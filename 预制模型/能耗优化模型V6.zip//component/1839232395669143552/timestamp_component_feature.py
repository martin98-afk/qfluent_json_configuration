"""
@author: mading
@license: (C) Copyright 1999-2019, NJ_LUCULENT Corporation Limited.
@contact: mading@luculent.com
@file: timestamp_component_feature.py
@time: 2024/09/29 09:01
@desc:
"""
import pandas as pd
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv
from sushineAI.argument import Xlsx
from sushineAI.argument import File
from sushineAI.argument import Model, StringOfDict, StringOfList


@Component.inputs(Csv(key="input"))
@Component.params(StringOfDict(key=['year', 'month', 'week', 'day', 'hour', 'minute', 'second', 'day_of_week', 'day_of_year', 'day&night']))
@Component.columns(StringOfList(key="特征字段"))
@Component.outputs(Csv(key="output"))
def timestamp_component_feature(**kwargs):
    print(kwargs)
    input = kwargs.get('input')
    year= int(kwargs.get('year'))
    month = int(kwargs.get('month'))
    week = int(kwargs.get('week'))
    day = int(kwargs.get('day'))
    hour = int(kwargs.get('hour'))
    minute = int(kwargs.get('minute'))
    second = int(kwargs.get('second'))
    dayofweek = int(kwargs.get('day_of_week'))
    dayofyear = int(kwargs.get('day_of_year'))
    daynight = int(kwargs.get('day&night'))
    
    column1 = kwargs.get("特征字段")[0]
    input['time_feature'] = input[column1].apply(lambda x: pd.Timestamp(x))
    print(input.head())
    print(input.info())
    if year: input["year"] = input['time_feature'].apply(lambda x: x.year)
    if month: input["month"] = input['time_feature'].apply(lambda x: x.month)
    if week: input["week"] = input['time_feature'].apply(lambda x: x.week)
    if day: input["day"] = input['time_feature'].apply(lambda x: x.day)
    if hour: input["hour"] = input['time_feature'].apply(lambda x: x.hour)
    if minute: input["minute"] = input['time_feature'].apply(lambda x: x.minute)
    if second: input["second"] = input['time_feature'].apply(lambda x: x.second)
    if dayofweek: input["dayofweek"] = input['time_feature'].apply(lambda x: x.dayofweek)
    if dayofyear: input["dayofyear"] = input['time_feature'].apply(lambda x: x.dayofyear)
    if daynight: input["day&night"] = input['time_feature'].apply(lambda x: int((x.hour >= 6) and (x.hour <= 17)))
    input.drop("time_feature", axis=1, inplace=True)
    return {
        'output': input
    }


if __name__ == '__main__':
    App.run(timestamp_component_feature)
