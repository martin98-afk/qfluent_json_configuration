"""
算法包代码示例 - 烟雾反馈寻优参数优化
"""
from datetime import datetime
from typing import Tuple, List, Any, Optional

import numpy as np
import pandas as pd
from loguru import logger
from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.argument import StringOfDict
from sushineAI.argument import Xlsx
from sushineAI.component import Component


class SmokeOptimizationProcessor:
    """烟雾反馈寻优参数处理器"""

    def __init__(self, lookback_days: int = 3, add: float = 0.0, minus: float = 0.0):
        self.lookback_days = lookback_days
        self.add = add
        self.minus = minus

        # 配置参数
        self.TH_SAFE = 0.1    # 安全区
        self.TH_WARN = 0.5    # 警告区
        self.TH_DANGER = 1.0  # 危险区

    @staticmethod
    def calculate_smoke_index(smoke_record: List[float]) -> float:
        """计算单条记录的冒烟指数：平均每分钟冒烟次数"""
        if not isinstance(smoke_record, (list, tuple)) or len(smoke_record) != 4:
            return 0.0

        v1, v2, v3, seconds = smoke_record
        total_smoke = v1 + v2 + v3
        minutes = max(1, seconds / 60.0)
        return total_smoke / minutes

    @staticmethod
    def is_date_column(col_name: str) -> bool:
        """判断列名是否为日期格式 YYYY-MM-DD"""
        if not isinstance(col_name, str):
            return False
        try:
            datetime.strptime(col_name, '%Y-%m-%d')
            return True
        except ValueError:
            return False

    def parse_smoke_data(self, val: Any) -> Optional[List[float]]:
        """解析烟雾数据，支持字符串和列表格式"""
        if pd.isna(val):
            return None

        if isinstance(val, str) and val.strip():
            try:
                # 安全地解析字符串为列表
                parsed_val = eval(val)
                if isinstance(parsed_val, (list, tuple)) and len(parsed_val) == 4:
                    return list(parsed_val)
            except:
                logger.warning(f"无法解析烟雾数据: {val}")
                return None
        elif isinstance(val, (list, tuple)) and len(val) == 4:
            return list(val)

        return None

    def calculate_weighted_smoke_index(self, row: pd.Series) -> Tuple[float, List[str]]:
        """计算加权冒烟指数"""
        # 动态识别所有日期列
        date_cols = [col for col in row.index if self.is_date_column(str(col))]

        if not date_cols:
            logger.warning("未找到日期列数据")
            return 0.0, []

        # 按日期从新到旧排序
        date_cols_sorted = sorted(
            date_cols,
            key=lambda x: datetime.strptime(str(x), '%Y-%m-%d'),
            reverse=True
        )

        # 取最近几天的数据
        recent_date_cols = date_cols_sorted[:self.lookback_days]

        weighted_smoke_indices = []
        valid_weights = []
        valid_dates = []

        for i, col in enumerate(recent_date_cols):
            smoke_data = self.parse_smoke_data(row[col])
            if smoke_data is not None:
                smoke_index = self.calculate_smoke_index(smoke_data)
                # 指数衰减权重：最近一天权重最高
                weight = 0.5 ** i
                weighted_smoke_indices.append(smoke_index * weight)
                valid_weights.append(weight)
                valid_dates.append(col)
            else:
                logger.debug(f"日期 {col} 的烟雾数据无效，跳过")

        # 计算加权平均
        if sum(valid_weights) == 0:
            return 0.0, []

        avg_weighted_smoke_index = sum(weighted_smoke_indices) / sum(valid_weights)
        return avg_weighted_smoke_index, valid_dates

    def get_adjustment_suggestion(self, row: pd.Series, control_range: List[float]) -> Tuple[float, float, str, float]:
        """
        获取调节建议
        返回: (新下限, 新上限, 调节原因, 加权冒烟指数)
        """
        # 提取当前寻优范围
        current_L = float(row['寻优下限'])
        current_U = float(row['寻优上限'])

        # 计算加权冒烟指数
        avg_weighted_smoke_index, valid_dates = self.calculate_weighted_smoke_index(row)
        logger.debug(f"加权冒烟指数: {avg_weighted_smoke_index:.3f}, 有效日期: {valid_dates}")

        # 调节逻辑
        L_new = current_L
        U_new = current_U
        reason = "保持不变"

        # 检查是否在控制范围内
        L_MIN, L_MAX = control_range
        current_L = np.clip(current_L, L_MIN, L_MAX)
        current_U = np.clip(current_U, L_MIN, L_MAX)

        if avg_weighted_smoke_index >= self.TH_WARN:
            # 警告调节：同时提高下限和上限（减少冒烟）
            L_new = min(current_L + self.add, L_MAX)  # 确保下限不超过上限-1
            U_new = min(current_U + self.add, L_MAX)  # 同时提高上限
            reason = f"⚠️ 警告调节：加权冒烟指数{avg_weighted_smoke_index:.3f}≥{self.TH_WARN}，下限+{self.add:.1f}（从{current_L:.1f}到{L_new:.1f}），上限+{self.add:.1f}（从{current_U:.1f}到{U_new:.1f}）"
        elif avg_weighted_smoke_index <= self.TH_SAFE:
            # 节能调节：适当降低下限（允许更多冒烟以节能），上限保持不变或适当降低
            L_new = max(current_L - abs(self.minus), current_U * 0.3)  # 不低于上限的30%
            reason = f"🌿 节能调节：加权冒烟指数{avg_weighted_smoke_index:.3f}≤{self.TH_SAFE}，下限-{abs(self.minus):.1f}（从{current_L:.1f}到{L_new:.1f}）"
        else:
            # 安全区域，保持不变
            reason = f"✅ 安全区域内，保持：加权冒烟指数{avg_weighted_smoke_index:.3f}，当前下限{current_L:.1f}，当前上限{current_U:.1f}"

        # 安全边界保护
        L_new = np.clip(L_new, L_MIN, min(L_MAX, U_new - 0.1))  # 确保下限始终低于上限
        U_new = np.clip(U_new, max(L_MIN, L_new + 0.1), L_MAX)  # 确保上限始终高于下限

        return L_new, U_new, reason, avg_weighted_smoke_index

    def process_sheet(self, df: pd.DataFrame, control_range: List[float]) -> pd.DataFrame:
        """处理单个sheet的数据"""
        logger.info(f"开始处理sheet，数据形状: {df.shape}")

        # 保存原始值
        original_L = df['寻优下限'].copy()
        original_U = df['寻优上限'].copy()

        # 创建结果DataFrame
        result_df = df.copy()

        # 应用调节建议
        new_L_values = []
        new_U_values = []
        reasons = []
        weighted_indices = []

        for idx, row in df.iterrows():
            try:
                L_new, U_new, reason, weighted_index = self.get_adjustment_suggestion(row, control_range)
                new_L_values.append(L_new)
                new_U_values.append(U_new)
                reasons.append(reason)
                weighted_indices.append(weighted_index)
            except Exception as e:
                logger.error(f"处理行 {idx} 时出错: {e}")
                # 返回原始值
                new_L_values.append(row['寻优下限'])
                new_U_values.append(row['寻优上限'])
                reasons.append(f"处理错误: {str(e)}")
                weighted_indices.append(0.0)

        # 更新原有的寻优下限和寻优上限
        result_df['寻优下限'] = new_L_values
        result_df['寻优上限'] = new_U_values
        # 添加旧寻优上下限
        result_df['旧寻优下限'] = original_L
        result_df['旧寻优上限'] = original_U
        # 添加其他列
        result_df['调节原因'] = reasons
        result_df['加权冒烟指数'] = weighted_indices

        logger.info(f"完成sheet处理，更新了{len(new_L_values)}行数据")
        return result_df


@Component.inputs(File(key="input", file_type="Any"), File(key="model_params", file_type="Json"))
@Component.params(StringOfDict(key=['lookback_days', 'add', 'minus']))
@Component.outputs(Xlsx(key="output"))
def main_business(**kwargs):
    """
    主业务逻辑：烟雾反馈寻优参数优化
    """
    try:
        # 获取输入参数
        input_file = kwargs.get('input').name
        model_params = kwargs.get("model_params")
        lookback_days = int(kwargs.get("lookback_days", 3))
        add = float(kwargs.get("add", 0.0))
        minus = float(kwargs.get("minus", 0.0))

        logger.info(f"开始处理文件: {input_file}")
        logger.info(f"参数设置 - 回溯天数: {lookback_days}, add: {add}, minus: {minus}")

        # 读取Excel文件
        excel_data = pd.read_excel(input_file, sheet_name=None)
        logger.info(f"Excel包含 {len(excel_data)} 个工作表")

        # 初始化处理器
        processor = SmokeOptimizationProcessor(lookback_days=lookback_days, add=add, minus=minus)

        # 获取控制范围
        control_vars = model_params.get("control_vars_normal", [])
        if len(control_vars) < len(excel_data):
            raise ValueError(f"控制变量数量({len(control_vars)})不足，需要{len(excel_data)}个")

        result = {}

        # 处理每个工作表
        for i, sheet_name in enumerate(excel_data):
            current_df = excel_data[sheet_name]

            if current_df.empty:
                logger.warning(f"工作表 {sheet_name} 为空，跳过处理")
                result[sheet_name] = current_df
                continue

            # 验证必要列是否存在
            required_cols = ['寻优下限', '寻优上限']
            missing_cols = [col for col in required_cols if col not in current_df.columns]
            if missing_cols:
                raise ValueError(f"工作表 {sheet_name} 缺少必要列: {missing_cols}")

            control_range = control_vars[i]
            logger.info(f"处理工作表: {sheet_name}, 控制范围: {control_range}")

            # 处理当前工作表
            processed_df = processor.process_sheet(current_df, control_range)
            result[sheet_name] = processed_df

            logger.info(f"工作表 {sheet_name} 处理完成，数据形状: {processed_df.shape}")

        logger.info("所有工作表处理完成")
        return {'output': result}

    except Exception as e:
        logger.error(f"主业务逻辑执行出错: {e}")
        raise


if __name__ == '__main__':
    App.run(main_business)