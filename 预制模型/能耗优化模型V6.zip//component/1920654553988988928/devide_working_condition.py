"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: devide_working_condition.py
@time: 2024/5/28 15:22
@desc: 
"""
import datetime
import os
import shutil
import sys
import json
import zipfile

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from loguru import logger
from jenkspy import jenks_breaks
from kneed import KneeLocator
from typing import Tuple, Dict
from sushineAI.utils.translator import transform_params_type
from sklearn.mixture import GaussianMixture

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, File, StringOfDict, Model
from sushineAI.component import Component
from sushineAI.app import App

SideFunc = {}


def register_function(name):
    """注册函数"""

    def decorator(func):
        SideFunc[name] = func
        return func

    return decorator


@register_function("min_max")
def calc(data, **kwargs):
    return [np.min(data), np.max(data)]


@register_function("normal")
def calc(data, **kwargs):
    return [np.mean(data), np.std(data)]


@register_function("25%~50%")
def calc(data, **kwargs):
    return [np.percentile(data, 25), np.percentile(data, 50)]


@register_function("percentile")
def calc(data, **kwargs):
    lower_percentage = kwargs.get("lower_percentage")
    upper_percentage = kwargs.get("upper_percentage")
    return [np.percentile(data, lower_percentage), np.percentile(data, upper_percentage)]


@register_function("one_sigma")
def calc(data, **kwargs):
    return [np.mean(data) - np.std(data), np.mean(data) + np.std(data)]


@register_function("two_sigma")
def calc(data, **kwargs):
    return [np.mean(data) - 2 * np.std(data), np.mean(data) + 2 * np.std(data)]


@register_function("three_sigma")
def calc(data, **kwargs):
    return [np.mean(data) - 3 * np.std(data), np.mean(data) + 3 * np.std(data)]


@register_function("adapt")
def calc(data, **kwargs):
    import statistics
    max_std = kwargs.get("max_std")
    min_std = kwargs.get("min_std")
    max_data = kwargs.get("max_data")
    min_data = kwargs.get("min_data")
    # 获取数据上下限
    data = np.round(data, 1)
    mode = statistics.mode(data)
    minimum = min(mode, np.mean(data))
    maximum = max(mode, np.mean(data))
    # 计算权重
    # TODO 公式错误，逻辑细化
    if mode < 0:
        weight = (minimum - min_data) / (max_data - min_data) * (max_std - data.std()) / (max_std - min_std)
        return [minimum, (0.95 - weight * 0.05) * minimum]
    else:
        weight = (max_data - maximum) / (max_data - min_data) * (max_std - data.std()) / (max_std - min_std)
        return [(0.95 - weight * 0.05) * maximum, maximum]


@register_function("five_percent_mean")
def calc(data, **kwargs):
    if np.mean(data) < 0:
        return [1.0 * np.mean(data), 0.9 * np.mean(data)]
    else:
        return [0.9 * np.mean(data), 1.0 * np.mean(data)]


@register_function("three_percent_mean")
def calc(data, **kwargs):
    if np.mean(data) < 0:
        return [1.0 * np.mean(data), 0.94 * np.mean(data)]
    else:
        return [0.94 * np.mean(data), 1.0 * np.mean(data)]


@register_function("five_percent_mode")
def calc(data, **kwargs):
    import statistics
    data = np.round(data, 1)
    mode = statistics.mode(data)
    if mode < 0:
        return [1.0 * mode, 0.9 * mode]
    else:
        return [0.9 * mode, 1.0 * mode]


@register_function("three_percent_mode")
def calc(data, **kwargs):
    import statistics
    data = np.round(data, 1)
    mode = statistics.mode(data)
    if mode < 0:
        return [1.0 * mode, 0.94 * mode]
    else:
        return [0.94 * mode, 1.0 * mode]


def find_optimal_jenks(
        data: np.ndarray,
        max_k: int = 10,
        sample_size: int = 10000,
        use_auto_knee: bool = True,
        return_plot: bool = False,
        random_seed: int = 42
) -> Tuple[int, Dict, np.ndarray, plt.Figure]:
    """
    自动确定Jenks自然间断点法的最佳分类数

    参数：
    data : 输入数据数组
    max_k : 考虑的最大分类数（默认10）
    use_auto_knee : 是否使用Kneed算法自动检测拐点（默认True）
    sample_size: 随机采样数
    random_seed: 随机种子
    return_plot : 是否返回可视化图表（默认False）

    返回：
    best_k : 推荐的最佳分类数
    metrics : 包含评估指标的字典
    breaks : 最佳分类对应的间断点数组
    fig : 可视化图表对象（仅当return_plot=True时返回）
    """
    # 参数校验
    if not isinstance(data, np.ndarray):
        data = np.array(data)
    if max_k < 2:
        raise ValueError("max_k必须大于等于2")
    if len(data) < max_k:
        raise ValueError("数据量必须大于max_k")

    # 数据预处理
    orig_data = np.asarray(data).ravel()
    n = len(orig_data)

    # 智能数据抽样（保留分布特征）
    if n > sample_size:
        np.random.seed(random_seed)
        stratify_bins = min(100, n // 100)  # 动态分层数
        bins = np.linspace(orig_data.min(), orig_data.max(), stratify_bins)
        digitized = np.digitize(orig_data, bins)

        # 分层随机抽样
        sampled_indices = []
        for d in np.unique(digitized):
            pool = np.where(digitized == d)[0]
            if len(pool) == 0: continue
            sample_num = min(max(1, int(sample_size * len(pool) / n)), len(pool))
            sampled_indices.extend(np.random.choice(pool, sample_num, replace=False))
        print(f"采样长度: {len(sampled_indices)}")
        # 确保抽样总数不超过目标
        sampled_data = orig_data[sampled_indices]
        print(f"数据量从 {n} 抽样至 {sample_size}（分层抽样）")
    else:
        sampled_data = orig_data.copy()

    # 初始化指标存储
    k_values = list(range(2, max_k + 1))
    metrics = {
        'gvf': [],
        'bic': [],
        'f_stat': [],
        'breaks_list': []
    }

    # 计算总方差
    mean = np.mean(sampled_data)
    sst = np.sum((sampled_data - mean) ** 2)
    n = len(sampled_data)

    # 遍历所有k值
    for i, k in enumerate(k_values):
        # 计算自然间断点
        breaks = jenks_breaks(sampled_data, n_classes=k)
        metrics['breaks_list'].append(breaks)

        # 计算组内方差
        classes = np.digitize(sampled_data, breaks[1:-1])  # 排除首尾断点
        ssw = 0
        for i in range(k):
            class_data = sampled_data[classes == i]
            if len(class_data) > 0:
                ssw += np.sum((class_data - np.mean(class_data)) ** 2)

        # 计算评估指标
        gvf = (sst - ssw) / sst
        metrics['gvf'].append(gvf)

        # 伪F统计量
        f_stat = ((sst - ssw) / (k - 1)) / (ssw / (n - k)) if k > 1 else 0
        metrics['f_stat'].append(f_stat)

        # BIC
        bic = n * np.log(ssw / n) + k * np.log(n)
        metrics['bic'].append(bic)

    # 自动选择最佳k值
    if use_auto_knee:
        # 使用Kneed算法检测GVF曲线拐点
        kneedle = KneeLocator(k_values, metrics['gvf'], curve='concave', direction='increasing', S=2)
        best_k = kneedle.knee if kneedle.knee else k_values[-1]
    else:
        # 使用BIC最小值
        best_k = k_values[np.argmin(metrics['bic'])]

    # 获取最佳断点
    best_breaks = metrics['breaks_list'][best_k - 2]  # k从2开始
    best_breaks = [round(br, 2) for br in best_breaks]
    # 可视化
    fig = None
    if return_plot:
        fig = plt.figure(figsize=(12, 5))

        # GVF曲线
        plt.subplot(1, 2, 1)
        plt.plot(k_values, metrics['gvf'], 'bo-')
        plt.axvline(best_k, color='r', linestyle='--')
        plt.xlabel('Number of classes (k)')
        plt.ylabel('GVF')
        plt.title(f'Best k={best_k} (Auto)')

        # 数据分布
        plt.subplot(1, 2, 2)
        plt.hist(data, bins=30, alpha=0.7)
        for b in best_breaks:
            plt.axvline(b, color='r', linestyle='--')
        plt.title('Data Distribution with Breaks')

        plt.tight_layout()

    return (best_k, metrics, best_breaks, fig) if return_plot else (best_k, metrics, best_breaks)


def calc_jenks_break_point(df: pd.DataFrame, break_points: dict, feature_range: list[list[float]],
                           n_classes: list[int], cut_ranges: list[list[list[float]]], current_path: str):
    def convert_from_value_to_interval(value: float, clusters: list):
        for cluster in clusters:
            if value >= cluster[0] and value <= cluster[1]:
                return cluster
        if value < clusters[0][0]:
            return clusters[0]
        elif value > clusters[-1][1]:
            return clusters[-1]

    # 对每个工况进行Jenks自然间断点聚类
    cluster_results = {}
    for i, column in enumerate(df.columns):
        values = df[column].dropna().values
        n_class = 10 if n_classes[i] == 0 else n_classes[i]
        n_class = min(n_class, len(df[column].dropna().unique()))
        if len(cut_ranges[i]) > 0:
            default_ranges = sorted(cut_ranges[i], key=lambda x: x[0])
            # 确保区间中不会有缝隙
            clusters = []
            for i in range(len(default_ranges) - 1):
                if default_ranges[i][1] < default_ranges[i + 1][0]:
                    clusters.extend([default_ranges[i], [default_ranges[i][1], default_ranges[i + 1][0]]])
                elif default_ranges[i][1] > default_ranges[i + 1][0]:
                    clusters.append([default_ranges[i][0], default_ranges[i + 1][0]])
                else:
                    clusters.append(default_ranges[i])
            clusters.append(default_ranges[-1])
        elif column not in break_points:
            # 使用Jenks自然间断点算法
            best_k, metrics, best_breaks, fig = find_optimal_jenks(data=values, max_k=n_class, return_plot=True)
            fig.savefig(f"{current_path}/{column}.png")
            # 生成区间标记
            clusters = []
            for j in range(len(best_breaks) - 1):
                clusters.append([best_breaks[j], best_breaks[j + 1]])
            if len(feature_range[i]) > 0:
                clusters = [[round(feature_range[i][0], 2), best_breaks[0]]] + clusters \
                    if best_breaks[0] > round(feature_range[i][0], 2) else clusters
                if best_breaks[-1] < round(feature_range[i][1], 2):
                    clusters.append([best_breaks[-1], round(feature_range[i][1], 2)])
        else:
            clusters = break_points.get(column)

        # 对原模拟量按区间进行离散化
        df[column] = df[column].apply(lambda x: convert_from_value_to_interval(x, clusters))

        cluster_results[column] = clusters

    return cluster_results, df


def save_gk(current_path, data, file_name: str):
    with open(os.path.join(current_path, file_name), "w") as f:
        json.dump(data, f)


def load_json(current_path: str, file_name: str):
    data = {}
    if os.path.exists(os.path.join(current_path, file_name)):
        logger.info("读取到原训练结果，结果保留!")
        with open(os.path.join(current_path, file_name), "r") as f:
            data = json.load(f)

    return data


@Component.inputs(Csv(key="control"), Csv(key="feature"), File(key='model_params', file_type='Json'))
@Component.params(
    StringOfDict(key=["min_num_of_working_condition", "remove", "all_min_percentage", "all_max_percentage"]))
@Component.outputs(File(key="output1", file_type="Json"), Model(key="gmm", model_type="sklearn"),
                   File(key='model_params', file_type='Json'), File(key="images.zip", file_type="Any"))
def compute_target_weight(**kwargs):
    current_time = (datetime.datetime.now() + datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
    # 获取参数
    control_df = kwargs.get('control')  # 控制参数
    feature_df = kwargs.get('feature')  # 工况参数
    model_params = kwargs.get("model_params")  # 模型参数
    feature_df.columns = [
        name if len(name) > 0 else column
        for column, name in zip(feature_df.columns, model_params.get("feature_vars_name"))
    ]

    dist_func = model_params.get("distance_function")  # 距离函数
    feature_type = model_params.get("feature_type")  # 工况类型
    min_num_of_working_condition = transform_params_type(kwargs.get('min_num_of_working_condition'), int, 50)  # 每类最小样本数
    # 获取工况存储路径
    current_path = os.getcwd()
    current_path = current_path.replace("/opt/", "/")
    if (not model_params.get("keep") or int(kwargs.get("remove"))) and os.path.exists(current_path):
        shutil.rmtree(current_path)
    os.makedirs(current_path, exist_ok=True)
    # 读取历史工况分割结果
    search_dist_dict = load_json(current_path, "gk.json") \
        if model_params.get("keep") and feature_type == "距离匹配" else {}

    break_points = load_json(current_path, "break_points.json") \
        if model_params.get("keep") and feature_type == "距离匹配" else {}

    # 初始化聚类模型
    gk_nums = model_params.get("gk_nums")
    gmm = GaussianMixture(n_components=gk_nums)
    # TODO 优化对模拟量工况的工况分割效果
    if feature_type == "距离匹配":
        # 提取类型为模拟量的工况
        float_columns_index = list(np.where(np.array(model_params["feature_vars_type"]) == "模拟量")[0])
        # TODO 描述细化
        if len(float_columns_index) > 0:
            feature_range = [
                item for i, item in enumerate(model_params["feature_vars_normal"]) if i in float_columns_index]
            cut_nums = [
                item for i, item in enumerate(model_params["feature_vars_cut_nums"]) if i in float_columns_index]
            non_switch_columns = list(feature_df.columns.to_numpy()[float_columns_index]) \
                if len(break_points) == 0 else [key for key in break_points]
            cut_ranges = [
                item for i, item in enumerate(model_params["feature_vars_cut_ranges"]) if i in float_columns_index]
            # 计算模拟量的自然断点
            break_points, feature_df[non_switch_columns] = calc_jenks_break_point(
                feature_df[non_switch_columns], break_points, feature_range, cut_nums, cut_ranges, current_path
            )
            model_params["break_points"] = break_points
            save_gk(current_path, break_points, "break_points.json")
        # 关联控制参数与工况参数，方便后续计算寻优范围
        df = pd.concat([control_df, feature_df], axis=1)
        control_columns = control_df.columns.tolist()
        # 构建字符串工况，方便统计每种工况的样本数量
        df["GK"] = df.iloc[:, len(control_columns):].values.tolist()
        df["GK"] = df["GK"].apply(
            lambda x: json.dumps([[column, item] for column, item in zip(feature_df.columns, x)], ensure_ascii=False)
        )

    elif feature_type == "聚类匹配":
        df = pd.concat([control_df, feature_df], axis=1)
        control_columns = control_df.columns.tolist()
        df["GK"] = df.iloc[:, len(control_columns):].values.tolist()
        gk = np.array(df["GK"].values.tolist())
        gmm.fit(gk)
        df["GK"] = df["GK"].apply(lambda x: str(gmm.predict(np.array(x).reshape(1, -1))))

    # 筛选工况中出现次数大于100次的工况，小于50次的工况计算平均值和方差没有意义
    select_GK = df.groupby("GK")["GK"].count() > min_num_of_working_condition
    select_GK = select_GK.index[select_GK.values]
    df.set_index(df["GK"], inplace=True)
    df = df.loc[select_GK, :]
    assert len(df) > 0, "历史数据量不够，所有工况的数据都没有超过设定的最小样本数量！选择更长时间的数据，或者降低每种工况的最小样本数！"
    # 导入搜寻范围计算模块
    search_dist_fun = SideFunc.get(dist_func)

    for i, control_var in enumerate(control_columns):
        search_dist = search_dist_dict.get(control_var, {})
        max_data = max(df.loc[:, control_var].values.tolist())
        min_data = min(df.loc[:, control_var].values.tolist())

        max_std = max([df.loc[gk, control_var].std() for gk in select_GK])
        min_std = min([df.loc[gk, control_var].std() for gk in select_GK])
        for gk in select_GK:
            if gk in search_dist:
                logger.info(f"检测到历史计算过该工况{gk}!")
                continue

            gk_data = df.loc[gk, control_var]
            # TODO 增加自适应工况计算，依据工况的均值，以及方差计算范围
            control_range = search_dist_fun(
                gk_data, max_data=max_data, min_data=min_data, max_std=max_std, min_std=min_std
            )
            search_dist[gk] = control_range + [gk_data.mean(), gk_data.std(), len(gk_data), current_time]

        # 如果再推理时出现未见过的工况，则使用全部训练数据的范围去寻优
        control_range = SideFunc.get("percentile")(
            df.loc[:, control_var],
            lower_percentage=int(kwargs.get("all_min_percentage")),
            upper_percentage=int(kwargs.get("all_max_percentage"))
        )
        search_dist["all"] = control_range + [df.loc[:, control_var].mean(), df.loc[:, control_var].std(), len(df)]
        search_dist = {key: [item for item in value] for key, value in search_dist.items()}
        search_dist_dict[control_var] = search_dist

    save_gk(current_path, search_dist_dict, "gk.json")
    with zipfile.ZipFile("images.zip", "w") as zipf:
        for root, dirs, files in os.walk(current_path):
            for file in files:
                if file.endswith(".png"):
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.relpath(file_path, ""))

    with open("images.zip", "rb") as file:
        return {
            'output1': search_dist_dict, "gmm": gmm, "model_params": model_params, "images.zip": file.read()
        }


if __name__ == '__main__':
    App.run(compute_target_weight)
