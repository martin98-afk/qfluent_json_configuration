"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: configuration_convertion.py
@time: 2024/5/28 15:22
@desc: 
"""
import datetime
import os
import sys

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import File
from sushineAI.component import Component
from sushineAI.app import App


def delete_eight_hours(time_str):
    time_correct = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S") - datetime.timedelta(hours=8)
    return time_correct.strftime("%Y-%m-%d %H:%M:%S")


def fill_range(input_dict, major_key, minor_key):
    result = []
    for k, v in input_dict[major_key].items():
        if len(v[minor_key]) == 0:
            result.append([])
        else:
            range = v[minor_key]
            range[0] = -10000 if range[0] == "-inf" else range[0]
            range[1] = 10000 if range[1] == "inf" else range[1]
            result.append(range)

    return result


@Component.inputs(File(key='input', file_type='Json'))
@Component.outputs(File(key='output', file_type='Json'))
def configuration_convertion(**kwargs):
    input = kwargs.get("input")
    output = {}
    loss_target_dict = {
        "最小": "min", "最大": "max", "均值": "mean",
        "均值+上下限": "mean+-", "均值+上限": "mean+",
        "均值+下限": "mean-"
    }
    distance_function_dict = {
        "自适应": "adapt",
        "众数-6%": "three_percent_mode",
        "众数-10%": "five_percent_mode",
        "均值-6%": "three_percent_mean",
        "均值-10%": "five_percent_mean",
        "下四分位距": "",
        "正态分布": ""
    }
    # 解析控制参数
    output["control_vars"] = [v["测点名"].split("\n")[0] for k, v in input["控制参数"].items()]
    output["target_vars"] = [v["测点名"].split("\n")[0] for k, v in input["目标参数"].items()]
    output["feature_vars"] = [v["测点名"].split("\n")[0] for k, v in input["工况参数"].items()]
    output["control_vars_name"] = [v["测点名"].split("\n")[1] if "\n" in v["测点名"] else "" for k, v in
                                   input["控制参数"].items()]
    output["target_vars_name"] = [v["测点名"].split("\n")[1] if "\n" in v["测点名"] else "" for k, v in
                                  input["目标参数"].items()]
    output["feature_vars_name"] = [v["测点名"].split("\n")[1] if "\n" in v["测点名"] else "" for k, v in
                                   input["工况参数"].items()]
    # 解析各个参数理论正常范围
    output["control_vars_normal"] = fill_range(input, "控制参数", "理论正常范围")
    output["target_vars_normal"] = fill_range(input, "目标参数", "理论正常范围")
    output["feature_vars_normal"] = fill_range(input, "工况参数", "理论正常范围")
    # 解析参数类型
    output["control_vars_type"] = [v.get("控制类型", "") for k, v in input["控制参数"].items()]
    output["feature_vars_type"] = [v.get("工况类型", "") for k, v in input["工况参数"].items()]
    # 解析切分数量
    output["feature_vars_cut_nums"] = [
        int(v["切分数量"]) if "切分数量" in v and len(v["切分数量"]) > 0 else 0 for k, v in input["工况参数"].items()
    ]
    output["feature_vars_cut_ranges"] = [
        v["自定义切分范围"] if "自定义切分范围" in v and len(v["自定义切分范围"]) > 0 else []
        for k, v in input["工况参数"].items()
    ]
    # 解析目标损失类型
    output["loss_target"] = [loss_target_dict[v["目标计算类型"]] for k, v in input["目标参数"].items()]
    # 解析控制范围
    output["boundary"] = fill_range(input, "控制参数", "控制范围")

    # 解析其他参数
    output["feature_type"] = input["工况划分策略"]
    output["gk_nums"] = int(input["聚类数量"]) if len(input["聚类数量"]) > 0 else ""
    output["keep"] = True if input["是否保留工况"] == "是" else False
    output["distance_function"] = distance_function_dict[input["寻优范围计算方法"]]

    # 解析时序库配置
    trenddb_config = input["时序库配置"]
    output["trenddb_ip"] = trenddb_config["时序库host"]
    output["trenddb_port"] = trenddb_config["时序库port"]
    output["trenddb_version"] = trenddb_config["时序库版本"].lower()
    output["trenddb_name"] = trenddb_config["时序库库名"]
    output["trenddb_username"] = trenddb_config["时序库用户名(V4不需要)"]
    output["trenddb_password"] = trenddb_config["时序库密码(V4不需要)"]

    # 解析历史训练数据时间段
    output["time_lists"] = []
    if isinstance(input["历史训练数据范围"], dict):
        for k, d in input["历史训练数据范围"].items():
            if "开始/结束时间" not in d:
                output["time_lists"].extend([
                    {
                        "beginTime": delete_eight_hours(d["开始时间"]),
                        "endTime": delete_eight_hours(d["结束时间"]),
                        "sampleInterval": float(d["采样间隔(s)"]),
                    }])
            elif isinstance(d["开始/结束时间"][0], list):
                output["time_lists"].extend([{
                    "beginTime": delete_eight_hours(item[0]),
                    "endTime": delete_eight_hours(item[1]),
                    "sampleInterval": float(d["采样间隔(s)"]),
                }
                    for item in d["开始/结束时间"]
                ])
            else:
                output["time_lists"].extend([{
                    "beginTime": delete_eight_hours(d["开始/结束时间"][0]),
                    "endTime": delete_eight_hours(d["开始/结束时间"][1]),
                    "sampleInterval": float(d["采样间隔(s)"]),
                }
                ])

    # 解析试试训练数据范围
    if "实时训练数据范围(天)" in input and len(input["实时训练数据范围(天)"]) > 0:
        output["time_lists"].append(
            {
                "beginTime": (
                        datetime.datetime.now() - datetime.timedelta(
                    days=float(input["实时训练数据范围(天)"]))
                ).strftime("%Y-%m-%d %H:%M:%S"),
                "endTime": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "sampleInterval": float(input["实时训练数据采样间隔(s)"]),
            }
        )
    output["original_params"] = input

    return {"output": output}


if __name__ == '__main__':
    App.run(configuration_convertion)
