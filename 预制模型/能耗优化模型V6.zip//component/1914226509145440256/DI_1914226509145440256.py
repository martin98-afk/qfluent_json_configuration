"""
@author: TangXC
@license: (C) Copyright 1999-2019, NJ_LUCULENT Corporation Limited.
@contact: tangxucheng@luculent.com
@file: request_platform_csv.py
@time: 2024/08/26 11:12
@desc:
"""
import json
import pandas as pd
import os
from zipfile import ZipFile
from sushineAI.argument import Csv, StringOfDict, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.params(StringOfDict(key=["url"]))
@Component.outputs(File(key='model_param', file_type="Json"))
def request_platform_csv(**kwargs):
    file_path = os.path.join("/opt/storage", kwargs['url'].split("?filePath=/")[-1])
    with ZipFile(file_path) as zipfile:
        zipfile.extractall()
        for file_name in os.listdir("./"):
            if file_name.endswith(".json"):
                with open(file_name, "r") as f:
                    return {"model_param": json.load(f)}

if __name__ == '__main__':
    App.run(request_platform_csv)
