"""
算法包代码示例
"""
import os
import json
import datetime
from pathlib import Path
from typing import defaultdict
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv
from sushineAI.argument import Xlsx
from sushineAI.argument import File
from sushineAI.argument import Model


@Component.inputs(File(key="model_params",file_type="Json"))
@Component.outputs(File(key="output",file_type="Json"))
def main_business(**kwargs):
    model_params = kwargs.get('model_params')
    smoke_feedback_id = model_params.get("烟雾反馈存储id")
    days_back = kwargs.get("days_back", 7)  # 默认最近7天
    
    base_dir = Path("/opt") / "smoke_stats" / str(smoke_feedback_id)
    if not base_dir.exists():
        return {'output': {}}
    
    merged_data = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    
    for i in range(days_back):
        date_str = (datetime.datetime.now() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
        file_path = base_dir / f"{date_str}.json"
        
        if file_path.exists():
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    daily_data = json.load(f)
                
                # 合并：gk_id -> date -> smoke_col -> list
                for gk_id, gk_data in daily_data.items():
                    for date_key, smoke_dict in gk_data.items():
                        for smoke_col, counts in smoke_dict.items():
                            merged_data[gk_id][date_key][smoke_col].extend(counts)
            except Exception as e:
                print(f"Warning: failed to load {file_path}: {e}")
                continue
    
    # 转为普通 dict（避免 defaultdict）
    result = {
        gk: {
            d: dict(smoke_cols)
            for d, smoke_cols in dates.items()
        }
        for gk, dates in merged_data.items()
    }
    
    return {'output': result}


if __name__ == '__main__':
    App.run(main_business)
