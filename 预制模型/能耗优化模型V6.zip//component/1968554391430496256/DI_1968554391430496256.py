"""
算法包代码示例
"""
import os
import json

from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv
from sushineAI.argument import Xlsx
from sushineAI.argument import File
from sushineAI.argument import Model


@Component.inputs(File(key="model_params",file_type="Json"))
@Component.outputs(File(key="output",file_type="Json"))
def main_business(**kwargs):
    model_params = kwargs.get('model_params')
    smoke_feedback_id = model_params.get("烟雾反馈存储id")
    return {
        'output': json.load(
            open(
                os.path.join("/opt", f"{smoke_feedback_id}.txt"), "r"
            )
        )
    }


if __name__ == '__main__':
    App.run(main_business)
