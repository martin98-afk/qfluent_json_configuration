"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: compute_target_mean_std.py
@time: 2025/1/20 16:09
@desc: 
"""

import os
import sys
import numpy as np

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, File, StringOfDict
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(Csv(key="target"), File(key='model_params',file_type='Json'))
@Component.params(StringOfDict(key=["loss_target"]))
@Component.outputs(File(key="output1", file_type="Json"))
def compute_target_weight(**kwargs):
    """
    目前支持7种目标函数类型，类型包括：
    min 历史最小值
    max 历史最大值
    mean 历史均值
    mean+ 历史均值，3倍标准差上限
    mean- 历史均值，3倍标准差下限
    mean+- 历史均值，3倍标准差上限和下限
    给定值 给定数值作为优化目标 
    """
    df = kwargs.get("target")
    model_params = kwargs.get("model_params")
    target_columns = df.columns
    # 计算目标值
    target = model_params.get("loss_target")
    for i in range(len(target)):
        target[i] = target[i].lower()
        # 7种目标函数类型
        if target[i] == "min":
            target[i] = {"target": df.loc[:, target_columns[i]].min()}
        elif target[i] == "max":
            target[i] = {"target": df.loc[:, target_columns[i]].max()}
        elif target[i] == "mean":
            target[i] = {"target": df.loc[:, target_columns[i]].mean()}
        elif target[i] == "mean+":
            target[i] = {
                "target": df.loc[:, target_columns[i]].mean(),
                "upper_bound": np.percentile(df.loc[:, target_columns[i]], 75)# df.loc[:, target_columns[i]].mean() + 3 * df.loc[:, target_columns[i]].std()
            }
        elif target[i] == "mean-":
            target[i] = {
                "target": df.loc[:, target_columns[i]].mean(),
                "lower_bound": np.percentile(df.loc[:, target_columns[i]], 25)# df.loc[:, target_columns[i]].mean() - 3 * df.loc[:, target_columns[i]].std()
            }
        elif target[i] == "mean+-" or target[i] == "mean-+":
            target[i] = {
                "target": df.loc[:, target_columns[i]].mean(),
                "upper_bound": np.percentile(df.loc[:, target_columns[i]], 25),# df.loc[:, target_columns[i]].mean() + 3 * df.loc[:, target_columns[i]].std(),
                "lower_bound": np.percentile(df.loc[:, target_columns[i]], 75)# df.loc[:, target_columns[i]].mean() - 3 * df.loc[:, target_columns[i]].std()
            }
        else:
            target[i] = {"target": float(target[i])}

    output = {
        df.columns[i]: target[i] for i in range(len(df.columns))
    }
    return {'output1': output}


if __name__ == '__main__':
    App.run(compute_target_weight)


