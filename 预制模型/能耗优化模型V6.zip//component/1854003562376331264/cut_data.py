"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: cut_data.py
@time: 2024/11/6 16:36
@desc: 
"""
import pandas as pd
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv

@Component.inputs(Csv(key="input1"), Csv(key="input2"), Csv(key="input3"))
@Component.outputs(Csv(key="output1"), Csv(key="output2"), Csv(key="output3"), Csv(key="timestamp"))
def main_business(**kwargs):
    input1 = kwargs.get('input1')
    input1.set_index("timestamp", inplace=True)
    input2 = kwargs.get('input2')
    input2.set_index("timestamp", inplace=True)
    input3 = kwargs.get('input3')
    input3.set_index("timestamp", inplace=True)
    merge_df = pd.merge(input1, input2, left_index=True, right_index=True, how="inner")
    merge_df = pd.merge(merge_df, input3, left_index=True, right_index=True, how="inner")
    merge_df.dropna(inplace=True)
    print(merge_df)
    print(merge_df.info())
    return {
        'output1': merge_df[input1.columns],
        'output2': merge_df[input2.columns],
        'output3': merge_df[input3.columns],
        'timestamp': pd.DataFrame(merge_df.index)
    }


if __name__ == '__main__':
    App.run(main_business)
