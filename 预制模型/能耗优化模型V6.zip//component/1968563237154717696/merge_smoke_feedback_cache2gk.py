"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: merge_smoke_feedback_cache2gk.py
@time: 2025/9/18 15:02
@desc: 
"""
import os
import sys
from loguru import logger
import datetime
PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(File(key="smoke_feedback", file_type="Json"), File(key="gk", file_type="Json"))
@Component.outputs(File(key="output", file_type="Json"))
def main(**kwargs):
    smoke_feedback = kwargs.get('smoke_feedback')
    gk = kwargs.get("gk")
    for lkey, lvalue in smoke_feedback.items():
        for key, value in gk.copy().items():
            if lkey not in gk[key]:
                gk[key][lkey] = gk[key].get("all", [0, 0, 0, 0, 0]) + [datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")] + [lvalue]
            else:
                gk[key][lkey].append(lvalue)

    return {'output': gk}


if __name__ == '__main__':
    App.run(main)