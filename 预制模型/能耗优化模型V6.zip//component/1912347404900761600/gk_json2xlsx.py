"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: gk_json2xlsx.py
@time: 2025/2/24 10:54
@desc: 
"""
import datetime
import os
import sys
import numpy as np
import pandas as pd
from loguru import logger
PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, Xlsx, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(File(key="input", file_type="Json"))
@Component.outputs(Xlsx(key="output"))
def main(**kwargs):
    json = kwargs.get('input')
    output_dict = {}
    info_columns = ["寻优下限", "寻优上限", "历史数据均值", "历史数据方差", "历史数据量", "工况更新时间"]
    smoke_columns = []
    for key in json:
        output_dict[key] = []
        json[key].pop("all")
        for lkey, value in json[key].items():
            lkey = eval(lkey)
            dicts = {key: 0}
            dicts.update({l[0]: l[1] for l in lkey})
            if len(value) <= 5:
                value.append(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                
            for column, v in zip(info_columns, value):
                dicts[column] = v
                
            # 烟雾反馈统计
            if len(value) > 6:
                smoke_feedback = value[6]
                smoke_columns = sorted([key for key in smoke_feedback], reverse=True)
                for column in smoke_columns:
                    dicts[column] = [np.sum(value) for key, value in smoke_feedback[column].items()]

            output_dict[key].append(dicts)

        columns = [key] + [l[0] for l in lkey] + info_columns + smoke_columns
        output_dict[key] = pd.DataFrame(output_dict[key], columns=columns)

    return {'output': output_dict}


if __name__ == '__main__':
    App.run(main)
