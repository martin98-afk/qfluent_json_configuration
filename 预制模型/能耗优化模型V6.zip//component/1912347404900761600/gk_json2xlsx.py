"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: gk_json2xlsx.py
@time: 2025/2/24 10:54
@desc: 
"""
import datetime
import os
import sys

import pandas as pd

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, Xlsx, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(File(key="input", file_type="Json"))
@Component.outputs(Xlsx(key="output"))
def main(**kwargs):
    json = kwargs.get('input')
    output_dict = {}
    for key in json:
        output_dict[key] = []
        json[key].pop("all")
        for lkey, value in json[key].items():
            lkey = eval(lkey)
            dicts = {key: 0}
            dicts.update({l[0]: l[1] for l in lkey})
            if len(value) != 6:
                value.append(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            dicts["寻优下限"] = value[0]
            dicts["寻优上限"] = value[1]
            dicts["历史数据均值"] = value[2]
            dicts["历史数据方差"] = value[3]
            dicts["历史数据量"] = value[4]
            dicts["工况更新时间"] = value[5]

            output_dict[key].append(dicts)

        columns = [key] + [l[0] for l in lkey] + ["寻优下限", "寻优上限", "历史数据均值", "历史数据方差", "历史数据量",
                                                  "工况更新时间"]
        output_dict[key] = pd.DataFrame(output_dict[key], columns=columns)

    return {'output': output_dict}


if __name__ == '__main__':
    App.run(main)
