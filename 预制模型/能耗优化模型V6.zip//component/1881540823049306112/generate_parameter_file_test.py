"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: GenerateParameterFile.py
@time: 2024/5/31 9:30
@desc: 
"""

import os
import sys

import pandas as pd

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, Xlsx, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(File(key="model_params", file_type="Json"))
@Component.outputs(Xlsx(key="parameters"))
def generate_parameter_file(**kwargs):
    model_params = kwargs.get('model_params')
    db_name = model_params.get("trenddb_name")
    output_list = []
    for column, name in zip(model_params["control_vars"], model_params["control_vars_name"]):
        output_list.append({"参数名称": f"{db_name}.{column}_AI_RECOM", "参数类型": "float", "参数描述": f"控制参数: {name}", "输入/输出": "输出"})
    for column, name in zip(model_params["target_vars"], model_params["target_vars_name"]):
        output_list.append({"参数名称": f"{db_name}.{column}_AI_PREDICT", "参数类型": "float", "参数描述": f"目标参数: {name}", "输入/输出": "输出"})
    for column, name in zip(model_params["feature_vars"], model_params["feature_vars_name"]):
        output_list.append({"参数名称": column, "参数类型": "float", "参数描述": f"工况参数: {name}", "输入/输出": "输入"})
    dataframe = pd.DataFrame(output_list)
    return {'parameters': {"sheet1": dataframe}}


if __name__ == '__main__':
    App.run(generate_parameter_file)


