"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: csv_column_merge.py
@time: 2024/9/27 17:42
@desc: 
"""
import pandas as pd
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv


@Component.inputs(Csv(key="input1"), Csv(key="input2"))
@Component.outputs(Csv(key="output"))
def main_business(**kwargs):
    input1 = kwargs.get('input1')
    input2 = kwargs.get('input2')
    return {
        'output': pd.merge(input1, input2, left_index=True, right_index=True)
    }


if __name__ == '__main__':
    App.run(main_business)