#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@Author  : WangLei
@Time    : 2020/6/10 16:21
@Email   : wanglei@luculent.net
@Project : SushineAIPlatform
@File    : PlotHistChart.py
@Desc    : 
'''


import os
import sys
import matplotlib
# Linux的非GUI交互式必须要添加(常用于服务器上），不能再使用matplotlib.pyplot.show查看图片，只能保存图片
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


# 注意linux服务器的字体问题，这个在windows下没问题
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
sns.set_style('darkgrid', {'font.sans-serif': ['simhei', 'Arial']})

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import StringOfDict, File, Csv, StringOfList
from sushineAI.component import Component
from sushineAI.app import App

# 多个字段画在多幅子图中，一维kdeplot（非displot）
def make_line_chart(data, kwargs):
    cols_list = kwargs.get('特征字段')
    n_cols = len(cols_list)
    if n_cols > 4:
        plt.figure(figsize=(12, 6))
        plt.suptitle("{}".format(kwargs.get('标题')))
        for i in range(n_cols):

            ax = plt.subplot(int(n_cols)/2+1, 2, i+1)
            y = list(data[cols_list[i]])
            sns.kdeplot(y, shade=True, label=cols_list[i], ax=ax)

        plt.legend()
        return plt
    else:
        plt.figure(figsize=(12, 6))
        plt.suptitle("{}".format(kwargs.get('标题')))
        for i in range(n_cols):

            ax = plt.subplot(n_cols, 1, i+1)
            y = list(data[cols_list[i]])
            sns.kdeplot(y, shade=True, label=cols_list[i], ax=ax)

        plt.legend()
        #
        return plt


@Component.inputs(Csv(key="input1"))
@Component.params(StringOfDict(key=['标题']))
@Component.columns(StringOfList(key="特征字段"))
@Component.outputs(File(key='output1', file_type='Image'))
def plot_line(**kwargs):
    data = kwargs.get('input1')
    plt = make_line_chart(data, kwargs)
    return {'output1': plt}


if __name__ == '__main__':
    App.run(plot_line)