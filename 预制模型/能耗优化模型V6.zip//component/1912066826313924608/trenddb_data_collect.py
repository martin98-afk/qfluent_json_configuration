"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: trend_db_data_collect.py
@time: 2025/4/15 16:54
@desc:
"""
import time
from typing import Union

import pandas as pd
import datetime
import os
import sys
import numpy as np

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from loguru import logger
from trenddb_client.v4 import TrendDBClient as TrendDBClientV4
from trenddb_client.v5 import TrendDBClient as TrendDBClientV5
from sushineAI.argument import StringOfDict, Csv, File
from sushineAI.component import Component
from sushineAI.app import App


def _utc_2_timestamp(utc):
    """
    UTC时间转时间字符串
    :param utc: utc时间戳
    :return: str
    """
    local_time = time.localtime(utc)
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S", local_time)
    return timestamp


# TrendDB数据库接口
class TrendDB_Manager:
    def __init__(self, db_host, db_port, db_version, db_name, username, password):
        if db_version.lower() == "v4":
            self.tc = TrendDBClientV4(db_host, db_port)
        elif db_version.lower() == "v5":
            self.tc = TrendDBClientV5(host=db_host, port=db_port, username=username, password=password, dbname=db_name)
        else:
            raise ValueError("Unknown DB version: {}".format(db_version))

    @staticmethod
    def _time_merge(date_times: Union[list, dict]):
        """
        取时间并集，减少重复获取数据。注意时间字符串规范性
        :param date_time_lists:
        :return:
        """
        if isinstance(date_times[0], list):
            date_time_sorted = sorted(date_times, key=lambda x: x[0])
            result = []
            for paratition in date_time_sorted:
                if len(result) != 0 and result[-1][1] >= paratition[0] and result[-1][2] == paratition[2]:
                    result[-1][1] = max(result[-1][1], paratition[1])
                else:
                    result.append(paratition)
            return result
        elif isinstance(date_times[0], dict):
            date_time_sorted = sorted(date_times, key=lambda x: x["beginTime"])
            result = []
            for paratition in date_time_sorted:
                if len(result) != 0 and result[-1]["endTime"] >= paratition["beginTime"] and result[-1][
                    "sampleInterval"] == paratition["sampleInterval"]:
                    result[-1]["endTime"] = max(result[-1]["endTime"], paratition["endTime"])
                else:
                    result.append(paratition)
            return result

    def _complex_respone_interval(self, respone):
        """
        解析请求返回参数->按PI固定间隔取值
        :param respone:
        :return:
        """
        history_data = {}

        try:
            for tag in respone:
                history_data[tag] = [item.value if not isinstance(item.value, bool) else int(item.value) for item in respone[tag]]
            history_data["timestamp"] = [item.utc_time for item in respone[tag]]
        except:
            Exception('TrendDB接口无返回数据')  # TrendDB数据库配置存在问题
        return history_data

    def _get_fixed_interval(self, tags, start_time, end_time, interval):
        """
        获取PI固定间隔
        :param start_time: 开始时间
        :param end_time: 结束时间
        :param interval: 时间间隔 second
        :return: []
        """
        # 调用获取固定间隔的接口
        start_time = int(time.mktime(time.strptime(start_time, '%Y-%m-%d %H:%M:%S')))
        end_time = int(time.mktime(time.strptime(end_time, '%Y-%m-%d %H:%M:%S')))
        respone = self.tc.get_history_values_by_period(tags, start_time, end_time, int(interval) * 1000)  # api need ms

        # 解析数据
        return self._complex_respone_interval(respone)

    def load_dataset(self, date_times, tags):
        """
        获取数据
        :param tags: 测点名list
        :param date_times: 时间段和自定义/等间隔列表
        """

        data = {'timestamp': []}
        # 检查测点名
        assert len(tags) == len(set(tags)), '存在重复测点'
        for tag in tags:
            data[tag] = []
        # 合并时间段
        date_time_lists = self._time_merge(date_times)
        # 遍历时间段获取数据
        for time_part in date_time_lists:
            sample_num = -1
            # 普通测点, 调用TrendDB接口
            cache = self._get_fixed_interval(tags, time_part[0], time_part[1], time_part[2])
            for tag, value in cache.items():  # 合并各时间段数据
                num = len(value)
                if num != 0 and sample_num == -1:
                    sample_num = num
                # 对数据异常处理
                assert num != 0, '测点:{} 在时间段：{} "{} 没有历史值'.format(tag, time_part[0], time_part[1])
                assert num == sample_num, '测点:{} 在时间段：{} "{} 数据长度不一致'.format(tag, time_part[0],
                                                                                          time_part[1])
                data[tag].extend(value)
        # 转换数据格式
        data = pd.DataFrame(data)
        logger.info(f"测点数量：{len(tags)} 时序库数据读取长度：{len(data)}")
        data['timestamp'] = [_utc_2_timestamp(i) for i in data['timestamp']]
        data = data.sort_values(by='timestamp').drop_duplicates().reset_index(drop=True)
        data.set_index('timestamp', inplace=True)
        return data.values, data.index


def load_dataset(db, tags, time_lists):
    """
    获取数据
    :param tags: 测点名list
    :param date_times: 时间段和自定义/等间隔列表
    :param tenant_no: 租号
    :return:
    """
    request = {'columnInfo': tags}
    # 获取当前时间节点
    request['timeIntervals'] = []
    # 对数据时间获取列表进行合并
    time_lists = TrendDB_Manager._time_merge(time_lists)
    logger.info(f"总时间获取列表: {time_lists}")
    for time_dict in time_lists:
        start_time = pd.to_datetime(time_dict["beginTime"])
        end_time = pd.to_datetime(time_dict["endTime"])
        time_interval = time_dict.get("sampleInterval")
        while start_time < end_time:
            new_time = (start_time + datetime.timedelta(days=1))
            if new_time > end_time: new_time = end_time
            request['timeIntervals'].append({
                'beginTime': start_time.strftime('%Y-%m-%d %H:%M:%S'),
                'endTime': new_time.strftime('%Y-%m-%d %H:%M:%S'),
                'sampleInterval': time_interval
            })
            start_time = new_time

    # 开始按测点逐次读取数据
    dataframe = pd.DataFrame()
    for j in range(len(request['timeIntervals'])):
        beginTime = request['timeIntervals'][j]['beginTime']
        endTime = request['timeIntervals'][j]['endTime']
        sampleInterval = request['timeIntervals'][j]['sampleInterval']
        # 对于测点数较多的情况采用分组查询数据
        merge_data, time_index = None, None
        for i in range(len(request['columnInfo'])):
            select_tags = request['columnInfo'][i:i + 1]
            if len(select_tags) == 0 or "" in select_tags: continue
            try:
                data, time_index = db.load_dataset(date_times=[[beginTime, endTime, sampleInterval]], tags=select_tags)
                if merge_data is not None:
                    if merge_data.shape[0] > data.shape[0]:
                        merge_data = merge_data[-data.shape[0]:, ...]
                    elif merge_data.shape[0] < data.shape[0]:
                        data = data[-merge_data.shape[0]:, ...]
                    merge_data = np.concatenate((merge_data, data), axis=1)
                else:
                    merge_data = data
            except Exception as e:
                import traceback
                logger.error(f"测点：{select_tags}，数据获取失败！错误信息: \n {traceback.format_exc()}")

        if merge_data is None or merge_data.shape[1] != len(request['columnInfo']):
            raise Exception("某个测点数据获取失败！")

        result = pd.DataFrame(np.squeeze(merge_data), columns=request['columnInfo'])
        result.set_index(time_index, inplace=True)
        dataframe = pd.concat([dataframe, result], axis=0)

    del db
    if bool(int(new_kwargs.get("return_timestamp"))):
        dataframe.reset_index(inplace=True)
        dataframe["timestamp"] = dataframe["timestamp"].apply(
            lambda x: pd.to_datetime(x).strftime(new_kwargs.get("timestamp_format")))

    return dataframe


def filter_data(dataframe, normal_range):
    for column, normal_range in zip(dataframe.columns[1:], normal_range):
        logger.info(column)
        logger.info(normal_range)
        if len(normal_range) != 2 or column == "timestamp": continue
        filter_data = dataframe.copy()
        filter_data = filter_data[
            (
                    (filter_data[column] > normal_range[1]) | (filter_data[column] < normal_range[0])
            )
        ]
        dataframe = dataframe.drop(index=filter_data.index, axis=0) if len(filter_data) != len(dataframe) else dataframe

    return dataframe


def get_trend_db_data(kwargs):
    json_params = kwargs.get("input")
    host = json_params.get("trenddb_ip")
    port = json_params.get("trenddb_port")
    db = json_params.get("trenddb_name")
    version = json_params.get("trenddb_version")
    username = json_params.get("trenddb_username")
    password = json_params.get("trenddb_password")
    tag_name = kwargs.get("tag_name")
    tags = json_params.get(tag_name)
    tags = tags.split(",") if isinstance(tags, str) else tags
    tags = [f"{db}.{item}" if not item.startswith(f"{db}.") else item for item in tags]
    time_lists = json_params.get("time_lists")
    db = TrendDB_Manager(host, port, version, db, username, password)
    dataframe = load_dataset(db, tags, time_lists)
    # 通过配置的数据正常范围对数据进行过滤
    normal_range_tag = tag_name + "_normal"
    if normal_range_tag not in json_params:
        return dataframe
    else:
        return filter_data(dataframe, json_params[normal_range_tag])


@Component.inputs(File(key='input', file_type="Json"))
@Component.params(StringOfDict(key=["tag_name", "return_timestamp", "timestamp_format"]))
@Component.outputs(Csv(key='output'))
def collect_trend_db_data(**kwargs):
    global new_kwargs
    new_kwargs = kwargs.copy()
    output = get_trend_db_data(kwargs)
    return {'output': output}


if __name__ == '__main__':
    App.run(collect_trend_db_data)
