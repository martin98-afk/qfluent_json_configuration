"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: gk_update.py
@time: 2025/3/3 16:29
@desc: 
"""
import copy
import datetime
import os
import shutil
import sys

import numpy as np
import pandas as pd
from loguru import logger

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import File, StringOfDict
from sushineAI.component import Component
from sushineAI.app import App


def squeeze_work_condition(work_condition):
    squeezed_work_condition = []
    for value in work_condition:
        value = eval(value) if isinstance(value, str) else value
        if isinstance(value, list):
            squeezed_work_condition.extend(value)
        else:
            squeezed_work_condition.append(value)

    return squeezed_work_condition


def cell_changed(a, b, *, atol=1e-5, rtol=1e-5) -> bool:
    """
    如果 a 和 b 都能转成数值数组，就用 allclose 判断是否在误差范围内；
    否则退回到普通的 != 比较。
    """
    try:
        # 尝试把 a, b 转成 numpy 数组
        arr_a = np.array(a, dtype=float)
        arr_b = np.array(b, dtype=float)
        # 如果两者形状都适合做 allclose，就比较
        if arr_a.shape == arr_b.shape:
            return not np.allclose(arr_a, arr_b, atol=atol, rtol=rtol, equal_nan=True)
    except Exception:
        pass

    # 其他情况，退回到最简单的 !=
    return a != b


def update_gk_from_xlsx(saved_gk_xlsx_df, updated_xlsx_df, update_time):
    """
    :param saved_gk_xlsx_df: 本地存储最后更新xlsx记录
    :param updated_xlsx_df: 最新手动更新工况xlsx文件
    :param update_time: 更新时间
    """
    out_excel_sheets = {}
    for sheet_name in updated_xlsx_df:
        df_update = updated_xlsx_df.get(sheet_name)
        df_saved = saved_gk_xlsx_df.get(sheet_name)

        # 特征列为 df.columns[:-6], 配置列为 df.columns[-6:-1], 最后更新时间列为 df.columns[-1]
        feat_cols = list(df_update.columns[:-6])
        conf_cols = list(df_update.columns[-6:-1])
        time_col = df_update.columns[-1]

        # 1. 将特征列设为索引，便于对齐
        df_update_i = df_update.set_index(feat_cols)
        df_sav_i = df_saved.set_index(feat_cols)

        # 2. 对已存在行，检查配置是否有变化
        for idx, row in df_update_i.iterrows():
            if idx in df_sav_i.index:
                # 如果任意一个配置字段与 saved 不同，则进行更新
                changed = any(
                    cell_changed(row[col], df_sav_i.at[idx, col])
                    for col in conf_cols
                )
                if changed:
                    print(df_sav_i.loc[idx])
                    df_sav_i.loc[idx, conf_cols] = row[conf_cols]
                    df_sav_i.loc[idx, time_col] = update_time  # 更新时间
                    print(df_sav_i.loc[idx])
            else:
                # 3. 如果是新特征，直接追加
                new_row = row.copy()
                new_row[time_col] = update_time
                df_sav_i = pd.concat([df_sav_i, pd.DataFrame([new_row], index=[idx], columns=df_sav_i.columns)])

        # 4. 恢复原来的索引
        df_out = df_sav_i.reset_index()
        df_out.columns = feat_cols + conf_cols + [time_col]
        logger.info(df_out.info())
        # 5. 保存到新的测点表
        out_excel_sheets[sheet_name] = df_out
    
    return out_excel_sheets


def update_gk_json(gk_json, updated_xlsx_df):
    for sheet_name in updated_xlsx_df:
        df = updated_xlsx_df.get(sheet_name)
        _ori_gk = copy.deepcopy(gk_json[df.columns[0]])
        gk_em = eval([key for key in _ori_gk][0])
        # 将范围转换成数值
        work_conditions = df.iloc[:, 1:(len(gk_em) + 1)].values.tolist()
        new_squeezed_work_conditions = np.array(
            [squeeze_work_condition(work_condition) for work_condition in work_conditions]
        )
        # 开始匹配工况
        include_index = []
        for key in _ori_gk:
            if key == "all": continue
            work_condition = eval(key)
            squeezed_work_condition = squeeze_work_condition([item[1] for item in work_condition])
            squeezed_work_condition = np.repeat(
                np.array(squeezed_work_condition).reshape(1, -1), new_squeezed_work_conditions.shape[0],
                axis=0
            )
            index = np.where(
                np.sum(np.abs(new_squeezed_work_conditions - squeezed_work_condition), axis=1) < 1e-2)[0]
            # 如果没有匹配工况或者工况寻优范围没有变化，则不进行更新
            if len(index) == 0:
                continue
            else:
                index = int(index[0])
                include_index.append(index)
                if abs(df.iloc[index, -6] - gk_json[df.columns[0]][key][0]) < 1e-3 and \
                        abs(df.iloc[index, -5] - gk_json[df.columns[0]][key][1]) < 1e-3:
                    continue
                try:
                    # print(gk_json[df.columns[0]][key])
                    gk_json[df.columns[0]][key] = [
                        float(df.iloc[index, -6]),
                        float(df.iloc[index, -5]),
                        float(df.iloc[index, -4]),
                        float(df.iloc[index, -3]),
                        float(df.iloc[index, -2]),
                        df.iloc[index, -1]
                    ]
                except:
                    logger.info(df.iloc[index])

        # 更新新出现的工况
        for i in range(len(df)):
            if i in include_index: continue
            key = str(
                [
                    [column, eval(value)] if isinstance(value, str) else [column, value]
                    for column, value in zip(df.columns[1:-5], work_conditions[i])
                ]
            ).replace("'", "\"")
            gk_json[df.columns[0]][key] = [
                float(df.iloc[i, len(gk_em) + 1]),
                float(df.iloc[i, len(gk_em) + 2]),
                float(df.iloc[i, len(gk_em) + 3]),
                float(df.iloc[i, len(gk_em) + 4]),
                float(df.iloc[i, len(gk_em) + 5]),
                df.iloc[i, len(gk_em) + 6]
            ]

    return gk_json


@Component.inputs(File(key="input1", file_type="Any"), File(key="input2", file_type="Json"))
@Component.params(StringOfDict(key=["clear_cache"]))
@Component.outputs(File(key="output", file_type="Json"))
def main(**kwargs):
    current_time = (datetime.datetime.now() + datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
    new_gk = kwargs.get('input1').name
    ori_gk = kwargs.get("input2")
    res_json = {}
    if new_gk.endswith(".json"):
        with open(new_gk, "r") as f:
            import json
            new_gk = json.load(f)
        res_json = {ori_gk[key] | new_gk[key] if key in new_gk else ori_gk[key] for key in ori_gk}
    elif new_gk.endswith(".xlsx"):
        # 获取本地存储工况xlsx
        updated_xlsx_df = pd.read_excel(new_gk, sheet_name=None)
        current_path = os.getcwd()
        current_path = current_path.replace("/opt/", "/")
        if int(kwargs.get("clear_cache")) and os.path.exists(current_path):
            shutil.rmtree(current_path)
        os.makedirs(current_path, exist_ok=True)
        local_file_list = os.listdir(current_path)
        print(local_file_list)
        save_file_name = 'saved_gk.xlsx'
        saved_gk_path = os.path.join(current_path, save_file_name)
        print(saved_gk_path)
        updated_gk_excel = {}
        if save_file_name in local_file_list:  # 有历史修改记录,读取后融合更新
            saved_gk_xlsx_df = pd.read_excel(saved_gk_path, sheet_name=None)
            updated_gk_excel = update_gk_from_xlsx(saved_gk_xlsx_df, updated_xlsx_df, current_time)
        else:  # 第一次修改,直接将updated_gk_excel所有时间更新为最新时间,存储本地时不使用updated_gk_excel所以不受影响
            for sheet_name in updated_xlsx_df:
                df_update = updated_xlsx_df.get(sheet_name)
                df_update.iloc[:, -1] = current_time
                updated_gk_excel[sheet_name] = df_update

        final_gk_json = update_gk_json(ori_gk, updated_gk_excel)
        res_json = copy.deepcopy(final_gk_json)
        # 更新本地工况xlsx
        output_dict = {}
        for key in final_gk_json:
            output_dict[key] = []
            final_gk_json[key].pop("all")
            for lkey, value in final_gk_json[key].items():
                lkey = eval(lkey)
                dicts = {key: 0}
                dicts.update({l[0]: l[1] for l in lkey})
                if len(value) != 6:
                    value.append(current_time)
                dicts["寻优下限"] = value[0]
                dicts["寻优上限"] = value[1]
                dicts["历史数据均值"] = value[2]
                dicts["历史数据方差"] = value[3]
                dicts["历史数据量"] = value[4]
                dicts["工况更新时间"] = value[5]

                output_dict[key].append(dicts)

            columns = [key] + [l[0] for l in lkey] + ["寻优下限", "寻优上限", "历史数据均值", "历史数据方差",
                                                      "历史数据量",
                                                      "工况更新时间"]
            output_dict[key] = pd.DataFrame(output_dict[key], columns=columns)

        with pd.ExcelWriter(saved_gk_path, engine='openpyxl') as writer:
            for sheet_name, data in output_dict.items():
                # 写入对应的 sheet
                data.to_excel(writer, sheet_name=sheet_name, index=False)
        print(os.listdir(current_path))
    return {'output': res_json}


if __name__ == '__main__':
    App.run(main)
