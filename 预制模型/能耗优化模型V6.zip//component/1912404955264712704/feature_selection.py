"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: feature_selection.py
@time: 2025/4/16 15:15
@desc: 
"""

import os
import json
import shutil

import numpy as np
from loguru import logger
from scipy.stats import pearsonr

from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv, StringOfDict
from sushineAI.argument import File


def default_dump(obj):
    """Convert numpy classes to JSON serializable objects."""
    if isinstance(obj, (np.integer, np.floating, np.bool_)):
        return obj.item()
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    else:
        return obj


@Component.inputs(Csv(key="control"), Csv(key="feature"), File(key="model_params", file_type="Json"))
@Component.params(StringOfDict(key=["threshold", "remove"]))
@Component.outputs(Csv(key="feature"), File(key="model_params", file_type="Json"))
def main_business(**kwargs):
    control = kwargs.get('control')
    feature = kwargs.get('feature')
    model_params = kwargs.get('model_params')
    feature.columns = [
        f"{column}\n{name}" if len(name) > 0 else column
        for column, name in zip(feature.columns, model_params.get("feature_vars_name"))
    ]
    threshold = eval(kwargs.get("threshold"))
    # 读取已保存结果
    current_path = os.getcwd()
    logger.info(current_path)
    current_path = current_path.replace("/opt/", "/")
    if (not model_params.get("keep") or int(kwargs.get("remove"))) and os.path.exists(current_path):
        shutil.rmtree(current_path)
    os.makedirs(current_path, exist_ok=True)
    if os.path.exists(os.path.join(current_path, "feature.json")) and model_params.get("keep"):
        logger.info("读取到原训练结果，结果保留!")
        with open(os.path.join(current_path, "feature.json"), "r") as f:
            select_coef = json.load(f)
            select_index = [i for i in range(len(feature.columns)) if feature.columns[i] in select_coef["columns"] or feature.columns[i].split("\n")[1] in select_coef["columns"]]
    else:
        select_coef = {}
        select_index = []
        for i, column in enumerate(feature.columns):
            for j, c_column in enumerate(control.columns):
                coef, p_value = pearsonr(feature[column], control[c_column])
                logger.info(f"特征参数：{column}, 控制参数：{c_column}，相关系数：{coef}, 方差：{control[c_column].std()}")
                if abs(coef) >= threshold:
                    coef = coef if coef else 0
                    column_name = column.split("\n")[1] if "\n" in column else column
                    select_coef[column_name] = max(abs(coef), select_coef.get(column_name, 0))
                    if i not in select_index:
                        select_index.append(i)

    if len(select_index) != 0:
        feature = feature.iloc[:, select_index]
        for key in model_params:
            if key.startswith("feature_vars") and isinstance(model_params[key], list):
                model_params[key] = [item for i, item in enumerate(model_params[key]) if i in select_index]
    else:
        raise Exception("工况测点全部剔除，请检查数据质量或者过滤阈值")

    model_params["feature_weights"] = select_coef
    if model_params.get("keep"):
        with open(os.path.join(current_path, "feature.json"), "w") as f:
            select_coef["columns"] = [item.split("\n")[1] if "\n" in item else item for item in feature.columns.tolist()]
            json.dump(select_coef, f, ensure_ascii=False)
    feature.columns = [item.split("\n")[0] for item in feature.columns.tolist()]
    return {
        'feature': feature,
        'model_params': json.loads(json.dumps(model_params, ensure_ascii=False, default=default_dump))
    }


if __name__ == '__main__':
    App.run(main_business)
