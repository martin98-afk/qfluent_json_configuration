"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: smoke_area_detect_loader.py
@time: 2025/3/11 17:19
@desc:
"""
from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.component import Component


MODEL_LOADER = '''"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: model_loader.py
@time: 2025/3/5 9:15
@desc: 智能模型加载与推理引擎（内存优化版）
"""
import sys
import json
import os
import re
import math
import threading
import time
import tempfile
import contextlib
from concurrent.futures import ThreadPoolExecutor

import anyio
import optuna
import joblib
import zipfile
import numpy as np
import pandas as pd
import datetime
import warnings
from collections import defaultdict
from typing import Dict, List, Any, Tuple, Optional
from fontTools import unicodedata
from loguru import logger
from pydantic.dataclasses import dataclass
from sushineAI.services import Processor
from trenddb_client.v4 import TrendDBClient as TrendDBClientV4
from trenddb_client.v5 import TrendDBClient as TrendDBClientV5

# 局部抑制 warnings，避免全局污染
warnings.filterwarnings("ignore")
with warnings.catch_warnings():
    np.warnings = warnings
    optuna.logging.disable_default_handler()

TIME_FEATURES = {
    'year': lambda dt: dt.year,
    'month': lambda dt: dt.month,
    'week': lambda dt: dt.week,
    'day': lambda dt: dt.day,
    'hour': lambda dt: dt.hour,
    'minute': lambda dt: dt.minute,
    'second': lambda dt: dt.second,
    'day_of_week': lambda dt: dt.dayofweek,
    'day_of_year': lambda dt: dt.dayofyear,
    'day&night': lambda dt: int(6 <= dt.hour <= 17)
}


class ModelConfig:
    arbitrary_types_allowed = True


@dataclass(config=ModelConfig)
class ModelInstance:
    model_param: Dict[str, Any]
    feature_columns: List[str]
    control_columns: List[str]
    smoke_columns: List[str]
    target_models: Dict[str, Any]
    gmm_model: Any
    target: Dict[str, Dict]
    params_space: Dict[str, Dict]
    search_dist: Dict[str, Dict]  # 工况及对应的寻优范围
    automatic_weight: Dict[str, float]  # 模型训练时自动计算的目标权重值


class TrendDBManager:
    """时序数据库管理器（优化错误处理与顺序保持）"""

    def __init__(self, trenddb_ip: str, trenddb_port: int, trenddb_version: str,
                 trenddb_username: str = None, trenddb_password: str = None, trenddb_name: str = None, *args, **kwargs):
        client_cls = TrendDBClientV5 if trenddb_version == "v5" else TrendDBClientV4
        if trenddb_version == "v5":
            self.tc = client_cls(trenddb_ip, trenddb_port, trenddb_username, trenddb_password, dbname=trenddb_name)
        else:
            self.tc = client_cls(trenddb_ip, trenddb_port)

    def close(self):
        """释放数据库连接（若客户端支持）"""
        if hasattr(self.tc, 'close'):
            self.tc.close()
        elif hasattr(self.tc, '_session') and self.tc._session:
            self.tc._session.close()

    @staticmethod
    def _convert_time(utc: float) -> str:
        return datetime.datetime.fromtimestamp(utc).strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def _merge_time_ranges(ranges: List[List]) -> List[List]:
        """时间段去重"""
        sorted_ranges = sorted(ranges, key=lambda x: x[0])
        merged = []
        for start, end, interval in sorted_ranges:
            if merged and merged[-1][1] >= start and merged[-1][2] == interval:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end, interval])
        return merged

    def __safe_fetch(self, tags: List[str], start: int, end: int, interval: int) -> Dict:
        """带重试机制的数据获取"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = self.tc.get_history_values_by_period(
                    tags, start, end, interval * 1000
                )
                if not response:
                    raise ValueError(f"Empty response for tags: {tags}")
                return response
            except Exception as e:
                if attempt == max_retries - 1:
                    logger.error(f"数据获取失败: {str(e)}")
                    raise
                logger.warning(f"第 {attempt + 1} 次重试...")
                time.sleep(2 ** attempt)

    def _fetch_data(self, tags: List[str], start: int, end: int, interval: int) -> Dict:
        """带校验的数据处理"""
        try:
            response = self.__safe_fetch(tags, start, end, interval)
            base_data = {
                "timestamp": [item.utc_time for item in response[tags[0]]]
            }

            # 保持原始顺序的去重处理
            seen = set()
            ordered_tags = [t for t in tags if not (t in seen or seen.add(t))]

            return {
                tag: [item.value if not isinstance(item.value, bool) else int(item.value) for item in response[tag]]
                for tag in ordered_tags
            } | base_data

        except KeyError as e:
            logger.error(f"响应数据缺少必要字段: {str(e)}")
            raise
        except Exception as e:
            logger.critical("数据处理发生不可恢复错误!")
            raise RuntimeError(f"Data processing failed: {str(e)}") from e

    def load_dataset(self, date_ranges: List[List], tags: List[str]) -> pd.DataFrame:
        """强化版数据加载方法"""
        try:
            seen = set()
            ordered_tags = [t for t in tags if not (t in seen or seen.add(t))]

            data = {tag: [] for tag in ordered_tags}
            data["timestamp"] = []

            for i, (start_str, end_str, interval) in enumerate(date_ranges):
                if not self.__validate_time_format(start_str) or not self.__validate_time_format(end_str):
                    raise ValueError(f"时间格式错误于第{i}组参数: {start_str} - {end_str}")

            merged_ranges = self._merge_time_ranges(date_ranges)

            for start_str, end_str, interval in merged_ranges:
                start_utc = self.__time_to_utc(start_str)
                end_utc = self.__time_to_utc(end_str)

                if start_utc >= end_utc:
                    raise ValueError(f"无效时间范围: {start_str} > {end_str}")

                raw_data = self._fetch_data(
                    [t for t in ordered_tags if t not in TIME_FEATURES],
                    start_utc,
                    end_utc,
                    interval
                )

                sample_size = len(raw_data["timestamp"])
                if sample_size == 0:
                    logger.warning(f"空数据区间: {start_str} - {end_str}")
                    continue

                for tag in ordered_tags:
                    try:
                        if tag in TIME_FEATURES:
                            values = self._get_time_features(tag, start_str, sample_size)
                        else:
                            values = raw_data.get(tag, [])

                        if not values:
                            logger.error(f"测点 {tag} 无有效数据")
                            values = [np.nan] * sample_size

                        data[tag].extend(values if len(values) == sample_size
                                         else self.__align_data(values, sample_size))

                    except Exception as e:
                        logger.error(f"处理测点 {tag} 时发生错误: {str(e)}")
                        data[tag].extend([np.nan] * sample_size)

                data["timestamp"].extend(raw_data["timestamp"])

            return self.__build_dataframe(data)[ordered_tags]

        except Exception as e:
            logger.error("数据加载整体失败!")
            raise

    def get_realtime_data(self, tags: List[str]) -> Dict[str, float]:
        """
        参考第二个脚本，使用 get_realtime_values 获取当前最新点位值
        """
        try:
            # 调用底层客户端的实时接口
            response = self.tc.get_realtime_values(tags)
            result = {}

            for tag in tags:
                if tag in response:
                    # 兼容不同版本的返回格式：有些返回对象，有些返回字典
                    item = response[tag]
                    val = getattr(item, 'value', None)
                    if val is None and isinstance(item, dict):
                        val = item.get('value')

                    # 布尔值转数值处理
                    if isinstance(val, bool):
                        val = int(val)

                    result[tag] = val if val is not None else np.nan
                else:
                    logger.warning(f"测点 {tag} 未在实时响应中找到")
                    result[tag] = np.nan
            return result
        except Exception as e:
            logger.error(f"获取实时数据异常: {e}")
            return {tag: np.nan for tag in tags}

    @staticmethod
    def __validate_time_format(time_str: str) -> bool:
        try:
            datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
            return True
        except ValueError:
            return False

    @staticmethod
    def __time_to_utc(time_str: str) -> int:
        try:
            dt = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
            return int(dt.timestamp())
        except ValueError as e:
            logger.error(f"时间格式错误: {time_str}")
            raise

    @staticmethod
    def __align_data(values: List, target_length: int) -> List:
        if len(values) == 0:
            return [np.nan] * target_length
        if len(values) > target_length:
            logger.warning(f"数据截断: {len(values)} -> {target_length}")
            return values[:target_length]
        logger.warning(f"数据填充: {len(values)} -> {target_length}")
        return values + [values[-1]] * (target_length - len(values))

    def __build_dataframe(self, data: Dict) -> pd.DataFrame:
        try:
            df = pd.DataFrame(data)
            df.sort_values('timestamp', inplace=True)

            if df.timestamp.duplicated().any():
                logger.warning("发现重复时间戳，执行去重")
                df = df[~df.timestamp.duplicated(keep='first')]

            df.reset_index(drop=True, inplace=True)
            df.set_index('timestamp', inplace=True)

            missing_ratio = df.isna().mean()
            if (missing_ratio > 0.3).any():
                problematic = missing_ratio[missing_ratio > 0.3].index.tolist()
                logger.warning(f"高缺失率测点: {problematic}")

            return df
        except Exception as e:
            logger.error("DataFrame构建失败!")
            raise RuntimeError("Data processing failed at final stage") from e

    def _get_time_features(self, feature: str, start_str: str, sample_size: int) -> List:
        start_str = (datetime.datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")+ datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logger.info(start_str)
        dt = pd.Timestamp(start_str)
        logger.info(dt)
        return [TIME_FEATURES[feature](dt)] * sample_size


class ModelLoader:
    """模型加载工厂（安全文件读取）"""

    @staticmethod
    def _load_torch(path):
        torch = __import__('torch')
        return torch.jit.load(path)

    @staticmethod
    def _load_json(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    @staticmethod
    def _load_csv(path):
        return pd.read_csv(path, index_col=0)

    LOADERS = {
        'torch': _load_torch.__func__,
        'joblib': joblib.load,
        'json': _load_json.__func__,
        'csv': _load_csv.__func__,
    }

    @classmethod
    def load(cls, model_list: List[Dict], base_dir: str) -> Dict:
        model_dict = {}
        for model in model_list:
            if isinstance(model["path"], list):
                file_names = [".".join(os.path.basename(p).split(".")[:-1]) for p in model["path"]]
                model_dict[model["name"]] = {
                    file_name: cls.LOADERS[model["type"]](os.path.join(base_dir, model_path))
                    for model_path, file_name in zip(model["path"], file_names)
                }
            else:
                full_path = os.path.join(base_dir, model["path"])
                model_dict[model["name"]] = cls.LOADERS[model["type"]](full_path)
        return model_dict


class OptimizationEngine:
    """参数优化引擎（无状态、用完即弃）"""

    def __init__(self, model: ModelInstance):
        self.model = model
        self.data = None

    def _create_trial(self, param_space: Dict) -> callable:
        def objective(trial: optuna.Trial) -> List[float]:
            params = np.array([
                trial.suggest_float(f"act{i}", *space[1:])
                for i, space in enumerate(param_space.values())
            ])[None]

            frequence_params = params[0, np.where(np.array(self.model.model_param["control_vars_type"]) == "统一频率")]
            losses = [np.sqrt(np.sum((frequence_params - np.mean(frequence_params)) ** 2))] if len(frequence_params) > 0 else [0]

            for key in self.model.automatic_weight:
                pred = self.model.target_models[key].predict(np.hstack([params, self.data]))[0]
                losses.append(
                    self.model.automatic_weight[key] * abs(pred - self.model.target[key]["target"]) +
                    1e4 * (pred <= self.model.target[key].get("lower_bound", -np.inf)) +
                    1e4 * (pred >= self.model.target[key].get("upper_bound", np.inf))
                )
            return losses
        return objective

    def optimize(
        self, data: np.ndarray, param_space: Dict, timeout: float = 1.0
    ) -> List[float]:
        self.data = data
        study = optuna.create_study(
            directions=["minimize"] * (1 + len(self.model.target))
        )
        self._last_valid_params = None
        self._last_valid_values = float("inf")

        def callback(study: optuna.Study, trial: optuna.Trial):
            if trial.values is not None:
                trial_loss = sum(trial.values)
                if trial_loss < self._last_valid_values:
                    self._last_valid_values = trial_loss
                    self._last_valid_params = {k: v for k, v in trial.params.items()}

        try:
            logger.info("开始优化")
            study.optimize(
                self._create_trial(param_space),
                n_trials=20,
                n_jobs=1,
                timeout=timeout,
                callbacks=[callback],
            )
            best_trial = min(study.best_trials, key=lambda t: sum(t.values))
            logger.info(
                f"优化完成，最佳loss: {sum(best_trial.values)}, 参数: {[best_trial.params.get(f'act{i}') for i in range(len(param_space))]}"
            )
            del study
            return [best_trial.params[f"act{i}"] for i in range(len(param_space))]
        except Exception:
            logger.error("参数优化失败")
            if self._last_valid_params is not None:
                return [
                    self._last_valid_params.get(f"act{i}", 0.0)
                    for i in range(len(param_space))
                ]


class TableLogger:
    @staticmethod
    def char_width(char):
        if unicodedata.east_asian_width(char) in ('F', 'W', 'A'):
            return 2
        return 1

    @staticmethod
    def str_display_width(s):
        return sum(TableLogger.char_width(c) for c in s)

    @staticmethod
    def ljust_with_width(s, width):
        current_width = TableLogger.str_display_width(s)
        pad = width - current_width
        return s + ' ' * pad

    @staticmethod
    def format_row(row, widths):
        return "| " + " | ".join(TableLogger.ljust_with_width(cell, w) for cell, w in zip(row, widths)) + " |"

    @staticmethod
    def format_separator(widths):
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"


class Model(Processor):
    """智能模型主类（支持资源释放）"""

    def __init__(self):
        super().__init__()
        self._last_control = None
        self._last_active_time = datetime.datetime.now()
        self._smoke_feedback_active = False
        self._last_update = datetime.datetime.min
        self._last_gk = None
        self._smoke_executor = ThreadPoolExecutor(max_workers=1)
        self._smoke_task_running = False
        self._smoke_lock = threading.Lock()
        self.db: Optional[TrendDBManager] = None
        self.model: Optional[ModelInstance] = None
        self.smoke_feedback_id = None
        self.smoke_threshold = []
        self.params = {}
        self._setup_logging()

    def _setup_logging(self):
        """配置日志：同时输出到终端和本地文件，按天滚动"""
        log_dir = "logs"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # 移除 loguru 默认的终端输出（如果想自定义格式的话）
        logger.remove()

        # 1. 添加终端输出 (控制台)
        logger.add(
            sys.stdout,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
            level="INFO"
        )

        # 2. 添加文件输出 (按天滚动)
        log_file_path = os.path.join(log_dir, "model_service_{time:YYYY-MM-DD}.log")
        logger.add(
            log_file_path,
            rotation="00:00",  # 每天午夜 0 点切换新文件
            retention="30 days",  # 日志保留 30 天，防止磁盘撑爆
            compression="zip",  # 旧日志自动压缩成 zip 节省空间
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            encoding="utf-8",
            enqueue=True,  # 开启异步写入，不影响主线程推理性能
            level="DEBUG"  # 文件中保存更详细的 DEBUG 日志
        )
        logger.info("日志系统初始化完成：按天滚动存储于 logs/ 目录")

    def load(self, model_path: str):
        """加载模型（安全解压 + 资源初始化）"""
        with tempfile.TemporaryDirectory() as tmpdir:
            with zipfile.ZipFile(model_path) as zf:
                zf.extractall(tmpdir)
                param_file = os.path.join(tmpdir, "models", "model_params.json")
                with open(param_file, 'r', encoding='utf-8') as f:
                    self.params = json.load(f)

            # 解析烟雾超限统计
            self.smoke_feedback_id = self.params["original_params"].get("烟雾反馈存储id")
            self.params["smoke_vars"] = []
            self.smoke_threshold = []
            if self.params["original_params"].get("烟雾反馈参数"):
                for item in self.params["original_params"].get("烟雾反馈参数").values():
                    tag_name = item.get("测点名", "").split('\\n')[0]
                    if tag_name not in self.params["smoke_vars"]:
                        self.params["smoke_vars"].append(tag_name)
                        self.smoke_threshold.append(float(item.get("超限统计阈值", 0.0)))

            db_name = self.params.get("trenddb_name")
            self.params = {
                key: value if not key.endswith("vars") else self._format_columns(value, db_name)
                for key, value in self.params.items()
            }

            components = ModelLoader.load(
                model_list=[
                    {"name": "automatic_weight", "path": 'models/target_weight.json', "type": "json"},
                    {"name": "target_models", "path": [f'models/{var}.m' for var in self.params["target_vars"]], "type": "joblib"},
                    {"name": "gmm_model", "path": 'models/gmm.m', "type": "joblib"},
                    {"name": "search_dist", "path": 'models/search_dist.json', "type": "json"},
                    {"name": "target", "path": 'models/target.json', "type": "json"}
                ],
                base_dir=tmpdir
            )

            self.model = ModelInstance(
                model_param=self.params,
                feature_columns=self.params["feature_vars"],
                control_columns=self.params["control_vars"],
                smoke_columns=self.params["smoke_vars"],
                params_space=self._build_param_space(components["search_dist"], self.params),
                **components
            )

        # 初始化数据库连接（仅一次）
        self.db = TrendDBManager(**self.model.model_param)

    def close(self):
        """释放所有资源"""
        if self.db:
            self.db.close()
        if self._smoke_executor:
            self._smoke_executor.shutdown(wait=False)
            self._smoke_executor = None

    def predict(self, data: List[str]) -> List[float]:
        # if self.smoke_feedback_id is not None:
        #     self._trigger_smoke_count()

        result = self._run_optimization(data)
        current_time = datetime.datetime.now()

        if self._last_control is None:
            self._update_state(result, current_time, "normal_control")
            return self._format_result(result)

        update_condition = result["gk"] != self._last_gk
        if update_condition:
            self._update_state(result, current_time, "normal_control")
        else:
            result["control"] = self._last_control

        return self._format_result(result)

    def _run_optimization(self, data: List[str]) -> Dict:
        if len(data) == 0:
            data = self._fetch_realtime_data(self.db, self.params["feature_vars"] + self.model.model_param["feature_weights"]["columns"][len(self.params["feature_vars"]):])
            self.control_data = np.squeeze(self._fetch_realtime_data(self.db, self.model.control_columns))
        elif len(data) == 1:
            data = self._fetch_realtime_data(self.db, self.params["feature_vars"] + self.model.model_param["feature_weights"]["columns"][len(self.params["feature_vars"]):], data[0])
        elif len(data) == len(self.params["feature_vars"]):
            data = np.array([data])
        else:
            raise ValueError("Invalid input data length!")

        self._last_active_time = datetime.datetime.now()
        threshold = float(self.model.model_param["original_params"].get("新工况判断阈值", 1.5)) * np.mean(
            [v for v in self.model.model_param["feature_weights"].values() if isinstance(v, (float, int))]
        )

        gk_info = self._match_operating_condition(data, threshold)
        optimized_params = OptimizationEngine(self.model).optimize(data, gk_info["param_space"])

        return {
            "control": self._apply_noise(optimized_params),
            "predict": self._get_predictions(optimized_params, data),
            "gk": gk_info["id"]
        }

    def _update_state(self, result: Dict, timestamp: datetime.datetime, state: str):
        self._last_control = result["control"]
        self._last_update = timestamp
        self._last_gk = result["gk"]
        self.state = state
        logger.debug(f"状态已更新｜时间：{timestamp}")

    def _should_add_noise(self) -> bool:
        return (
            self.model.model_param.get('add_noise', False) and
            np.random.random() > 0.9
        )

    def _apply_noise(self, control_params: List[float]) -> List[float]:
        if self._should_add_noise():
            noise = 0.03 * np.random.randn(len(control_params))
            return [p * (1 + n) for p, n in zip(control_params, noise)]
        return control_params

    def _format_columns(self, variable_names: List[str], prefix: str) -> List[str]:
        return [
            f"{prefix}.{item}" if not item.startswith(f"{prefix}.") and item not in TIME_FEATURES else item
            for item in variable_names
        ]

    def _build_param_space(self, search_dist: Dict, params: Dict) -> Dict:
        distribution_type = "normal" if params.get('distance_function') == 'normal' else "uniform"
        params_space = defaultdict(dict)
        for i, var in enumerate(params["control_vars"]):
            for gk in search_dist[var]:
                bound1 = float(search_dist[var][gk][0])
                bound2 = float(search_dist[var][gk][1])
                params_space[gk][f"act{i}"] = [distribution_type, bound1, bound2]
        return dict(params_space)

    def _fetch_realtime_data(self, db: TrendDBManager, columns: List[str], time_str: str = "") -> np.ndarray:
        """
        优化后的实时数据获取：
        1. 如果提供了具体时间字符串，则使用历史查询逻辑。
        2. 否则，直接使用高效的实时值接口。
        """
        # 如果传入了特定时间点，仍然需要走历史查询逻辑（因为 get_realtime_values 只给当前时刻）
        if len(time_str) > 0:
            now = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
            time_range = [[
                (now - datetime.timedelta(seconds=1)).strftime("%Y-%m-%d %H:%M:%S"),
                now.strftime("%Y-%m-%d %H:%M:%S"),
                1
            ]]
            return db.load_dataset(time_range, columns).values[-1:]

        db_tags = [t for t in columns if t not in TIME_FEATURES]
        realtime_values_dict = db.get_realtime_data(db_tags)

        # 获取当前时间字符串，用于传给 _get_time_features
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        final_row = []
        for col in columns:
            if col in TIME_FEATURES:
                # --- 直接复用你原来的逻辑 ---
                # _get_time_features 返回的是 List，实时模式下 sample_size 为 1，取第一个值即可
                time_val = db._get_time_features(col, now_str, 1)[0]
                final_row.append(time_val)
            else:
                # 原始测点从实时响应字典中获取
                final_row.append(realtime_values_dict.get(col, np.nan))

        return np.array([final_row])

    def _trigger_smoke_count(self):
        with self._smoke_lock:
            if not self._smoke_task_running:
                self._smoke_task_running = True
                self._smoke_executor.submit(self._count_smoke_task)

    def _count_smoke_task(self):
        try:
            self._execute_smoke_count()
        except Exception as e:
            logger.error(f"烟雾统计失败: {e}")
        finally:
            with self._smoke_lock:
                self._smoke_task_running = False

    def _execute_smoke_count(self):
        try:
            if not self.smoke_feedback_id or not self.model.smoke_columns:
                return

            start_time = self._last_active_time
            end_time = datetime.datetime.now()
            end_day = start_time.date().strftime("%Y-%m-%d")
            fetch_seconds = (end_time - start_time).total_seconds()
            if fetch_seconds <= 0:
                return

            time_range = [[
                start_time.strftime("%Y-%m-%d %H:%M:%S"),
                end_time.strftime("%Y-%m-%d %H:%M:%S"),
                1
            ]]

            smoke_tags = self.model.smoke_columns
            feature_columns = self.model.feature_columns
            all_columns = list(set(feature_columns + smoke_tags))

            df = self.db.load_dataset(time_range, all_columns)
            if df.empty:
                return

            file_path = os.path.join("/opt", f"{self.smoke_feedback_id}.json")
            data = {}
            txt_path = os.path.join("/opt", f"{self.smoke_feedback_id}.txt")
            if os.path.exists(txt_path):
                with open(txt_path, "r", encoding='utf-8') as f:
                    data = json.load(f)
                os.remove(txt_path)
            if os.path.exists(file_path):
                try:
                    with open(file_path, "r", encoding='utf-8') as f:
                        data = json.load(f)
                except Exception:
                    pass

            for idx, row in df.iterrows():
                try:
                    feature_data = np.array([row[col] for col in feature_columns])[None, :]
                    threshold = float(self.model.model_param["original_params"].get("新工况判断阈值", 1.5)) * np.mean([
                        v for v in self.model.model_param["feature_weights"].values() if isinstance(v, (float, int))
                    ])
                    gk_info = self._match_operating_condition(feature_data, threshold, debug=False)
                    gk_id = str(gk_info["id"])

                    if gk_id not in data:
                        data[gk_id] = {end_day: defaultdict(list)}
                    if end_day not in data[gk_id]:
                        data[gk_id][end_day] = defaultdict(list)
                    for key in self.model.smoke_columns:
                        data[gk_id][end_day][key].append(0)
                    for smoke_col, threshold_value in zip(self.model.smoke_columns, self.smoke_threshold):
                        value = row[smoke_col]
                        if not pd.isna(value) and value > threshold_value:
                            data[gk_id][end_day][smoke_col][-1] += 1
                except Exception as e:
                    logger.warning(f"处理数据点失败: {e}")
                    continue

            with open(file_path, "w", encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)

            self._last_active_time = end_time
            logger.info(f"烟雾统计完成，处理了 {len(df)} 条数据")

        except Exception as e:
            logger.error(f"烟雾统计执行失败: {e}")

    def _match_operating_condition(self, data: np.ndarray, threshold: float = 0, debug: bool = True) -> Dict:
        if self.model.model_param["feature_type"] == "聚类匹配":
            cluster_id = self.model.gmm_model.predict(data)
            return {"id": str(cluster_id), "param_space": self.model.params_space[str(cluster_id)]}

        break_points = self.model.model_param.get("break_points", {})
        distances = {}
        for gk in self.model.params_space:
            if gk == "all":
                continue
            distance = 0
            # ⚠️ 高风险：使用 eval 解析工况字符串。建议模型保存时用 JSON list 替代字符串。
            try:
                gk_conditions = eval(gk)
            except Exception:
                logger.error(f"工况解析失败: {gk}")
                continue
            for i, (k, v) in enumerate(gk_conditions):
                v = eval(v) if isinstance(v, str) else v
                if isinstance(v, list):
                    if data[0][i] > v[1]:
                        distance += self.model.model_param["feature_weights"][k] * math.sqrt((v[1] - data[0][i]) ** 2) / (break_points[k][-1][-1] - break_points[k][0][0] + 1e-6)
                    elif data[0][i] < v[0]:
                        distance += self.model.model_param["feature_weights"][k] * math.sqrt((v[0] - data[0][i]) ** 2) / (break_points[k][-1][-1] - break_points[k][0][0] + 1e-6)
                else:
                    distance += self.model.model_param["feature_weights"][k] * math.sqrt((v - data[0][i]) ** 2)
            distances[gk] = distance

        if not distances:
            best_gk = "all"
            param_space = self.model.params_space[best_gk]
        else:
            best_gk = min(distances, key=distances.get)
            if distances[best_gk] > threshold:
                new_work_condition_control_type = self.model.model_param.get("original_params", {}).get("新工况控制模式")
                if new_work_condition_control_type == "全量工况":
                    best_gk = "all"
                    param_space = self.model.params_space[best_gk]
                elif new_work_condition_control_type == "三个最近工况高频":
                    best_gk_list = sorted(distances, key=distances.get)[:3]
                    gk_max = {
                        gk: self.model.params_space[gk]["act0"][-1]
                        for gk in best_gk_list if gk != "all"
                    }
                    best_gk = max(gk_max, key=gk_max.get) if gk_max else best_gk
                    param_space = self.model.params_space[best_gk]
                elif new_work_condition_control_type == "给定频率":
                    given_frequence_index = [
                        k for k, var_type in enumerate(self.model.model_param["control_vars_type"])
                        if re.search(r"频率", var_type)
                    ]
                    param_space = self.model.params_space[best_gk].copy()
                    for index in given_frequence_index:
                        param_space[f"act{index}"] = [
                            "uniform", self.control_data[index] - 0.1, self.control_data[index] + 0.1
                        ]
                else:
                    param_space = self.model.params_space[best_gk]
            else:
                param_space = self.model.params_space[best_gk]

        if debug and best_gk != "all" and best_gk in distances:
            rows = []
            try:
                gk_conditions = eval(best_gk)
                for real_data, (gk_name, gk_value) in zip(data[0], gk_conditions):
                    weight = self.model.model_param.get("feature_weights", {}).get(gk_name, 0)
                    gk_value_parsed = eval(gk_value) if isinstance(gk_value, str) else gk_value
                    if isinstance(gk_value_parsed, list):
                        if real_data < gk_value_parsed[0] or real_data > gk_value_parsed[1]:
                            real_data = f"**{real_data}**"
                    else:
                        if abs(real_data - gk_value_parsed) > 1e-2:
                            real_data = f"**{real_data}**"
                    rows.append((gk_name, str(real_data), str(gk_value_parsed), str(weight)))
                if rows:
                    headers = ["测点名", "实时值", "匹配值", "工况距离权重"]
                    column_widths = [TableLogger.str_display_width(h) for h in headers]
                    for row in rows:
                        for i, cell in enumerate(row):
                            cell_width = TableLogger.str_display_width(cell)
                            if cell_width > column_widths[i]:
                                column_widths[i] = cell_width
                    separator = TableLogger.format_separator(column_widths)
                    logger.info(separator)
                    logger.info(TableLogger.format_row(headers, column_widths))
                    logger.info(separator)
                    for row in rows:
                        logger.info(TableLogger.format_row(row, column_widths))
                    logger.info(separator)
            except Exception as e:
                logger.warning(f"工况日志打印失败: {e}")

        if debug and best_gk in self.model.params_space:
            for i, key in enumerate(self.model.search_dist):
                gk_data = self.model.search_dist[key].get(best_gk)
                if gk_data:
                    logger.info(
                        f"控制参数 {key} 的历史数据分布信息："
                        f"匹配工况历史均值：{gk_data[2]}, "
                        f"匹配工况历史标准差：{gk_data[3]}, "
                        f"匹配工况历史数据量：{gk_data[4]}"
                    )
                    act_key = f'act{i}'
                    if act_key in self.model.params_space[best_gk]:
                        bounds = self.model.params_space[best_gk][act_key]
                        logger.info(f"控制参数 {key} 的寻优范围：{bounds[1]} ~ {bounds[2]}")

        return {"id": best_gk, "param_space": param_space}

    def _apply_constraints(self, params: List[float]) -> List[float]:
        boundary = self.model.model_param.get("boundary", [])
        return [
            max(min(p, bound[1]), bound[0]) if len(bound) >= 2 else p
            for p, bound in zip(params, boundary)
        ]

    def _get_predictions(self, params: List[float], data: np.ndarray) -> List[float]:
        return [
            self.model.target_models[m].predict(np.hstack([np.array(params)[None], data]))[0]
            for m in self.params["target_vars"]
        ]

    def _format_result(self, result: Dict) -> List[float]:
        control = [
            round(p, 2) + float(param.get("偏移量", 0))
            for p, param in zip(
                result["control"], self.model.model_param.get("original_params", {}).get("控制参数", {}).values()
            )
        ]
        predictions = [round(p, 2) for p in result["predict"]]
        return self._apply_constraints(control) + predictions'''


@Component.outputs(File(key="loader_file.py", file_type="Any"))
def main_business(**kwargs):

    return {"loader_file.py": bytes(MODEL_LOADER, encoding="utf-8")}


if __name__ == '__main__':
    App.run(main_business)
