"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: smoke_area_detect_loader.py
@time: 2025/3/11 17:19
@desc:
"""
from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.component import Component

MODEL_LOADER = """
\"\"\"
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: model_loader.py
@time: 2025/3/5 9:15
@desc: 
\"\"\"
import json
import os
import re
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import anyio
import optuna
import joblib
import zipfile
import numpy as np
import pandas as pd
import datetime
import warnings
from collections import defaultdict
from typing import Dict, List, Any, Tuple
from fontTools import unicodedata
from loguru import logger
from pydantic.dataclasses import dataclass
from sushineAI.services import Processor
from trenddb_client.v4 import TrendDBClient as TrendDBClientV4
from trenddb_client.v5 import TrendDBClient as TrendDBClientV5

np.warnings = warnings
warnings.filterwarnings("ignore")
optuna.logging.disable_default_handler()

TIME_FEATURES = {
    'year': lambda dt: dt.year,
    'month': lambda dt: dt.month,
    'week': lambda dt: dt.week,
    'day': lambda dt: dt.day,
    'hour': lambda dt: dt.hour,
    'minute': lambda dt: dt.minute,
    'second': lambda dt: dt.second,
    'day_of_week': lambda dt: dt.dayofweek,
    'day_of_year': lambda dt: dt.dayofyear,
    'day&night': lambda dt: int(6 <= dt.hour <= 17)
}


class ModelConfig:
    arbitrary_types_allowed = True


@dataclass(config=ModelConfig)
class ModelInstance:
    model_param: Dict[str, Any]
    feature_columns: List[str]
    control_columns: List[str]
    smoke_columns: List[str]
    target_models: Dict[str, Any]
    gmm_model: Any
    target: Dict[str, Dict]
    params_space: Dict[str, Dict]
    search_dist: Dict[str, Dict]  # 工况及对应的寻优范围
    automatic_weight: Dict[str, float]  # 模型训练时自动计算的目标权重值


class TrendDBManager:
    \"\"\"时序数据库管理器（优化错误处理与顺序保持）\"\"\"

    def __init__(self, trenddb_ip: str, trenddb_port: int, trenddb_version: str,
                 trenddb_username: str = None, trenddb_password: str = None, trenddb_name: str = None, *args, **kwargs):
        client_cls = TrendDBClientV5 if trenddb_version == "v5" else TrendDBClientV4
        self.tc = client_cls(trenddb_ip, trenddb_port, trenddb_username, trenddb_password, dbname=trenddb_name) if trenddb_version == "v5" else client_cls(trenddb_ip, trenddb_port)

    @staticmethod
    def _convert_time(utc: float) -> str:
        return datetime.datetime.fromtimestamp(utc).strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def _merge_time_ranges(ranges: List[List]) -> List[List]:
        \"\"\"时间段去重\"\"\"
        sorted_ranges = sorted(ranges, key=lambda x: x[0])
        merged = []
        for start, end, interval in sorted_ranges:
            if merged and merged[-1][1] >= start and merged[-1][2] == interval:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end, interval])
        return merged

    def __safe_fetch(self, tags: List[str], start: int, end: int, interval: int) -> Dict:
        \"\"\"带重试机制的数据获取\"\"\"
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = self.tc.get_history_values_by_period(
                    tags, start, end, interval * 1000
                )
                if not response:
                    raise ValueError(f"Empty response for tags: {tags}")
                return response
            except Exception as e:
                if attempt == max_retries - 1:
                    logger.error(f"数据获取失败: {str(e)}")
                    raise
                logger.warning(f"第 {attempt + 1} 次重试...")
                time.sleep(2 ** attempt)

    def _fetch_data(self, tags: List[str], start: int, end: int, interval: int) -> Dict:
        \"\"\"带校验的数据处理\"\"\"
        try:
            response = self.__safe_fetch(tags, start, end, interval)
            base_data = {
                "timestamp": [item.utc_time for item in response[tags[0]]]
            }

            # 保持原始顺序的去重处理
            seen = set()
            ordered_tags = [t for t in tags if not (t in seen or seen.add(t))]

            return {
                tag: [item.value if not isinstance(item.value, bool) else int(item.value) for item in response[tag]]
                for tag in ordered_tags
            } | base_data

        except KeyError as e:
            logger.error(f"响应数据缺少必要字段: {str(e)}")
            raise
        except Exception as e:
            logger.critical("数据处理发生不可恢复错误!")
            raise RuntimeError(f"Data processing failed: {str(e)}") from e

    def load_dataset(self, date_ranges: List[List], tags: List[str]) -> pd.DataFrame:
        \"\"\"强化版数据加载方法\"\"\"
        try:
            # 原始顺序去重
            seen = set()
            ordered_tags = [t for t in tags if not (t in seen or seen.add(t))]

            data = {tag: [] for tag in ordered_tags}
            data["timestamp"] = []

            # 验证时间范围格式
            for i, (start_str, end_str, interval) in enumerate(date_ranges):
                if not self.__validate_time_format(start_str) or not self.__validate_time_format(end_str):
                    raise ValueError(f"时间格式错误于第{i}组参数: {start_str} - {end_str}")

            merged_ranges = self._merge_time_ranges(date_ranges)

            for start_str, end_str, interval in merged_ranges:
                start_utc = self.__time_to_utc(start_str)
                end_utc = self.__time_to_utc(end_str)

                if start_utc >= end_utc:
                    raise ValueError(f"无效时间范围: {start_str} > {end_str}")

                raw_data = self._fetch_data(
                    [t for t in ordered_tags if t not in TIME_FEATURES],
                    start_utc,
                    end_utc,
                    interval
                )

                sample_size = len(raw_data["timestamp"])
                if sample_size == 0:
                    logger.warning(f"空数据区间: {start_str} - {end_str}")
                    continue

                for tag in ordered_tags:
                    try:
                        if tag in TIME_FEATURES:
                            values = self._get_time_features(tag, start_str, sample_size)
                        else:
                            values = raw_data.get(tag, [])

                        if not values:
                            logger.error(f"测点 {tag} 无有效数据")
                            values = [np.nan] * sample_size

                        data[tag].extend(values if len(values) == sample_size
                                         else self.__align_data(values, sample_size))

                    except Exception as e:
                        logger.error(f"处理测点 {tag} 时发生错误: {str(e)}")
                        data[tag].extend([np.nan] * sample_size)

                data["timestamp"].extend(raw_data["timestamp"])

            return self.__build_dataframe(data)[ordered_tags]  # 保持标签原有顺序

        except Exception as e:
            logger.error("数据加载整体失败!")
            raise

    @staticmethod
    def __validate_time_format(time_str: str) -> bool:
        try:
            datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
            return True
        except ValueError:
            return False

    @staticmethod
    def __time_to_utc(time_str: str) -> int:
        \"\"\"时间转换的防御式处理\"\"\"
        try:
            dt = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
            return int(dt.timestamp())
        except ValueError as e:
            logger.error(f"时间格式错误: {time_str}")
            raise

    @staticmethod
    def __align_data(values: List, target_length: int) -> List:
        \"\"\"数据对齐策略\"\"\"
        if len(values) == 0:
            return [np.nan] * target_length
        if len(values) > target_length:
            logger.warning(f"数据截断: {len(values)} -> {target_length}")
            return values[:target_length]
        logger.warning(f"数据填充: {len(values)} -> {target_length}")
        return values + [values[-1]] * (target_length - len(values))

    def __build_dataframe(self, data: Dict) -> pd.DataFrame:
        \"\"\"DataFrame构建的健壮性处理\"\"\"
        try:
            df = pd.DataFrame(data)
            df.sort_values('timestamp', inplace=True)

            # 处理可能的重复时间戳
            if df.timestamp.duplicated().any():
                logger.warning("发现重复时间戳，执行去重")
                df = df[~df.timestamp.duplicated(keep='first')]

            df.reset_index(drop=True, inplace=True)
            df.set_index('timestamp', inplace=True)

            # 检查数据质量
            missing_ratio = df.isna().mean()
            if (missing_ratio > 0.3).any():
                problematic = missing_ratio[missing_ratio > 0.3].index.tolist()
                logger.warning(f"高缺失率测点: {problematic}")

            return df
        except Exception as e:
            logger.error("DataFrame构建失败!")
            raise RuntimeError("Data processing failed at final stage") from e

    def _get_time_features(self, feature: str, start_str: str, sample_size: int) -> List:
        start_str = (datetime.datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S") + datetime.timedelta(hours=8)).strftime(
            "%Y-%m-%d %H:%M:%S")
        dt = pd.Timestamp(start_str)
        return [TIME_FEATURES[feature](dt)] * sample_size


class ModelLoader:
    \"\"\"模型加载工厂\"\"\"

    LOADERS = {
        'torch': lambda p: __import__('torch').jit.load(p),
        'joblib': joblib.load,
        'json': lambda p: json.load(open(p)),
        'csv': lambda p: pd.read_csv(p, index_col=0)
    }

    @classmethod
    def load(cls, model_list: List[Dict]) -> Dict:
        model_dict = {}
        for model in model_list:
            if isinstance(model["path"], list):
                # 遇到列表类型文件路径，加载为以文件名为key的字典
                file_names = [".".join(model_path.split('/')[-1].split(".")[:-1]) for model_path in model["path"]]
                model_dict[model["name"]] = (
                    {
                        file_name: cls.LOADERS[model["type"]](model_path)
                        for model_path, file_name in zip(model["path"], file_names)
                    }
                )
            else:
                model_dict[model["name"]] = cls.LOADERS[model["type"]](model["path"])

        return model_dict


class OptimizationEngine:
    \"\"\"参数优化引擎\"\"\"

    def __init__(self, model: ModelInstance):
        self.model = model
        self.study = optuna.create_study(directions=['minimize'] + ['minimize'] * len(model.target))  # 多目标优化目标值

    def _create_trial(self, param_space: Dict) -> callable:
        \"\"\"构建目标函数\"\"\"

        def objective(trial: optuna.Trial) -> List[float]:
            params = np.array([
                trial.suggest_float(i, *space[1:])
                for i, space in param_space.items()
            ])[None]
            # 提取控制参数中为频率类型的参数，并增加
            frequence_params = params[0, np.where(np.array(self.model.model_param["control_vars_type"]) == "统一频率")]
            losses = [
                np.sqrt(np.sum((frequence_params - np.mean(frequence_params)) ** 2))
            ] if len(frequence_params) > 0 else [0]
            for key in self.model.automatic_weight:
                pred = self.model.target_models[key].predict(np.hstack([params, self.data]))[0]
                losses.append(
                    # 自动计算的平衡参数量权重 * abs（预测目标-目标值）+ 上下限惩罚权重
                    self.model.automatic_weight[key] * abs(pred - self.model.target[key]["target"]) +
                    1e4 * (pred <= self.model.target[key].get("lower_bound", -np.inf)) +
                    1e4 * (pred >= self.model.target[key].get("upper_bound", np.inf))
                )

            return losses

        return objective

    def optimize(self, data: np.ndarray, param_space: Dict) -> List[float]:
        self.data = data
        self.study.optimize(self._create_trial(param_space), n_trials=20, n_jobs=20)
        # 从帕累托解集中找到能耗指标和最小的最优解，默认能耗指标为优化目标为最小值的目标，环保指标一般为mean
        # energy_index = [index for index, value in enumerate(self.model.model_param["loss_target"]) if value == 'min']
        best_trial = min(self.study.best_trials, key=lambda t: sum(t.values))
        return [best_trial.params[f"act{i}"] for i in range(len(param_space))]


class TableLogger:

    @staticmethod
    def char_width(char):
        \"\"\"判断字符的显示宽度\"\"\"
        if unicodedata.east_asian_width(char) in ('F', 'W', 'A'):
            return 2  # 全角字符（如中文、日文、韩文）
        else:
            return 1  # 半角字符（如英文、数字）

    @staticmethod
    def ljust_with_width(s, width):
        current_width = TableLogger.str_display_width(s)
        pad = width - current_width
        return s + ' ' * pad

    @staticmethod
    def str_display_width(s):
        return sum(TableLogger.char_width(c) for c in s)

    @staticmethod
    def format_row(row, widths):
        return "| " + " | ".join(TableLogger.ljust_with_width(cell, w) for cell, w in zip(row, widths)) + " |"

    @staticmethod
    def format_separator(widths):
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"


class Model(Processor):
    \"\"\"智能模型主类\"\"\"

    def __init__(self):
        super().__init__()
        self._last_control = None
        self._last_active_time = datetime.datetime.now()
        self._smoke_feedback_active = False
        self._last_update = datetime.datetime.min
        self._last_gk = None
        self._smoke_executor = ThreadPoolExecutor(max_workers=1)  # 单线程执行
        self._smoke_task_running = False
        self._smoke_lock = threading.Lock()

    def load(self, model_path: str):
        \"\"\"加载模型\"\"\"
        with zipfile.ZipFile(model_path) as zf:
            zf.extractall()
            self.params = json.load(open("models/model_params.json"))
        # 解析烟雾超限统计
        self.smoke_feedback_id = self.params["original_params"].get("烟雾反馈存储id")
        self.params["smoke_vars"] = []
        self.smoke_threshold = []
        if self.params["original_params"].get("烟雾反馈参数"):
            for item in self.params["original_params"].get("烟雾反馈参数").values():
                if item.get("测点名").split("|")[0] not in self.params["smoke_vars"]:
                    self.params["smoke_vars"].append(item.get("测点名").split('\\n')[0])
                    self.smoke_threshold.append(float(item.get("超限统计阈值")))

        db_name = self.params.get("trenddb_name")

        self.params = {
            key: value if not key.endswith("vars") else self._format_columns(value, db_name)
            for key, value in self.params.items()
        }
        components = ModelLoader.load(
            model_list=[
                {
                    "name": "automatic_weight",
                    "path": 'models/target_weight.json',
                    "type": "json"
                },
                {
                    "name": "target_models",
                    "path": [f'models/{var}.m' for var in self.params["target_vars"]],
                    "type": "joblib"
                },
                {
                    "name": "gmm_model",
                    "path": 'models/gmm.m',
                    "type": "joblib"
                },
                {
                    "name": "search_dist",
                    "path": 'models/search_dist.json',
                    "type": "json"
                },
                {
                    "name": "target",
                    "path": 'models/target.json',
                    "type": "json"
                }
            ]
        )

        self.model = ModelInstance(
            model_param=self.params,  # 训练时配置的参数信息
            feature_columns=self.params["feature_vars"],  # 需要通过trenddb获取数据的例
            control_columns=self.params["control_vars"],
            smoke_columns=self.params["smoke_vars"],
            params_space=self._build_param_space(components["search_dist"], self.params),  # 构造的可以直接输入optuna的参数范围和分布信息
            **components
        )
        self.db = TrendDBManager(**self.model.model_param)

    def predict(self, data: List[str]) -> List[float]:
        \"\"\"完整状态管理的预测方法\"\"\"
        # 异步启动烟雾统计（不阻塞推理）
        if self.smoke_feedback_id is not None:
            self._trigger_smoke_count()

        # 进行优化推理
        result = self._run_optimization(data)
        current_time = datetime.datetime.now()

        # 初始状态更新
        if self._last_control is None:
            self._update_state(result, current_time, "normal_control")
            return self._format_result(result)

        # 安全下控频次限制，2分钟内不推送新值，20分钟内工况不变化不推送新值
        update_condition = result["gk"] != self._last_gk

        if update_condition:
            self._update_state(result, current_time, "normal_control")
        else:
            result["control"] = self._last_control

        return self._format_result(result)

    def _run_optimization(self, data: List[str]) -> Dict:
        \"\"\"执行优化流程\"\"\"
        if len(data) == 0:
            data = self._fetch_realtime_data(self.db, self.model.feature_columns)
            self.control_data = np.squeeze(self._fetch_realtime_data(self.db, self.model.control_columns))
        elif len(data) == 1:
            data = self._fetch_realtime_data(self.db, self.model.feature_columns, data[0])
        elif len(data) == len(self.params["feature_vars"]):
            data = np.array([data])
        else:
            raise ValueError("Invalid input data length!")

        self._last_active_time = datetime.datetime.now()
        # 工况匹配
        # 自动计算新工况阈值
        threshold = float(self.model.model_param["original_params"].get("新工况判断阈值", 1.5)) * np.mean(
            [value for value in self.model.model_param["feature_weights"].values() if isinstance(value, float) or isinstance(value, int)]
        )

        gk_info = self._match_operating_condition(data, threshold)

        optimized_params = OptimizationEngine(self.model).optimize(data, gk_info["param_space"])

        return {
            "control": self._apply_noise(optimized_params),
            "predict": self._get_predictions(optimized_params, data),
            "gk": gk_info["id"]
        }

    def _update_state(self, result: Dict, timestamp: datetime.datetime, state: str):
        \"\"\"安全更新状态\"\"\"
        self._last_control = result["control"]
        self._last_update = timestamp
        self._last_gk = result["gk"]
        self.state = state
        logger.debug(f"状态已更新｜时间：{timestamp}")

    def _should_add_noise(self) -> bool:
        \"\"\"噪声添加策略\"\"\"
        return (
                self.model.model_param.get('add_noise', False) and
                np.random.random() > 0.9
        )

    def _apply_noise(self, control_params: List[float]) -> List[float]:
        \"\"\"参数扰动处理\"\"\"
        if self._should_add_noise():
            noise = 0.03 * np.random.randn(len(control_params))
            return [p * (1 + n) for p, n in zip(control_params, noise)]
        return control_params

    def _format_columns(self, variable_names: List[str], prefix: str) -> List[str]:
        \"\"\"批量添加测点数据库前缀\"\"\"
        return [
            f"{prefix}.{item}" if not item.startswith(f"{prefix}.") and item not in TIME_FEATURES else item
            for item in variable_names
        ]

    def _build_param_space(self, search_dist: Dict, params: Dict) -> Dict:
        \"\"\"重构后的参数空间构建方法\"\"\"
        # 寻优范围分布类型，主要分为正态和平均分布
        distribution_type = "normal" if params.get('distance_function') == 'normal' else "uniform"

        params_space = defaultdict(dict)
        # 处理每个控制变量
        for i, var in enumerate(params["control_vars"]):
            # 遍历每个工况条件
            for gk in search_dist[var]:
                # 解析参数边界
                bound1 = float(search_dist[var][gk][0])
                bound2 = float(search_dist[var][gk][1])
                # 构建参数寻优范围
                params_space[gk] = params_space[gk] | {f"act{i}": [distribution_type, bound1, bound2]}

        return params_space

    def _fetch_realtime_data(self, db: TrendDBManager, columns: List[str], time: str = "") -> np.ndarray:
        \"\"\"获取实时数据\"\"\"
        now = datetime.datetime.strptime(time, "%Y-%m-%d %H:%M:%S") if len(time) > 0 else datetime.datetime.now()
        # 获取最近3秒内的数据
        time_range = [
            [
                (now - datetime.timedelta(seconds=3)).strftime("%Y-%m-%d %H:%M:%S"),  # start_time
                now.strftime("%Y-%m-%d %H:%M:%S"),  # end_time
                1  # interval
            ]
        ]
        # 获取到数据后取最后一个数据作为当前最新数据
        data = db.load_dataset(time_range, columns).values[-1:]

        return data

    def _trigger_smoke_count(self):
        \"\"\"触发烟雾统计\"\"\"
        with self._smoke_lock:
            if not self._smoke_task_running:
                self._smoke_task_running = True
                # 提交任务到线程池
                self._smoke_executor.submit(self._count_smoke_task)

    def _count_smoke_task(self):
        \"\"\"烟雾统计任务\"\"\"
        try:
            self._execute_smoke_count()
        except Exception as e:
            logger.error(f"烟雾统计失败: {e}")
        finally:
            # 任务完成，释放锁
            with self._smoke_lock:
                self._smoke_task_running = False

    def _execute_smoke_count(self):
        \"\"\"执行烟雾统计逻辑\"\"\"
        try:
            if not self.smoke_feedback_id or not self.model.smoke_columns:
                return

            start_time = self._last_active_time
            end_time = datetime.datetime.now()
            end_day = start_time.date().strftime("%Y-%m-%d")
            fetch_seconds = (end_time - start_time).total_seconds()

            if fetch_seconds <= 0:
                return

            # 获取数据
            db = TrendDBManager(**self.model.model_param)
            time_range = [[
                start_time.strftime("%Y-%m-%d %H:%M:%S"),
                end_time.strftime("%Y-%m-%d %H:%M:%S"),
                1
            ]]

            smoke_tags = self.model.smoke_columns
            feature_columns = self.model.feature_columns
            all_columns = list(set(feature_columns + smoke_tags))

            df = db.load_dataset(time_range, all_columns)

            if df.empty:
                return

            # 加载统计数据
            file_path = os.path.join("/opt", f"{self.smoke_feedback_id}.txt")
            data = {}
            if os.path.exists(file_path):
                try:
                    with open(file_path, "r") as f:
                        data = json.load(f)
                except:
                    pass

            # 统计超限
            for idx, row in df.iterrows():
                try:
                    # 工况匹配
                    feature_data = np.array([row[col] for col in feature_columns])[None, :]
                    threshold = float(self.model.model_param["original_params"].get("新工况判断阈值", 1.5)) * np.mean([
                        v for v in self.model.model_param["feature_weights"].values() if isinstance(v, float) or isinstance(v, int)
                    ])
                    gk_info = self._match_operating_condition(feature_data, threshold, debug=False)
                    gk_id = str(gk_info["id"])
                    # 初始化：
                    if gk_id not in data:
                        data[gk_id] = {end_day: defaultdict(list)}
                    if end_day not in data[gk_id]:
                        data[gk_id][end_day] = defaultdict(list)
                    for key in self.model.smoke_columns:
                        data[gk_id][end_day][key].append(0)
                    for smoke_col, threshold_value in zip(self.model.smoke_columns, self.smoke_threshold):
                        value = row[smoke_col]
                        if not pd.isna(value) and value > threshold_value:
                            data[gk_id][end_day][smoke_col][-1] += 1

                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    logger.warning(f"处理数据点失败: {e}")
                    continue

            # 保存统计结果
            with open(file_path, "w") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            # 更新时间
            self._last_active_time = end_time
            logger.info(f"烟雾统计完成，处理了 {len(df)} 条数据")

        except Exception as e:
            logger.error(f"烟雾统计执行失败: {e}")

    def _match_operating_condition(self, data: np.ndarray, threshold: float = 0, debug: bool = True) -> Dict:
        \"\"\"匹配当前工况\"\"\"
        # 聚类模型直接预测工况类别
        if self.model.model_param["feature_type"] == "聚类匹配":
            cluster_id = self.model.gmm_model.predict(data)
            return {"id": cluster_id, "param_space": self.model.params_space[str(cluster_id)]}
        # 优化工况匹配，对开关量工况依旧使用原来匹配方法，模拟量由于现在不进行归一化，需要考虑如何计算距离
        break_points = self.model.model_param.get("break_points", {})
        distances = {}
        for gk in self.model.params_space:
            if gk == "all": continue
            distance = 0
            for i, (k, v) in enumerate(eval(gk)):
                v = eval(v) if isinstance(v, str) else v
                if isinstance(v, list):
                    if data[0][i] > v[1]:
                        distance += self.model.model_param["feature_weights"][k] * math.sqrt((v[1] - data[0][i]) ** 2) / (break_points[k][-1][-1] - break_points[k][0][0])  # 除以划分区域的整体数据范围，去除数量级影响

                    elif data[0][i] < v[0]:
                        distance += self.model.model_param["feature_weights"][k] * math.sqrt((v[0] - data[0][i]) ** 2) / (break_points[k][-1][-1] - break_points[k][0][0])  # 除以划分区域的整体数据范围，去除数量级影响
                else:
                    distance += self.model.model_param["feature_weights"][k] * math.sqrt((v - data[0][i]) ** 2)

            distances[gk] = distance

        best_gk = min(distances, key=distances.get)
        if debug:
            logger.info(f"最小匹配距离： {distances[best_gk]}, 新工况阈值自动计算结果: {threshold}")
        new_work_condition_control_type = self.model.model_param.get("original_params").get("新工况控制模式")
        if distances[best_gk] > threshold:
            if new_work_condition_control_type == "全量工况":
                # 方案一：如果距离超过阈值，则使用保守的全量工况搜索范围进行搜索，问题：一用一备的情况会出问题
                if debug:
                    logger.info(f"最小匹配距离超过阈值: {threshold}, 采用全量数据工况搜索范围!")
                best_gk = "all"
                param_space = self.model.params_space[best_gk]
            elif new_work_condition_control_type == "三个最近工况高频":
                # 方案二：如果距离超过阈值，则使用距离最近的三个工况的最高值范围进行搜索，与方案一相比稳定性差一点，但是可以解决一用一备问题。
                if debug:
                    logger.info(f"最小匹配距离超过阈值: {threshold}, 采用最近的三个工况的最高范围进行搜索!")
                best_gk_list = sorted(distances, key=distances.get)[:3]
                gk_max = {
                    gk: self.model.params_space[gk]["act0"][-1]
                    for gk in best_gk_list if gk != "all"
                }
                best_gk = max(gk_max, key=gk_max.get)
                param_space = self.model.params_space[best_gk]
            elif new_work_condition_control_type == "给定频率":
                # 方案三：采用给定赔率进行下控
                given_frequence_index = [
                    k for k, var_type in enumerate(self.model.model_param["control_vars_type"])
                    if re.search(r"频率", var_type)
                ]
                param_space = self.model.params_space[best_gk]
                for index in given_frequence_index:
                    param_space[f"act{index}"] = [
                        "uniform", [self.control_data[index] - 0.1, self.control_data[index] + 0.1]
                    ]
        else:
            param_space = self.model.params_space[best_gk]

        if best_gk != "all":
            rows = []
            for real_data, (gk_name, gk_value) in zip(data[0], eval(best_gk)):
                weight = self.model.model_param.get("feature_weights").get(gk_name)
                gk_value = eval(gk_value) if isinstance(gk_value, str) else gk_value
                if isinstance(gk_value, list):
                    if real_data < gk_value[0] or real_data > gk_value[1]:
                        real_data = f"**{real_data}**"
                else:
                    if abs(real_data - gk_value) > 1e-2:
                        real_data = f"**{real_data}**"
                rows.append((gk_name, str(real_data), str(gk_value), str(weight)))
            if debug:
                headers = ["测点名", "实时值", "匹配值", "工况距离权重"]

                # 计算每列的最大显示宽度
                column_widths = [TableLogger.str_display_width(h) for h in headers]
                for row in rows:
                    for i, cell in enumerate(row):
                        cell_width = TableLogger.str_display_width(cell)
                        if cell_width > column_widths[i]:
                            column_widths[i] = cell_width
                # 打印表格
                separator = TableLogger.format_separator(column_widths)
                logger.info(separator)
                logger.info(TableLogger.format_row(headers, column_widths))
                logger.info(separator)
                for row in rows:
                    logger.info(TableLogger.format_row(row, column_widths))
                logger.info(separator)

        if debug:
            # 展示当前工况历史数据的分布信息
            for i, key in enumerate(self.model.search_dist):
                logger.info(
                    f"控制参数 {key} 的历史数据分布信息："
                    f"匹配工况历史均值：{self.model.search_dist[key].get(best_gk)[2]}, "
                    f"匹配工况历史标准差：{self.model.search_dist[key].get(best_gk)[3]}, "
                    f"匹配工况历史数据量：{self.model.search_dist[key].get(best_gk)[4]}"
                )
                logger.info(
                    f"控制参数 {key} 的寻优范围：{param_space[f'act{i}'][1]} ~ {param_space[f'act{i}'][2]}"
                )

        return {"id": best_gk, "param_space": param_space}

    def _apply_constraints(self, params: List[float]) -> List[float]:
        \"\"\"应用参数约束\"\"\"
        return [
            max(min(p, bound[1]), bound[0]) if bound else p
            for p, bound in zip(params, self.model.model_param.get("boundary", []))
        ]

    def _get_predictions(self, params: List[float], data: np.ndarray) -> List[float]:
        \"\"\"获取预测结果\"\"\"
        return [
            self.model.target_models[m].predict(np.hstack([np.array(params)[None], data]))[0]
            for m in self.params["target_vars"]
        ]

    def _format_result(self, result: Dict) -> List[float]:
        \"\"\"格式化输出结果\"\"\"
        control = [
            round(p, 2) + float(param.get("偏移量", 0))
            for p, param in zip(
                result["control"], self.model.model_param.get("original_params").get("控制参数").values()
            )
        ]
        predictions = [round(p, 2) for p in result["predict"]]
        return self._apply_constraints(control) + predictions  # 在最后输出施加强范围约束
"""


@Component.outputs(File(key="loader_file.py", file_type="Any"))
def main_business(**kwargs):

    return {"loader_file.py": bytes(MODEL_LOADER, encoding="utf-8")}


if __name__ == '__main__':
    App.run(main_business)
