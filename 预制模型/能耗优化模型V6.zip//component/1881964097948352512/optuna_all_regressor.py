import zipfile

import optuna
import joblib
import os
import numpy as np
from loguru import logger
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.ensemble import RandomForestRegressor
from lightgbm import LGBMRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sushineAI.argument import Csv, File, StringOfDict
from sushineAI.component import Component
from sushineAI.app import App

# 定义目标函数
def objective(trial, X, y):
    # 建议模型类型
    regressor_name = trial.suggest_categorical('regressor', ['RandomForest', 'LightGBM', 'LinearRegression'])

    if regressor_name == 'RandomForest':
        # 定义随机森林的超参数空间
        params_space = {
            'n_estimators': trial.suggest_int('n_estimators', 10, 50),
            'max_depth': trial.suggest_int('max_depth', 2, 32),
            "min_samples_split": trial.suggest_int('min_samples_split', 2, 10),
            "min_samples_leaf": trial.suggest_int('min_samples_leaf', 1, 10),
            "max_features": trial.suggest_float ('max_features', 0.1, 1.0),
            "verbose": 0,
        }
        model = RandomForestRegressor(**params_space)
    elif regressor_name == 'LightGBM':
        # 定义LightGBM的超参数空间
        params_space = {
            'num_leaves': trial.suggest_int('num_leaves', 20, 150),
            'max_depth': trial.suggest_int('max_depth', 3, 20),
            'n_estimators':  trial.suggest_int('n_estimators', 20, 150),
            'learning_rate':  trial.suggest_float('learning_rate', 1e-3, 5e-1, log=True),
            'min_child_samples': trial.suggest_int("min_child_samples", 5, 100),
            'subsample': trial.suggest_float ('subsample', 0.5, 1.0),
            'colsample_bytree': trial.suggest_float ('colsample_bytree', 0.5, 1.0),
            'objective': 'regression',
            'boosting_type': 'gbdt',
            'metric': 'rmse',
            'verbosity': -1,
            'num_threads': 2
        }

        model = LGBMRegressor(**params_space)
    else:
        # 定义线性回归的超参数空间
        fit_intercept = trial.suggest_categorical('fit_intercept', [True, False])
        model = LinearRegression(fit_intercept=fit_intercept)

    # 使用五折交叉验证评估模型性能
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    scores = cross_val_score(model, X, y, cv=kf, scoring='neg_mean_squared_error')
    rmse = np.sqrt(-scores.mean())
    return rmse

@Component.inputs(Csv(key="feature"), Csv(key="target"))
@Component.params(StringOfDict(key=['n_jobs']))
@Component.outputs(Csv(key="predict"), File(key="model", file_type="Any"))
def train(**kwargs):
    feature = kwargs.get("feature")
    target = kwargs.get("target")
    n_jobs = int(kwargs.get("n_jobs"))
    os.makedirs("models", exist_ok=True)
    result = target.copy()
    result_df = {}

    for t in target.columns:
        X, y = feature, target[t]

        # 创建 Optuna study 对象
        study = optuna.create_study(direction='minimize')
        study.optimize(lambda trial: objective(trial, X, y), n_trials=50, n_jobs=n_jobs)

        # 获取最佳参数
        best_params = study.best_params
        result_df[t] = [best_params.copy()]
        regressor_name = best_params.pop('regressor')

        # 根据最佳参数定义模型
        if regressor_name == 'RandomForest':
            model = RandomForestRegressor(**best_params)
        elif regressor_name == 'LightGBM':
            model = LGBMRegressor(**best_params)
        else:
            model = LinearRegression(**best_params)

        # 训练模型
        model.fit(X, y)

        # 保存模型
        joblib.dump(model, f"models/{t}.m")

        # 预测结果
        total_predict = model.predict(feature)
        result[t + "_predict"] = total_predict

    # 打印结果
    for key in result_df:
        logger.info(f"参数: {key} 的最佳超参数：{result_df[key]}")

    # 返回结果
    with zipfile.ZipFile("models.zip", "w") as zipf:
        for root, dirs, files in os.walk("models"):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, "models"))
    with open("models.zip", "rb") as file:
        return {
                'predict': result,
                'model': file.read()
            }

if __name__ == '__main__':
    App.run(train)
