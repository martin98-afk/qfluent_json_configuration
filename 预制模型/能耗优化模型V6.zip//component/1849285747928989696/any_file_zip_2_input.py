"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: any_file_zip_2_input.py.py
@time: 2024/10/24 14:07
@desc:
"""

import os
import sys
import zipfile
import shutil

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import File, StringOfDict
from sushineAI.component import Component
from sushineAI.app import App


def process_trainset(file, name, zip_bool):
    file_name = file.name
    if zip_bool or file_name.endswith(".zip"):
        with zipfile.ZipFile(file_name, 'r') as zip_ref:
            print(zip_ref.namelist())
            for zip_info in zip_ref.infolist():
                zip_info.filename = os.path.basename(zip_info.filename)
                zip_info.filename = os.path.join(f"models/", zip_info.filename)
                zip_ref.extract(zip_info)
    else:
        if name == "": name = os.path.basename(file_name)
        if "." not in name:
            os.makedirs(name, exist_ok=True)
            name = os.path.join("models", name, file_name)
            shutil.copy(file_name, name)
        else:
            name = os.path.join("models", name)
            shutil.copy(file_name, name)


def zip_folder(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w') as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                file_in_zip_path = os.path.relpath(file_path, os.path.dirname(folder_path))
                zipf.write(file_path, file_in_zip_path)


@Component.inputs(File(key="model1", file_type='Any'), File(key="model2", file_type='Any'))
@Component.params(StringOfDict(key=["name1", "name2", "file1_zip", "file2_zip"]))
@Component.outputs(File(key='output.zip', file_type='Any'))
def model_zip(**kwargs):
    os.makedirs("models", exist_ok=True)
    model_list = [kwargs.get(f"model{i + 1}") for i in range(2)]
    name_list = [kwargs.get(f"name{i + 1}") for i in range(2)]
    zip_judge = [bool(int(kwargs.get(f"file{i + 1}_zip"))) for i in range(2)]
    [process_trainset(file, name, zip_bool) for file, name, zip_bool in zip(model_list, name_list, zip_judge)]

    # 将model目录打包成model.zip
    zip_folder("models", "model.zip")
    # 将压缩包使用rb方式读取并通过json回传
    with open("./model.zip", "rb") as f:
        return {"output.zip": f.read()}


if __name__ == '__main__':
    App.run(model_zip)
