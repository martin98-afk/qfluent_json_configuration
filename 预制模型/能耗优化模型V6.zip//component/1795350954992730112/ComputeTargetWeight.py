"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: ComputeTargetWeight.py
@time: 2024/5/28 14:48
@desc: 
"""
import os
import sys
import numpy as np

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(Csv(key="input1"))
@Component.outputs(File(key="output1", file_type="Json"))
def compute_target_weight(**kwargs):
    input1 = kwargs.get('input1')
    # 平衡各个目标的数量级，计算目标权重
    target_std = list(input1.std())
    print(target_std)
    min_std_id = np.argsort(target_std)
    for id in min_std_id:
        if target_std[id] != 0:
            target_std = [target_std[id] / item if item != 0 else 1 for item in target_std]
            break

    output = {
        input1.columns[i]: target_std[i] for i in range(len(input1.columns))
    }
    return {'output1': output}


if __name__ == '__main__':
    App.run(compute_target_weight)