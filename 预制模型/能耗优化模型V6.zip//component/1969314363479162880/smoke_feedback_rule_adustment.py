"""
算法包代码示例
"""
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import Csv, StringOfDict
from sushineAI.argument import Xlsx
from sushineAI.argument import File
from sushineAI.argument import Model


import pandas as pd
import numpy as np
from datetime import datetime
from loguru import logger

def calculate_smoke_index(smoke_record):
    """ 计算单条记录的冒烟指数：平均每分钟冒烟次数 """
    if not isinstance(smoke_record, list) or len(smoke_record) != 4:
        return 0.0
    v1, v2, v3, seconds = smoke_record
    total_smoke = v1 + v2 + v3
    minutes = max(1, seconds / 60.0)
    return total_smoke / minutes

def is_date_column(col_name):
    """ 判断列名是否为日期格式 YYYY-MM-DD """
    try:
        datetime.strptime(str(col_name), '%Y-%m-%d')
        return True
    except ValueError:
        return False

def get_adjustment_suggestion(row, lookback_days=3):
    """
    输入：DataFrame 的一行
    lookback_days: 回溯天数，默认取最近3天
    输出：新下限、新上限、调节原因、加权冒烟指数
    """
    # 提取当前寻优范围
    current_L = row['寻优下限']
    current_U = row['寻优上限']
    range_width = current_U - current_L

    if range_width <= 0:
        range_width = max(30, current_U * 0.1)

    # === 动态识别所有日期列 ===
    all_cols = row.index.tolist()
    date_cols = [col for col in all_cols if is_date_column(col)]

    # 按日期从新到旧排序（最新在前）
    date_cols_sorted = sorted(date_cols, key=lambda x: datetime.strptime(x, '%Y-%m-%d'), reverse=True)

    # 取最近 lookback_days 天
    recent_date_cols = date_cols_sorted[:lookback_days]

    # === 时间衰减权重 ===
    # 最近一天权重最高，依次递减（指数衰减或线性）
    weights = []
    for i in range(len(recent_date_cols)):
        # 权重 = 0.5^i （指数衰减）或 (lookback_days - i) / lookback_days （线性）
        weight = 0.5 ** i  # 指数衰减：第0天=1.0, 第1天=0.5, 第2天=0.25...
        weights.append(weight)

    weighted_smoke_indices = []
    valid_weights = []

    for i, col in enumerate(recent_date_cols):
        val = row[col]
        if isinstance(val, str) and len(val) > 0:
            val = eval(val)

        if isinstance(val, list) and len(val) == 4:
            smoke_index = calculate_smoke_index(val)
            weighted_smoke_indices.append(smoke_index * weights[i])
            valid_weights.append(weights[i])
        else:
            # 数据缺失，跳过该天
            continue
    logger.info(weighted_smoke_indices)


    # 计算加权平均
    if sum(valid_weights) == 0:
        avg_weighted_smoke_index = 0.0
    else:
        avg_weighted_smoke_index = sum(weighted_smoke_indices) / sum(valid_weights)

    # === 设定阈值 ===
    TH_SAFE = 0.1    # 安全区
    TH_WARN = 0.5    # 警告区
    TH_DANGER = 1.0  # 危险区

    # === 比例调节参数 ===
    STEP_DANGER = 0.3  # 15%
    STEP_WARN = 0.15    # 8%
    STEP_MICRO = 0.08   # 3%
    STEP_SAVE = 0.05    # 节能下调5%

    L_new = current_L
    U_new = current_U
    reason = "保持不变"

    # === 调节逻辑 ===
    if avg_weighted_smoke_index >= TH_DANGER:
        delta = STEP_DANGER * range_width
        L_new = current_L + delta
        reason = f"🚨 危险调节：加权冒烟指数{avg_weighted_smoke_index:.3f}，下限+{STEP_DANGER*100:.0f}%（+{delta:.1f}）"
    elif avg_weighted_smoke_index >= TH_WARN:
        delta = STEP_WARN * range_width
        L_new = current_L + delta
        reason = f"⚠️ 警告调节：加权冒烟指数{avg_weighted_smoke_index:.3f}，下限+{STEP_WARN*100:.0f}%（+{delta:.1f}）"
    elif avg_weighted_smoke_index >= TH_SAFE:
        if np.random.rand() < 0.2:
            delta = STEP_MICRO * range_width
            L_new = current_L + delta
            reason = f"🔧 微调：加权冒烟指数{avg_weighted_smoke_index:.3f}，下限+{STEP_MICRO*100:.0f}%（+{delta:.1f}）"
        else:
            reason = f"✅ 保持：加权冒烟指数{avg_weighted_smoke_index:.3f}在安全区"
    else:
        if current_L > current_U * 0.7:
            delta = STEP_SAVE * range_width
            L_new = current_L - delta
            reason = f"🌿 节能调节：加权冒烟指数{avg_weighted_smoke_index:.3f}，下限-{STEP_SAVE*100:.0f}%（-{delta:.1f}）"
        else:
            reason = f"🔒 已达安全边界，保持：加权冒烟指数{avg_weighted_smoke_index:.3f}"

    # === 安全边界保护 ===
    L_MIN = max(current_U * 0.5, current_L - range_width * 0.3)
    L_MAX = current_U * 0.97
    L_new = np.clip(L_new, L_MIN, L_MAX)
    U_new = current_U

    return L_new, U_new, reason, avg_weighted_smoke_index


@Component.inputs(File(key="input", file_type="Any"))
@Component.params(StringOfDict(key=['lookback_days']))
@Component.outputs(Xlsx(key="output"))
def main_business(**kwargs):
    df = kwargs.get('input').name
    df = pd.read_excel(df, sheet_name=None)
    logger.info(df)
    result = {}
    for sheet_name in df:
        current_df = df.get(sheet_name)
        logger.info(current_df)
        results = current_df.apply(lambda row: get_adjustment_suggestion(row, lookback_days=int(kwargs.get("lookback_days"))), axis=1)
        logger.info(results)
        # 拆分结果
        current_df[['新寻优下限', '新寻优上限', '调节原因', '加权冒烟指数']] = pd.DataFrame(results.tolist(), index=current_df.index)

        # 计算调节幅度和比例
        logger.info("-------------------------------")
        logger.info(current_df)
        logger.info("-------------------------------")
        result[sheet_name] = current_df

    return {
        'output': result
    }


if __name__ == '__main__':
    App.run(main_business)
