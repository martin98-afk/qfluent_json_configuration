from itertools import product
from collections import OrderedDict
from ast import literal_eval
import datetime
import pandas as pd
import numpy as np
import os
import sys

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Xlsx, File
from sushineAI.component import Component
from sushineAI.app import App


def _to_hashable(val):
    if isinstance(val, list):
        return tuple(val)
    return val


def _to_original(val):
    if isinstance(val, tuple):
        return list(val)
    return val


@Component.inputs(File(key="input", file_type="Json"))
@Component.outputs(Xlsx(key="output"))
def main(**kwargs):
    json_input = kwargs.get('input')
    output_dict = {}
    info_columns = ["寻优下限", "寻优上限", "历史数据均值", "历史数据方差", "历史数据量", "工况更新时间"]

    for sheet_key in json_input:
        raw_data = json_input[sheet_key]
        if "all" in raw_data:
            raw_data.pop("all")
        if not raw_data:
            output_dict[sheet_key] = pd.DataFrame()
            continue

        # Step 1: 收集所有 tag（保持首次出现顺序）
        all_tags_ordered = OrderedDict()
        parsed_raw = []

        for lkey_str, value in raw_data.items():
            lkey = literal_eval(lkey_str)
            param_dict = {}
            for tag, val in lkey:
                param_dict[tag] = _to_hashable(val)
                if tag not in all_tags_ordered:
                    all_tags_ordered[tag] = None
            parsed_raw.append((param_dict, value))

        param_order = list(all_tags_ordered.keys())

        # Step 2: 收集每个 tag 的所有取值
        param_values = {tag: set() for tag in param_order}
        parsed_records = []
        all_smoke_columns = set()

        for param_dict, value in parsed_raw:
            # 补全缺失的 tag（理论上不会缺，但保险）
            for tag in param_order:
                if tag not in param_dict:
                    # 如果某个工况缺少某个 tag，这里会出问题
                    # 但根据数据，所有工况应包含全部 tag
                    raise ValueError(f"工况缺少参数: {tag}")
                param_values[tag].add(param_dict[tag])

            # info_columns
            if len(value) <= 5:
                value = list(value) + [datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
            info_vals = value[:6]

            # smoke feedback
            smoke_dict = {}
            if len(value) > 6:
                smoke_feedback = value[6]
                smoke_cols = sorted(smoke_feedback.keys(), reverse=True)
                all_smoke_columns.update(smoke_cols)
                for col in smoke_cols:
                    total = 0
                    for inner_vals in smoke_feedback[col].values():
                        if isinstance(inner_vals, (list, tuple)):
                            total += sum(inner_vals)
                        else:
                            total += inner_vals
                    smoke_dict[col] = total

            # 构建记录
            record = {"sheet_key_col": 0}
            for tag in param_order:
                record[tag] = param_dict[tag]
            for col, val in zip(info_columns, info_vals):
                record[col] = val
            for col in sorted(all_smoke_columns, reverse=True):
                record[col] = smoke_dict.get(col, None)

            parsed_records.append(record)

        # Step 3: 生成全组合
        value_lists = []
        for tag in param_order:
            vals = list(param_values[tag])
            # 排序：数值型按值，tuple 按首元素，str 按字典序
            try:
                vals_sorted = sorted(vals)
            except TypeError:
                # 混合类型，用 repr 排序保证一致性
                vals_sorted = sorted(vals, key=lambda x: str(x))
            value_lists.append(vals_sorted)

        all_combinations = list(product(*value_lists))

        # 构建完整 DataFrame
        full_records = []
        for combo in all_combinations:
            rec = {"sheet_key_col": 0}
            for i, tag in enumerate(param_order):
                rec[tag] = combo[i]
            for col in info_columns + sorted(all_smoke_columns, reverse=True):
                rec[col] = None
            full_records.append(rec)

        df_full = pd.DataFrame(full_records)
        if parsed_records:
            df_existing = pd.DataFrame(parsed_records)
            df_full = df_full.set_index(param_order)
            df_existing = df_existing.set_index(param_order)
            df_full.update(df_existing)
            df_full = df_full.reset_index()
        else:
            df_full = df_full

        # 还原 list 格式
        for tag in param_order:
            df_full[tag] = df_full[tag].apply(_to_original)

        # 设置列顺序
        smoke_columns = sorted(all_smoke_columns, reverse=True)
        final_columns = [sheet_key] + param_order + info_columns + smoke_columns
        df_full.rename(columns={"sheet_key_col": sheet_key}, inplace=True)
        df_full = df_full.reindex(columns=final_columns, fill_value=None)

        output_dict[sheet_key] = df_full

    return {'output': output_dict}


if __name__ == '__main__':
    App.run(main)