"""
@author: TangXC
@license: (C) Copyright 1999-2019, NJ_LUCULENT Corporation Limited.
@contact: tangxucheng@luculent.net
@file: upload_xlsx.py
@time: 2024/9/3 11:30
@desc:
"""
from sushineAI.argument import Xlsx
from sushineAI.component import Component
from sushineAI.app import App



@Component.outputs(Xlsx(key='output1'))
def upload_xlsx(**kwargs):

    return {'output1': None}


if __name__ == '__main__':
    App.run(upload_xlsx)
