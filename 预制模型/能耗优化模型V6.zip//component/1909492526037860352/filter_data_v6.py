"""
@author: TangXC
@license: (C) Copyright 1999-2025, NJ_LUCULENT Corporation Limited.
@contact: tangxucheng@luculent.net
@file: filter_data_v6.py
@time: 2025/4/18 14:42
@desc:
"""
import os
import sys
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, StringOfList, StringOfDict
from sushineAI.component import Component
from sushineAI.utils.translator import transform_params_type
from sushineAI.app import App


def detect_analog_columns(
        df: pd.DataFrame,
        max_switch_unique: int = 5
) -> list:
    """
    判断哪些列为模拟量 (analog) 而非开关量 (switch).

    - 如果某列非数值型, 跳过.
    - 如果唯一值数小于等于 max_switch_unique, 视为开关量.
    - 如果唯一值数占比 (unique_count / total_count) 小于 discrete_ratio_thresh, 视为开关量.
    """
    analog_cols = []
    n_rows = len(df)
    for col in df.columns:
        # 仅数值型列
        if not np.issubdtype(df[col].dtype, np.number):
            continue
        unique_vals = df[col].dropna().unique()
        n_unique = len(unique_vals)
        print(col, n_unique, n_rows)
        # 如果简单开关只有少量唯一值
        if n_unique <= max_switch_unique:
            # 识别为开关量, 跳过
            continue
        analog_cols.append(col)
    return analog_cols


def remove_outliers_iso_forest(
        df: pd.DataFrame,
        cols: list,
        n_estimators: int = 100,
        contamination: float = 0.01,
        max_features: float = 1.0,
        bootstrap: bool = True,
        quantile: float = None
) -> pd.DataFrame:
    """
    对模拟量列应用孤立森林剔除异常值.

    如果提供 quantile 参数, 则使用 decision_function 得分的分位数阈值手动筛选;
    否则使用内置 predict 方法根据 contamination 参数筛选.
    """
    iso = IsolationForest(
        contamination=contamination,
        n_estimators=n_estimators,
        max_features=max_features,
        bootstrap=bootstrap
    )
    data = df[cols]
    iso.fit(data)

    if quantile is not None:
        # 使用分位数阈值过滤
        scores = iso.decision_function(data)
        # 决策得分越低越异常, 取得指定分位数阈值
        thr = np.quantile(scores, quantile)
        # 保留得分高于阈值的样本 (正常样本)
        mask = scores >= thr
    else:
        # 使用模型自带预测
        preds = iso.predict(data)
        # 保留预测为正常 (1) 的样本
        mask = preds == 1

    original_count = len(df)
    cleaned_df = df.loc[mask]
    cleaned_count = len(cleaned_df)

    print("--- 孤立森林剔除异常值报告 ---")
    print(f"原始行数: {original_count}")
    print(f"清洗后行数: {cleaned_count}")
    print(
        f"共剔除: {original_count - cleaned_count} 行 (约 {100 * (original_count - cleaned_count) / original_count:.2f}% )")
    return cleaned_df


def remove_outliers_iqr(
        df: pd.DataFrame,
        cols: list,
        multiplier: float = 1.5
) -> pd.DataFrame:
    """
    使用 IQR 方法剔除极端异常值：
    - 对指定列 (或所有数值型列) 计算 Q1, Q3, IQR;
    - 定义上下限为 [Q1 - multiplier*IQR, Q3 + multiplier*IQR];
    - 剔除超出上下限的数据行。

    返回清洗后的 DataFrame。
    """
    if cols is None:
        cols = df.select_dtypes(include="number").columns.tolist()

    bounds = {}
    mask = pd.Series(True, index=df.index)
    for col in cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - multiplier * IQR
        upper = Q3 + multiplier * IQR
        bounds[col] = (lower, upper)
        # 更新掩码: 保留在范围内的
        mask &= df[col].between(lower, upper)

    print("--- 四分位距各特征值上下边界阈值 ---")
    for col, (low, high) in bounds.items():
        print(f"  {col}: 下限={low:.3f}, 上限={high:.3f}")

    original_count = len(df)
    cleaned_df = df.loc[mask]
    cleaned_count = len(cleaned_df)

    print("--- 异常值四分位距剔除报告 ---")
    print(f"原始行数: {original_count}")
    print(f"清洗后行数: {cleaned_count}")
    print(
        f"共剔除: {original_count - cleaned_count} 行 (约 {100 * (original_count - cleaned_count) / original_count:.2f}% )")
    return cleaned_df


@Component.inputs(Csv(key="data"))
@Component.params(StringOfDict(
    key=["max_switch_unique", "n_estimators", "contamination", "max_features", "quantile",
         "use_iso_forest", "use_iqr"]))
@Component.outputs(Csv(key="data"))
def filter(**kwargs):
    input_init = kwargs.get('data')
    input_init.set_index("timestamp", inplace=True)

    max_switch_unique = transform_params_type(kwargs.get("max_switch_unique"), int, 5)
    analog_cols = detect_analog_columns(df=input_init, max_switch_unique=max_switch_unique)
    print(analog_cols)
    if len(analog_cols) > 0:

        n_estimators = transform_params_type(kwargs.get("n_estimators"), int, 100)
        contamination = kwargs.get("contamination")
        if isinstance(contamination, float):
            contamination = transform_params_type(contamination, float, 0.01)
        else:
            contamination = transform_params_type(contamination, str, 'auto')
        max_features = eval(kwargs.get("max_features"))
        if not (isinstance(max_features, int) or isinstance(max_features, float)):
            raise TypeError('max_features must be int or flaot.')
        quantile = transform_params_type(kwargs.get("quantile"), float, 0.01)
        multiplier = transform_params_type(kwargs.get("multiplier"), float, 1.5)

        use_iso_forest = transform_params_type(kwargs.get("use_iso_forest"), bool, True)
        use_iqr = transform_params_type(kwargs.get("use_iqr"), bool, True)
        if use_iso_forest:
            input_init = remove_outliers_iso_forest(df=input_init, cols=analog_cols, n_estimators=n_estimators,
                                                    contamination=contamination, max_features=max_features, quantile=quantile)
        if use_iqr:
            input_init = remove_outliers_iqr(df=input_init, cols=analog_cols, multiplier=multiplier)

    input_init.dropna(inplace=True)
    input_init.reset_index(inplace=True)

    return {"data": input_init}


if __name__ == '__main__':
    App.run(filter)
