import os
import sys
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, StringOfDict, StringOfList, File
from sushineAI.component import Component
from sushineAI.app import App

def make_regression_estimation(data, kwargs):
    y_true = data[kwargs.get('标签字段')]
    y_pred = data[kwargs.get('预测字段')]

    action = {'r2_score': r2_score, 'mean_absolute_error': mean_absolute_error,
              'mean_squared_error': mean_squared_error}

    indicator = kwargs.get('评估指标')

    if len(indicator) == 0:
        raise Exception('ValueError: 评估指标为空')
    print("#############################")
    indicator = indicator.split(',')
    a = [print(x) for x in indicator]
    scores = {}
    for t_column, p_column in zip(y_true.columns, y_pred.columns):
        scores[t_column] = {x: action[x](y_true[t_column], y_pred[p_column]) for x in indicator}

    return scores


@Component.inputs(Csv(key="input1"))
@Component.params(StringOfDict(key=['评估指标']))
@Component.columns(StringOfList(key="标签字段"), StringOfList(key='预测字段'))
@Component.outputs(File(key="output1", file_type='Json'))
def regression_estimation(**kwargs):
    input1 = kwargs.get('input1')

    scores = make_regression_estimation(input1, kwargs)

    return {'output1': scores}


if __name__ == '__main__':
    App.run(regression_estimation)
