"""
sklearn模型保存为服务组件
"""
from argparse import ArgumentParser
import re
import json
import requests
from loguru import logger
from base64 import b64decode
from sushineAI.argument import StringOfDict, Xlsx, Model,File
from sushineAI.component import Component
from sushineAI.app import App

# 加载原始参数
parser = ArgumentParser()
parser.add_argument("--input_ports", type=str, default="[]")  # 输入端口
parser.add_argument("--output_ports", type=str, default="[]")  # 输出端口
parser.add_argument("--node_params", type=str, default="[]")  # 节点参数
args,_ = parser.parse_known_args()
# 读取参数文件列表地址
model_file_url = ""
loader_file_url = ""

# 读取模型文件列表
param_config_file_url = ""
args_str = getattr(args, "input_ports").strip()
if not re.match(r"^\[.*]$", args_str):  # 如果不是json格式的数组数据, 尝试用base64解码
    try:
        args_str = b64decode(args_str).decode("utf-8")
        logger.debug(f"input_ports (decoded): {args_str}")
    except Exception as e:
        raise ValueError(f"Failed to decode input_ports as base64") from e
input_ports = json.loads(args_str)
for i, item in enumerate(input_ports):  # 遍历数组对象
    if item["id"] == 'model_file':
        model_file_url = item["fileCloudPath"]
    if item["id"] == 'loader_file':
        loader_file_url = item["fileCloudPath"]
    if item["id"] == 'param_config':
        param_config_file_url = item["fileCloudPath"]


@Component.params(StringOfDict(key=['_flowNo','_nodeNo','_tenantNo','_userId','服务地址','服务名称', '生成规则', '是否自动上线']))
@Component.outputs(File(key='result', file_type='Json'))
def sklearn_service(**kwargs):
    service_address = kwargs.get('服务地址') + "/rest/di/service/saveFromFlow"
    service_name = kwargs.get('服务名称')
    service_rule = kwargs.get('生成规则')
    auto_online = kwargs.get('是否自动上线')
    
    param = {
        "serviceName": service_name,
        "serviceRule": service_rule,
        "autoOnline": auto_online,
        "paramConfigFileUrl": param_config_file_url,
        "modelFileUrl": model_file_url,
        "loaderFileUrl": loader_file_url,
        # 公共参数
        "flowNo": kwargs.get('_flowNo'),
        "nodeNo": kwargs.get('_nodeNo'),
        "tenantNo": kwargs.get('_tenantNo'),
        "userId": kwargs.get('_userId')
    }
    print(param)
    headers = {
        "Content-Type": "application/json"
    }
    data = requests.post(url = service_address, json=param)
    print(data.text)
    return {'result': data.text}


if __name__ == '__main__':
    print(model_file_url)
    print(param_config_file_url)
    App.run(sklearn_service)
