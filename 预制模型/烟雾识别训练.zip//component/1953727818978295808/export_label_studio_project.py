"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: export_label_studio_project.py
@time: 2025/8/8 16:06
@desc:
"""
import os
import time
import zipfile
from pathlib import Path

import requests
from label_studio_sdk import Client
from sushineAI.app import App
from sushineAI.argument import File, StringOfDict
from sushineAI.component import Component


# =================== 辅助函数 ===================
def wait_for_export_completion(base_url, project_id, api_token, headers, timeout=300):
    """轮询导出状态，直到完成"""
    poll_url = f"{base_url}/api/projects/{project_id}/export"
    start_time = time.time()

    while time.time() - start_time < timeout:
        print("⏳ 等待导出完成...")
        time.sleep(3)
        response = requests.get(poll_url, headers=headers, params={'exportType': 'YOLO_WITH_IMAGES'})
        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')
            if 'application/zip' in content_type:
                # 已完成，返回当前响应的 URL（或直接用内容）
                return f"{base_url}/api/projects/{project_id}/export?exportType=YOLO_WITH_IMAGES"
    return None


def download_file(url, dest, headers):
    """下载文件"""
    response = requests.get(url, headers=headers, stream=True)
    response.raise_for_status()
    with open(dest, 'wb') as f:
        for chunk in response.iter_content(8192):
            f.write(chunk)


@Component.outputs(
    File(key="images.zip", file_type="Any"),
    File(key="labels.zip", file_type="Any"),
    File(key="class", file_type="Json")
)
@Component.params(StringOfDict(key=['prefix', 'project_name', 'token']))
def main_business(**kwargs):
    # =================== 配置参数 ===================
    LABEL_STUDIO_URL = kwargs.get("prefix").rstrip("/")  # 去掉末尾 /
    API_TOKEN = kwargs.get("token")
    PROJECT_NAME = kwargs.get("project_name").split(",")

    # 输出文件路径
    images_zip = "images.zip"
    labels_zip = "labels.zip"
    temp_dir = Path("export_temp")
    temp_dir.mkdir(exist_ok=True)
    full_zip = temp_dir / "yolo_full.zip"
    # 临时目录
    export_dir = Path("exported_data")
    export_dir.mkdir(exist_ok=True)
    images_dir = export_dir / "images"
    labels_dir = export_dir / "labels"
    images_dir.mkdir(exist_ok=True)
    labels_dir.mkdir(exist_ok=True)

    # =================== 初始化 Label Studio 客户端 ===================
    ls = Client(url=LABEL_STUDIO_URL, api_key=API_TOKEN)
    try:
        ls.check_connection()
    except Exception as e:
        raise RuntimeError(f"❌ 连接 Label Studio 失败: {e}")

    # =================== 查找项目 ===================
    projects = []
    for p in ls.get_projects():
        if p.params['title'] in PROJECT_NAME:
            projects.append(p)
    if not projects:
        raise ValueError(f"❌ 项目 '{PROJECT_NAME}' 不存在")
    
    for project in projects:
        # API 端点
        export_url = f"{LABEL_STUDIO_URL}/api/projects/{project.params['id']}/export"
        params = {'exportType': 'YOLO_WITH_IMAGES'}
        headers = {'Authorization': f'Token {API_TOKEN}'}

        # =================== 发起导出请求 ===================
        print("🔄 正在请求导出 YOLO 数据...")
        response = requests.get(export_url, headers=headers, params=params, stream=True)

        # 检查是否需要异步等待（Label Studio 会返回 200 但内容是 JSON 表示“正在生成”）
        if response.status_code == 200:
            # 检查内容是 zip 还是 JSON
            content_type = response.headers.get('Content-Type', '')
            if 'application/zip' in content_type:
                # 导出已完成，直接下载
                print("✅ 导出已完成，正在下载...")
                with open(full_zip, 'wb') as f:
                    for chunk in response.iter_content(8192):
                        f.write(chunk)
            elif 'application/json' in content_type:
                # 导出任务已创建，需轮询等待完成
                download_url = wait_for_export_completion(LABEL_STUDIO_URL, project.params['id'], API_TOKEN, headers)
                if not download_url:
                    raise RuntimeError("❌ 导出未完成或失败")
                # 下载最终文件
                download_file(download_url, full_zip, headers)
        else:
            raise RuntimeError(f"❌ 导出请求失败: {response.status_code} - {response.text}")

        # =================== 解压并分离文件 ===================
        print("📦 解压并分离图像和标签...")
        with zipfile.ZipFile(full_zip, 'r') as z:
            z.extractall(temp_dir)

        # 假设结构: dataset/images/, dataset/labels/
        dataset_dir = temp_dir / "dataset"
        if not dataset_dir.exists():
            dataset_dir = temp_dir  # 兼容旧版本结构

        # 移动文件
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}
        for root, _, files in os.walk(dataset_dir):
            for file in files:
                src = Path(root) / file
                if file.lower().endswith(tuple(image_extensions)):
                    dst = images_dir / file
                    os.rename(src, dst)
                elif file.endswith('.txt') and file != 'classes.txt':
                    dst = labels_dir / file
                    os.rename(src, dst)
                elif file == 'classes.txt':
                    with open(dataset_dir / file, 'r') as f:
                        classes = f.read().strip().split("\n")

    # =================== 打包成两个 zip ===================
    def make_zip(folder, zip_name):
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as z:
            for file in Path(folder).rglob('*'):
                if file.is_file():
                    z.write(file, file.relative_to(folder.parent))

    make_zip(images_dir, images_zip)
    make_zip(labels_dir, labels_zip)

    # =================== 清理 ===================
    import shutil
    shutil.rmtree(temp_dir)

    print("✅ 导出完成！")
    images_zip = open(images_zip, 'rb')
    labels_zip = open(labels_zip, 'rb')
    return {
        "images.zip": images_zip.read(),
        "labels.zip": labels_zip.read(),
        "class":classes
    }


if __name__ == '__main__':
    App.run(main_business)
