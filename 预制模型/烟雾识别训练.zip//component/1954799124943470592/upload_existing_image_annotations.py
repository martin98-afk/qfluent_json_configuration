"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: upload_existing_image_annotations.py
@time: 2025/8/29 09:03
@desc: 
"""
"""
算法包代码示例
"""
import glob
import os
import zipfile
from pathlib import Path

from PIL import Image
from label_studio_sdk import Client
from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.argument import StringOfDict
from sushineAI.component import Component


def generate_distinct_colors(classes):
    """
    为多个类别生成视觉上易区分的颜色
    使用 HSL 模型，均匀分布色相，固定饱和度和亮度
    """
    n = len(classes)
    colors = {}

    # 如果类别少，用预定义鲜艳颜色
    predefined = [
        "#e6194b", "#3cb44b", "#ffe119", "#0082c8", "#f58231",
        "#911eb4", "#46f0f0", "#f032e6", "#d2f53c", "#fabebe"
    ]

    if n <= 10:
        color_pool = predefined
    else:
        # 多类别：均匀分布在 0~360 色相环上
        color_pool = []
        for i in range(n):
            hue = int((i * 360 / n) % 360)  # 均匀分布
            saturation = 75  # 高饱和，但不过曝
            lightness = 60  # 适中偏亮，避免太暗

            # HSL to RGB
            h = hue / 360
            s = saturation / 100
            l = lightness / 100

            c = (1 - abs(2 * l - 1)) * s
            x = c * (1 - abs((h * 6) % 2 - 1))
            m = l - c / 2

            if 0 <= h < 1 / 6:
                r, g, b = c, x, 0
            elif 1 / 6 <= h < 2 / 6:
                r, g, b = x, c, 0
            elif 2 / 6 <= h < 3 / 6:
                r, g, b = 0, c, x
            elif 3 / 6 <= h < 4 / 6:
                r, g, b = 0, x, c
            elif 4 / 6 <= h < 5 / 6:
                r, g, b = x, 0, c
            else:
                r, g, b = c, 0, x

            r = int((r + m) * 255)
            g = int((g + m) * 255)
            b = int((b + m) * 255)

            color = "#{:02x}{:02x}{:02x}".format(r, g, b)
            color_pool.append(color)

    # 分配颜色
    for i, class_name in enumerate(classes):
        colors[class_name] = color_pool[i % len(color_pool)]

    return colors


def create_project(ls, project_name, classes):
    # 检查是否已存在同名项目
    for project in ls.get_projects():
        if project.params['title'] == project_name:
            print(f"✅ 项目已存在: {project}")
            return project

    # 生成高区分度颜色
    class_colors = generate_distinct_colors(classes)

    # 打印颜色映射（方便调试）
    print("🎨 颜色分配：")
    for cls, color in class_colors.items():
        print(f"  {cls}: {color}")

    # 创建新项目
    project = ls.start_project(
        title=project_name,
        label_config=f"""
        <View>
          <Image name="image" value="$image"/>

          <RectangleLabels name="label" toName="image">
            """ + "\n".join(
            [f'<Label value="{class_name}" background="{class_colors[class_name]}"/>' for class_name in classes]) + """
          </RectangleLabels>
        </View>"""
    )
    print(project.params)
    print(f"🎉 创建新项目成功: {project}")
    return project


def process_trainset(kwargs):
    print("############################")
    images, labels = kwargs.get('images'), kwargs.get('labels')

    os.makedirs('images')
    # 定义支持的图片扩展名（小写）
    IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg']

    with zipfile.ZipFile(images.name, 'r') as zip_ref:
        for f in zip_ref.infolist():
            # 获取文件名（处理路径分隔符）
            original_filename = f.filename.replace('\\', '/')  # 统一转换为正斜杠
            base_name = os.path.basename(original_filename)  # 提取纯文件名（含扩展名）

            # 检查是否为图片文件
            if '.' in base_name and os.path.splitext(base_name)[1].lower() in IMAGE_EXTENSIONS:
                # 修改提取路径：所有图片统一放入 'images/' 目录下
                f.filename = 'images/' + base_name
                zip_ref.extract(f)

    # 定义支持的标签扩展名（小写）
    LABEL_EXTENSIONS = ['.txt']

    with zipfile.ZipFile(labels.name, 'r') as zip_ref:
        for f in zip_ref.infolist():
            # 获取文件名（处理路径分隔符）
            original_filename = f.filename.replace('\\', '/')  # 统一转换为正斜杠
            base_name = os.path.basename(original_filename)  # 提取纯文件名（含扩展名）

            # 检查是否为标签文件
            if '.' in base_name and os.path.splitext(base_name)[1].lower() in LABEL_EXTENSIONS:
                # 修改提取路径：所有图片统一放入 'images/' 目录下
                f.filename = 'labels/' + base_name
                zip_ref.extract(f)


@Component.inputs(File(key="images", file_type="Any"), File(key="labels", file_type="Any"))
@Component.params(StringOfDict(key=['prefix', 'project_name', 'token', 'class']))
def main_business(**kwargs):
    # =================== 配置参数 ===================
    LABEL_STUDIO_URL = kwargs.get("prefix").rstrip("/")  # 去掉末尾 /
    API_TOKEN = kwargs.get("token")
    PROJECT_NAME = kwargs.get("project_name")

    # =================== 初始化 Label Studio 客户端 ===================
    ls = Client(url=LABEL_STUDIO_URL, api_key=API_TOKEN)
    try:
        ls.check_connection()
    except Exception as e:
        raise RuntimeError(f"❌ 连接 Label Studio 失败: {e}")

    # =================== 查找项目 ===================
    project = None
    for p in ls.get_projects():
        if p.params['title'] == PROJECT_NAME:
            project = p
            break
    if not project:
        project = create_project(ls, PROJECT_NAME, kwargs.get("class").split(","))

    process_trainset(kwargs)
    label_dict = {
        "fire": 0,
        "smoke": 1
    }

    label_reverse = {index: name for name, index in label_dict.items()}

    images_path = r"./images/*"
    labels_path = r"./labels/"
    for file in glob.glob(images_path):
        print("file:", file)
        ids = project.import_tasks(Path(file))
        suffix = os.path.splitext(os.path.basename(file))[0]
        img_path = os.path.basename(file)
        image = Image.open(file)
        width, height = image.size
        labels_file = os.path.join(labels_path, f"{suffix}.txt")
        with open(labels_file, "r") as f:
            lines = f.readlines()
        results = []
        for line in lines:
            label_index, x, y, w, h = map(float, line.strip().split(" "))
            label = label_reverse[int(label_index)]
            x1 = (x - w / 2) * 100
            y1 = (y - h / 2) * 100
            w1 = w * 100
            h1 = h * 100
            if label in kwargs.get("class").split(","):
                results.append(
                    {
                        "from_name": "label",
                        "to_name": "image",
                        "type": "rectanglelabels",
                        "value": {
                            "rectanglelabels": [label],
                            "x": x1,
                            "y": y1,
                            "width": w1,
                            "height": h1
                        }
                    }
                )
        project.create_prediction(
            task_id=ids[0],
            model_version="custom_model",
            result=results
        )


if __name__ == '__main__':
    App.run(main_business)
