"""
@author: TangXC
@license: (C) Copyright 1999-2019, NJ_LUCULENT Corporation Limited.
@contact: tangxucheng@luculent.net
@file: yolo_gen_detect.py
@time: 2024/9/2 15:30
@desc:
"""
import yaml
import sys
from ultralytics import YOLO
import os
import shutil
import zipfile
from random import shuffle
from PIL import Image

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, StringOfDict, StringOfList, Model, String, File
from sushineAI.utils.translator import transform_params_type
from sushineAI.component import Component
from sushineAI.app import App


def seed_everything(seed: int = 1):
    import torch
    import random
    import os
    import numpy as np
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def process_trainset(kwargs):
    print("############################")
    images, labels = kwargs.get('images'), kwargs.get('labels')

    os.makedirs('images')
    # 定义支持的图片扩展名（小写）
    IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg']

    with zipfile.ZipFile(images.name, 'r') as zip_ref:
        for f in zip_ref.infolist():
            # 获取文件名（处理路径分隔符）
            original_filename = f.filename.replace('\\', '/')  # 统一转换为正斜杠
            base_name = os.path.basename(original_filename)   # 提取纯文件名（含扩展名）

            # 检查是否为图片文件
            if '.' in base_name and os.path.splitext(base_name)[1].lower() in IMAGE_EXTENSIONS:
                # 修改提取路径：所有图片统一放入 'images/' 目录下
                f.filename = 'images/' + base_name
                zip_ref.extract(f)
    
    # 定义支持的标签扩展名（小写）
    LABEL_EXTENSIONS = ['.txt']

    with zipfile.ZipFile(labels.name, 'r') as zip_ref:
        for f in zip_ref.infolist():
            # 获取文件名（处理路径分隔符）
            original_filename = f.filename.replace('\\', '/')  # 统一转换为正斜杠
            base_name = os.path.basename(original_filename)   # 提取纯文件名（含扩展名）

            # 检查是否为标签文件
            if '.' in base_name and os.path.splitext(base_name)[1].lower() in LABEL_EXTENSIONS:
                # 修改提取路径：所有图片统一放入 'images/' 目录下
                f.filename = 'labels/' + base_name
                zip_ref.extract(f)


def make_object_detection(kwargs):
    epochs = transform_params_type(kwargs.get("epochs"), int, 20)
    batch_size = transform_params_type(kwargs.get("batch_size"), int, 16)
    device = transform_params_type(kwargs.get('device'), str, "cuda:3")
    name = transform_params_type(kwargs.get('任务名'), str, 'obj-detect')
    val_percent = transform_params_type(kwargs.get('验证集比例'), float, "0.2")
    current_path = os.getcwd()

    # 分割训练集和验证集,注意文件夹结构
    image_list = os.listdir(os.path.join(current_path, "images"))
    shuffle(image_list)
    val_list = image_list[:int(val_percent * len(image_list))]
    train_list = image_list[int(val_percent * len(image_list)):]
    shutil.rmtree("valset/", ignore_errors=True)
    shutil.rmtree("trainset/", ignore_errors=True)
    os.makedirs("valset/images", exist_ok=True)
    os.makedirs("valset/labels", exist_ok=True)
    os.makedirs("trainset/images", exist_ok=True)
    os.makedirs("trainset/labels", exist_ok=True)
    for val in val_list:
        shutil.copy(os.path.join("images", val), os.path.join("valset/images", val))
        label_name = os.path.splitext(val)[0] + ".txt"
        shutil.copy(os.path.join("labels", label_name), os.path.join("valset/labels", label_name))
    for train in train_list:
        shutil.copy(os.path.join("images", train), os.path.join("trainset/images", train))
        label_name = os.path.splitext(train)[0] + ".txt"
        shutil.copy(os.path.join("labels", label_name), os.path.join("trainset/labels", label_name))

    # 写入训练集和测试集文件
    with open(os.path.join("valset", "val.txt"), "w+", encoding='utf-8') as fw:
        for img_name in val_list:
            fw.write(current_path + "/valset/images/" + img_name + "\n")
    with open(os.path.join("trainset", "train.txt"), "w+", encoding='utf-8') as fw:
        for img_name in train_list:
            fw.write(current_path + "/trainset/images/" + img_name + "\n")
    # 生成yaml文件
    num_classes = transform_params_type(len(kwargs.get("class")), int, 1)
    yaml_content = {
        "train": current_path + "/trainset/train.txt",
        "val": current_path + "/valset/val.txt",
        "nc": num_classes,
    }
    names = kwargs.get("class")
    yaml_content.update({"names": names})
    with open("config.yaml", "w+", encoding='utf-8') as fw:
        yaml.dump(yaml_content, fw)
    pre_model = kwargs.get('pre_model').name
    os.rename(pre_model, "yolo.pt")

    # 选择yolo预训练模型
    model = YOLO('yolo.pt')
    # use the model
    model.train(data=current_path + "/config.yaml",
                save=True,
                epochs=epochs,
                device=device,
                exist_ok=True,
                name=name,
                nms=True,
                # amp=False,
                batch=min(batch_size, 32, len(train_list) // 8),
                resume=bool(int(kwargs.get("resume"))))

    return model


@Component.params(StringOfDict(
    key=['epochs', 'device', '标签数量', '任务名', '验证集比例', 'random_state',
         'class_name', 'resume', 'task_name', 'batch_size']))
@Component.inputs(File(key="images", file_type='Any'), File(key="class", file_type='Json'))
@Component.inputs(File(key="labels", file_type='Any'))
@Component.inputs(File(key="pre_model", file_type='Any'))
@Component.outputs(File(key='best.pt', file_type='Any'))
@Component.outputs(File(key='val_result', file_type='Image'))
def train_objectdetection(**kwargs):
    process_trainset(kwargs)
    # 固定随机种子
    random_state = int(kwargs.get("random_state"))
    seed_everything(random_state)
    model = make_object_detection(kwargs)
    task_name = kwargs.get("task_name")
    name = transform_params_type(kwargs.get('任务名'), str, 'obj-detect')
    # 读取验证图像
    with open(f"runs/{task_name}/{name}/val_batch0_pred.jpg", "rb") as fp:
        res = Image.open(fp).convert('RGB')
    # 找到训练保存模型
    current_path = os.getcwd()
    model_path = os.path.join(current_path, f"runs/{task_name}/{name}/weights/")
    for root, dirs, files in os.walk(model_path):
        for file in files:
            if file.endswith('best.pt'):
                # 获取文件的完整路径
                file_path = os.path.join(root, file)

    with open(file_path, "rb") as fm:
        return {"val_result": res, "best.pt": fm.read()}


if __name__ == '__main__':
    App.run(train_objectdetection)
