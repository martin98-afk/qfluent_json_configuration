"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: yolo_pt2onnx.py
@time: 2024/11/12 11:28
@desc: 
"""
import os
from ultralytics import YOLO
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import File, StringOfDict


@Component.inputs(File(key="model", file_type="Any"))
@Component.params(StringOfDict(key=['dynamic', 'quantization']))
@Component.outputs(File(key="model.onnx", file_type="Any"))
def main_business(**kwargs):
    model = kwargs.get('model')

    os.rename(model.name, "yolo.pt")
    # Load a model
    model = YOLO("yolo.pt")  # load a custom trained model
    dynamic = bool(int(kwargs.get("dynamic")))
    quantization = kwargs.get("quantization")
    # Export the model
    if quantization == "half":
        model.export(format="onnx", dynamic=dynamic, half=True)
    elif quantization == "int8":
        model.export(format="onnx", dynamic=dynamic, int8=True)

    with open("yolo.onnx", 'rb') as f:
        return {
            'model.onnx': f.read()
        }


if __name__ == '__main__':
    App.run(main_business)
