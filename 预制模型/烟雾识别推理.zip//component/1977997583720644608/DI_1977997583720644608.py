from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.component import Component

SMOKE_DETECT_SETTINGS = """
# ==================== 配置 ====================
RTSP_URL = "{rtsp_url}"
DETECT_CLASS = "{detect_class}"
BASE_URL = "{zone_api_base_url}"
device = "{device}"
SERVICE_ID = "{service_id}"
CONFIDENCE = {confidence}
POLL_INTERVAL = 5  # seconds between zone fetches

# ZLMediaKit 配置
ZLMEDIAKIT_HOST = "{zlmediakit_host}"
ZLMEDIAKIT_PORT = {zlmediakit_port}
ZLMEDIAKIT_SECRET = "{zlmediakit_key}"
ZLMEDIAKIT_TIMEOUT_SEC = 10
ZLMEDIAKIT_EXPIRE_SEC = 0
SNAPSHOT_INTERVAL = 0.2  # 200ms 一次截图，可调

TAG_NAME = "{tag_name}"
KAFKA_CONFIG = {{
    "bootstrap.servers": "{kafka}",
    "group.id": "ai-service-push",
    "auto.offset.reset": "earliest"
}}
"""

SMOKE_DETECT = """
PUSH_TEMPLATE = {
    'code': 0,
    'message': 'success',
    'timestamp': 1722054181043,
    'data': {
        'flag': True,
        'detail': 'error',
        'result': [],
        'outputParams': [
            {
                'paramName': TAG_NAME,
                'paramType': 'float',
                'paramDesc': '烟雾侵占区域面积',
            },
            {
                'paramName': 'timestamp',
                'paramType': 'str',
                'paramDesc': '',
            }
        ]
    }
}

import time
import httpx
import numpy as np
import base64
import cv2
import os
import json
import threading
import urllib.parse
from typing import List
from threading import Thread
from ultralytics import YOLO
from loguru import logger
from sushineAI import Processor

# URL 编码 RTSP 地址（关键！）
RTSP_URL_ENCODED = urllib.parse.quote(RTSP_URL, safe='')
SNAP_URL = (
    f"http://{ZLMEDIAKIT_HOST}:{ZLMEDIAKIT_PORT}/index/api/getSnap?"
    f"url={RTSP_URL_ENCODED}&timeout_sec={ZLMEDIAKIT_TIMEOUT_SEC}&"
    f"expire_sec={ZLMEDIAKIT_EXPIRE_SEC}&secret={ZLMEDIAKIT_SECRET}"
)


# ==================== 辅助函数 ====================
def image_to_base64(image: np.ndarray) -> str:
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')


# ==================== 后台线程：持续获取截图 ====================
class SnapshotFetcher(Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._frame_lock = threading.Lock()
        self._latest_frame = None
        self._latest_ts = None
        self._frame_id = 0  # 新增：帧ID，每次获取新图递增

    def get_latest_unprocessed_frame(self, last_processed_id):
        \"\"\"返回比 last_processed_id 更新的帧，否则返回 None\"\"\"
        with self._frame_lock:
            if self._frame_id > last_processed_id and self._latest_frame is not None:
                return self._latest_frame.copy(), self._latest_ts, self._frame_id
            else:
                return None, None, last_processed_id

    def run(self):
        logger.info("SnapshotFetcher 线程启动，开始轮询 ZLMediaKit 截图...")
        while not self._stop_event.is_set():
            try:
                with httpx.Client(timeout=10) as client:
                    resp = client.get(SNAP_URL)
                    if resp.status_code == 200:
                        img_array = np.frombuffer(resp.content, dtype=np.uint8)
                        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                        if frame is not None:
                            with self._frame_lock:
                                self._latest_frame = frame
                                self._latest_ts = time.perf_counter()
                                self._frame_id += 1  # 关键：新帧，ID递增
                            logger.debug(f"成功获取新截图，frame_id={self._frame_id}")
                        else:
                            logger.warning("截图解码失败")
                    else:
                        logger.error(f"getSnap 返回错误: {resp.status_code}")
            except Exception as e:
                logger.error(f"获取截图异常: {e}")
                logger.error(traceback.format_exc())
            time.sleep(0.2)

    def stop(self):
        self._stop_event.set()


# ==================== 区域获取线程（保持不变） ====================
class ZoneFetcher(Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self.zone_cache = {}

    def fetch_zone(self, service_id):
        try:
            with httpx.Client(base_url=BASE_URL, timeout=10) as client:
                resp = client.get(
                    f"/rest/video/camera/config/getRecogSphere?serviceId={service_id}"
                )
                resp.raise_for_status()
                data = resp.json().get("data", "{}")
            zone = json.loads(data)
            parsed = {
                key: [float(v) for v in val.split(',')]
                for key, val in zone.items()
            }
            self.zone_cache[service_id] = [
                [parsed['vertexPos1'][0], parsed['vertexPos1'][1]],
                [parsed['vertexPos2'][0], parsed['vertexPos2'][1]]
            ]
            logger.info(f"Fetched zone for {service_id}: {self.zone_cache[service_id]}")
        except Exception:
            logger.error(f"Failed to fetch zone for {service_id}, using full frame.")
            self.zone_cache[service_id] = [[0, 0], [100, 100]]

    def _remove_image(self):
        cutoff = time.time() - 86400
        for root, _, files in os.walk('.', topdown=False):
            for f in files:
                if f.endswith('.jpg'):
                    path = os.path.join(root, f)
                    if os.path.getmtime(path) < cutoff:
                        os.remove(path)

    def run(self):
        while not self._stop_event.is_set():
            try:
                self.fetch_zone(SERVICE_ID)
                self._remove_image()
                logger.info("历史图像已移除")
                time.sleep(POLL_INTERVAL)
            except:
                import traceback
                logger.error(traceback.format_exc())

    def stop(self):
        self._stop_event.set()


# ==================== 主模型类 ====================
class Model(Processor):
    def __init__(self):
        self.model = None
        self.snapshot_fetcher = None
        self.zone_fetcher = None
        self.detect_zone = None
        self._inference_thread = None
        self._stop_inference = threading.Event()  # 控制推理线程停止
        self.last_processed_frame_id = 0  # 新增：记录上次处理的帧ID
        self.stats = {
            'read_latency': [],
            'validate_zone': [],
            'inference': [],
            'postprocess': []
        }

    def load(self, model_path):
        if not model_path.endswith((".onnx", ".engine")):
            os.rename(model_path, "yolo.pt")
            self.model = YOLO("yolo.pt", task="detect")
        else:
            self.model = YOLO(model_path, task="detect")

        dummy_img = np.zeros((640, 640, 3), dtype=np.uint8)
        self.model(dummy_img, device=device, verbose=False)

        self.snapshot_fetcher = SnapshotFetcher()
        self.snapshot_fetcher.start()

        self.zone_fetcher = ZoneFetcher()
        self.zone_fetcher.start()

        # 启动推理线程（关键！不再阻塞主线程）
        self._stop_inference.clear()
        self._inference_thread = threading.Thread(target=self._inference_loop, daemon=True)
        self._inference_thread.start()

        logger.info("Model loaded. Background threads started.")

    def _inference_loop(self):
        \"\"\"独立的推理循环线程\"\"\"
        logger.info("推理线程启动...")
        while not self._stop_inference.is_set():
            try:
                result = self.detect()
                if result:
                    # 更新模板时间戳
                    PUSH_TEMPLATE["timestamp"] = int(time.time() * 1000)
                    PUSH_TEMPLATE["data"]["result"] = result
                    self.push_to_kafka(PUSH_TEMPLATE)
            except Exception as e:
                logger.error(f"推理循环异常: {e}")
                logger.error(traceback.format_exc())
            time.sleep(0.2)  # 可根据实际帧率调整
        logger.info("推理线程已停止")

    def detect(self):
        try:
            now = time.time()
            t_start = time.perf_counter()

            # 获取比 last_processed_frame_id 更新的帧
            frame, frame_ts, frame_id = self.snapshot_fetcher.get_latest_unprocessed_frame(self.last_processed_frame_id)
            if frame is None:
                # 没有新帧，跳过
                return None

            # === 处理该帧 ===
            read_latency = t_start - frame_ts
            self.stats['read_latency'].append(read_latency)
            if read_latency > 1.2:
                logger.warning(f"截图过期 ({read_latency:.2f}s)，跳过检测")
                # 注意：即使过期，也视为“已处理”，避免卡住
                self.last_processed_frame_id = frame_id
                return None

            # 验证区域
            t0 = time.perf_counter()
            self.detect_zone = self._validate_detect_zone(frame.shape)
            t1 = time.perf_counter()
            self.stats['validate_zone'].append(t1 - t0)

            # 推理
            t0 = time.perf_counter()
            results = self.model(frame, device=device, verbose=False, conf=CONFIDENCE)
            t1 = time.perf_counter()
            self.stats['inference'].append(t1 - t0)

            res = next(iter(results), None)
            if not res:
                logger.info("no detect result!")
                logger.info(
                    f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
                    f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
                    f"infer: {self.stats['inference'][-1] * 1000:.1f} ms"
                )
                self.last_processed_frame_id = frame_id  # 标记已处理
                return [0, now]

            # 后处理
            t0 = time.perf_counter()
            area_ratio = self._calculate_smoke_area(res, frame, now)
            t1 = time.perf_counter()
            self.stats['postprocess'].append(t1 - t0)

            logger.info(
                f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
                f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
                f"infer: {self.stats['inference'][-1] * 1000:.1f} ms  "
                f"post: {self.stats['postprocess'][-1] * 1000:.1f} ms"
            )

            # 标记该帧已处理！
            self.last_processed_frame_id = frame_id

            return [round(area_ratio, 4) * 100, now]

        except Exception:
            logger.error(f"Failed to detect smoke: {traceback.format_exc()}")
            return None

    def push_to_kafka(self, v):
        from kafka import KafkaProducer
        producer = KafkaProducer(
            bootstrap_servers=KAFKA_CONFIG['bootstrap.servers'],
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            api_version=(0, 10, 1)
        )
        producer.send(KAFKA_CONFIG['group.id'], v)

    def _validate_detect_zone(self, shape):
        h, w = shape[:2]
        raw = self.zone_fetcher.zone_cache.get(SERVICE_ID, [[0, 0], [100, 100]])
        zone = [[int(p[0] / 100 * w), int(p[1] / 100 * h)] for p in raw]
        x1, y1 = np.min(zone, axis=0)
        x2, y2 = np.max(zone, axis=0)
        logger.info(f"框选识别区域：左上角 ({x1}, {y1}), 右下角 ({x2}, {y2})")
        return np.array([[x1, y1], [x2, y2]], dtype=int)

    def _save_image(self, image: np.ndarray, timestamp):
        cv2.imwrite(f"{timestamp}.jpg", image)

    def predict(self, data: List):
        try:
            ts_req = data[0]
            if ts_req:
                img = self._read_image(ts_req)
                return [0, image_to_base64(img)] if img is not None else [0, "image not found!"]

        except Exception as e:
            import traceback
            logger.error(traceback.format_exc())
            return [0, time.time()]

    def _calculate_smoke_area(self, result, image, timestamp):
        # === 完全保留你原来的逻辑 ===
        if len(result.boxes) == 0:
            return 0.0

        boxes = result.boxes.xyxy.cpu().numpy()
        confidences = result.boxes.conf.cpu().numpy()
        classes = result.boxes.cls.cpu().numpy()
        names_list = result.names

        smoke_boxes = []
        can_boxes = []
        confidence = []

        for i, (conf, cls_id) in enumerate(zip(confidences, classes)):
            label = names_list[int(cls_id)]
            box = boxes[i]
            if label == DETECT_CLASS:
                confidence.append(conf)
                smoke_boxes.append(box)
            elif label == "can":
                can_boxes.append(box)

        if len(smoke_boxes) == 0:
            return 0.0

        smoke_boxes = np.array(smoke_boxes)
        can_boxes = np.array(can_boxes) if len(can_boxes) > 0 else []

        zone_x1 = self.detect_zone[0][0]
        zone_y1 = self.detect_zone[0][1]
        zone_x2 = self.detect_zone[1][0]
        zone_y2 = self.detect_zone[1][1]

        detect_zone_area = (zone_x2 - zone_x1) * (zone_y2 - zone_y1)
        if detect_zone_area <= 0:
            return 0.0

        MAX_HANGING_RATIO = 0.6
        HORIZONTAL_OVERLAP_RATIO = 0.3
        MIN_SMOKE_AREA = 100

        ambient_smoke_boxes = []
        smoke_from_can_boxes = []
        ambient_smoke_confidence = []
        for conf, smoke in zip(confidence, smoke_boxes):
            sx1, sy1, sx2, sy2 = smoke
            smoke_area = (sx2 - sx1) * (sy2 - sy1)
            if smoke_area < MIN_SMOKE_AREA:
                continue

            matched = False
            for can in can_boxes:
                cx1, cy1, cx2, cy2 = can
                can_height = cy2 - cy1

                if sy1 > cy2:
                    continue

                overlap_x1 = max(sx1, cx1)
                overlap_x2 = min(sx2, cx2)
                if overlap_x1 >= overlap_x2:
                    continue

                overlap_width = overlap_x2 - overlap_x1
                min_width = min(cx2 - cx1, sx2 - sx1)
                if overlap_width / min_width < HORIZONTAL_OVERLAP_RATIO:
                    continue

                smoke_from_can_boxes.append(smoke)
                matched = True
                break

            if not matched:
                ambient_smoke_confidence.append(conf)
                ambient_smoke_boxes.append(smoke)

        cv2.rectangle(image, (zone_x1, zone_y1), (zone_x2, zone_y2), (255, 0, 0), 8)

        for conf, smoke in zip(ambient_smoke_confidence, ambient_smoke_boxes):
            x1, y1, x2, y2 = map(int, smoke)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 8)
            cv2.putText(image, f"smoke {conf:.2f}", (x1 + 30, y1 + 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 8)

        for smoke in smoke_from_can_boxes:
            x1, y1, x2, y2 = map(int, smoke)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 255), 8)
            cv2.putText(image, "smoke (can)", (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 8)

        for can in can_boxes:
            x1, y1, x2, y2 = map(int, can)
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 255, 0), 8)
            cv2.putText(image, "can", (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 8)

        if len(ambient_smoke_boxes) == 0:
            return 0.0

        ambient_smoke_boxes = np.array(ambient_smoke_boxes)

        x1 = np.maximum(ambient_smoke_boxes[:, 0], zone_x1)
        y1 = np.maximum(ambient_smoke_boxes[:, 1], zone_y1)
        x2 = np.minimum(ambient_smoke_boxes[:, 2], zone_x2)
        y2 = np.minimum(ambient_smoke_boxes[:, 3], zone_y2)
        valid = (x2 > x1) & (y2 > y1)
        if not np.any(valid):
            return 0.0

        x1, y1, x2, y2 = x1[valid], y1[valid], x2[valid], y2[valid]

        mask_img = np.zeros(image.shape[:2], dtype=np.uint8)
        for xi1, yi1, xi2, yi2 in zip(x1.astype(int), y1.astype(int), x2.astype(int), y2.astype(int)):
            cv2.rectangle(mask_img, (xi1, yi1), (xi2, yi2), 255, -1)
        total_ambient_area = np.count_nonzero(mask_img)

        if total_ambient_area > 0:
            self._save_image(image, timestamp)

        area_ratio = total_ambient_area / detect_zone_area
        return float(area_ratio)

    def _read_image(self, timestamp):
        path = f"{timestamp}.jpg"
        if os.path.exists(path):
            return cv2.imread(path)
        logger.warning(f"Image not found: {path}")
        return None

    def stop(self):
        # 停止推理线程
        if self._inference_thread and self._inference_thread.is_alive():
            self._stop_inference.set()
            self._inference_thread.join(timeout=2)

        # 停止其他线程
        if self.snapshot_fetcher:
            self.snapshot_fetcher.stop()
        if self.zone_fetcher:
            self.zone_fetcher.stop()

        logger.info("Model stopped.")
"""


@Component.inputs(File(key="model_params", file_type="Json"))
@Component.outputs(File(key="model_loader.py", file_type="Any"))
def main_business(**kwargs):
    model_params = kwargs.get("model_params")
    rtsp_url = model_params.get("视频参数").get("视频流地址").split("\n")[0]
    detect_class = model_params.get("视频参数").get("识别种类")
    zone_api_base_url = model_params.get("视频参数").get("平台地址")
    device = model_params.get("视频参数").get("运行设备")
    service_id = model_params.get("视频参数").get("服务id", "")
    confidence = model_params.get("视频参数").get("置信度阈值", 0.4)
    zlmediakit_host = model_params.get("视频参数").get("zlmedikit地址","192.165.1.10")
    zlmediakit_port = model_params.get("视频参数").get("zlmedikit端口", 6060)
    zlmediakit_key = model_params.get("视频参数").get("zlmedikit密钥", "Sushine@2025!")
    kafka = model_params.get("视频参数").get("kafka地址", "192.165.1.10:9092")
    tag_name = model_params.get("视频参数").get("测点名").split("\n")[0]
    prefix = SMOKE_DETECT_SETTINGS.format(
        rtsp_url=rtsp_url,
        detect_class=detect_class,
        zone_api_base_url=zone_api_base_url,
        device=device,
        service_id=service_id,
        confidence=confidence,
        zlmediakit_host=zlmediakit_host,
        zlmediakit_port=zlmediakit_port,
        zlmediakit_key=zlmediakit_key,
        tag_name=tag_name,
        kafka=kafka
    )
    return {"model_loader.py": bytes(prefix + SMOKE_DETECT, encoding="utf-8")}


if __name__ == '__main__':
    App.run(main_business)
