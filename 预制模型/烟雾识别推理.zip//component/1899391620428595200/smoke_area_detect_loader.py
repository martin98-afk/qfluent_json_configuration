"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: smoke_area_detect_loader.py
@time: 2025/3/11 17:19
@desc:
"""
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import File, StringOfDict

SMOKE_DETECT = """
class ReconnectThread(Thread):
    def __init__(self, model):
        super().__init__(daemon=True)
        self.model = model
        self._stop_event = threading.Event()
    
    def _attempt_reconnect(self):
        logger.warning("尝试重连视频流...")
        cap = cv2.VideoCapture(RTSP_URL)
        time.sleep(1)

        if cap.isOpened():
            logger.info("视频流已重连")
            cap.release()
            return True
        else:
            logger.error("重连失败")
            cap.release()
            return False

    def run(self):

        while not self._stop_event.is_set():
            logger.info("重连线程正在运行")
            if self.model._is_disconnected:
                logger.info("检测到断连，开始后台重试...")
                if hasattr(self.model, "cap"):
                    try:
                        self.model.cap.stop_read()
                        self.model.cap.release()
                        del self.model.cap
                    except Exception as e:
                        logger.error(f"清理连接时出错: {e}")
                success = self._attempt_reconnect()
                if success:
                    logger.info("后台重连成功，恢复服务")
                    self.model.cap = RTSCapture.create(RTSP_URL)
                    self.model.cap.start_read()
                    if self.model.cap.isStarted():
                        self.model._is_disconnected = False  # 更新状态
            time.sleep(RECONNECT_INTERVAL)  # 间隔重试

    def stop(self):
        self._stop_event.set()


class ZoneFetcher(threading.Thread):
    "Background thread to periodically fetch and cache detection zones"

    def __init__(self, service_id_getter):
        super().__init__(daemon=True)
        self.service_id_getter = service_id_getter
        self._stop_event = threading.Event()
        self.zone_cache = {}

    def fetch_zone(self, service_id):
        try:
            with httpx.Client(base_url=BASE_URL, timeout=10) as client:
                resp = client.get(
                    f"/rest/video/camera/config/getRecogSphere?serviceId={service_id}"
                )
                resp.raise_for_status()
                data = resp.json().get("data", "{}")
            zone = json.loads(data)
            parsed = {
                key: [float(v) for v in val.split(',')]
                for key, val in zone.items()
            }
            self.zone_cache[service_id] = [
                [parsed['vertexPos1'][0], parsed['vertexPos1'][1]],
                [parsed['vertexPos2'][0], parsed['vertexPos2'][1]]
            ]
            logger.info(f"Fetched zone for {service_id}: {self.zone_cache[service_id]}")
        except Exception:
            logger.error(f"Failed to fetch zone for {service_id}, using full frame.")
            self.zone_cache[service_id] = [[0, 0], [100, 100]]

    def _remove_image(self):
        cutoff = time.time() - 86400
        for root, _, files in os.walk('.', topdown=False):
            for f in files:
                if f.endswith('.jpg'):
                    path = os.path.join(root, f)
                    if os.path.getmtime(path) < cutoff:
                        os.remove(path)

    def run(self):
        last_service = None
        while not self._stop_event.is_set():
            service_id = self.service_id_getter()
            if service_id:
                self.fetch_zone(service_id)
                last_service = service_id
            self._remove_image()
            logger.info("历史图像已移除")
            time.sleep(POLL_INTERVAL)

    def stop(self):
        self._stop_event.set()


class RTSCapture(cv2.VideoCapture):
    "Real Time Streaming Capture with timestamped frames."
    _cur_frame = None
    _reading = False
    _last_read_ts = None

    @staticmethod
    def create(url):
        rtscap = RTSCapture(url)
        # 限制内部缓冲区为 1 帧，减少旧帧滞留（并非所有后端均支持）
        try:
            rtscap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            logger.warning("CAP_PROP_BUFFERSIZE not supported by backend.")
        rtscap.frame_receiver = threading.Thread(
            target=rtscap.recv_frame, daemon=True
        )
        if isinstance(url, str) and url.startswith(("rtsp://", "rtmp://", "http://")):
            rtscap._reading = True
        return rtscap

    def isStarted(self):
        ok = self.isOpened()
        if ok and self._reading:
            ok = self.frame_receiver.is_alive()
        return ok

    def recv_frame(self):
        while self._reading and self.isOpened():
            ok, frame = super().read()
            if not ok:
                break
            # record timestamp when frame is captured
            self._last_read_ts = time.perf_counter()
            self._cur_frame = frame
            time.sleep(0.005)
        self._reading = False

    def read2(self):
        frame = self._cur_frame
        # clear stored frame after read
        self._cur_frame = None
        return (frame is not None), frame

    def start_read(self):
        self.frame_receiver.start()
        self.read_latest_frame = self.read2 if self._reading else self.read

    def stop_read(self):
        self._reading = False
        if getattr(self, "frame_receiver", None) and self.frame_receiver.is_alive():
            self.frame_receiver.join()


def image_to_base64(image: np.ndarray) -> str:
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')


class Model(Processor):
    def __init__(self):
        self.model = None
        self._service_id = None
        self._last_reconnect = 0.0
        self._is_disconnected = False  # 新增状态变量
        # stats for timing
        self.stats = {
            'read_latency': [],
            'validate_zone': [],
            'inference': [],
            'postprocess': []
        }

    def load(self, model_path):
        if not model_path.endswith(".onnx") and not model_path.endswith(".engine"):
            os.rename(model_path, "yolo.pt")
            self.model = YOLO("yolo.pt", task="detect")
        else:
            self.model = YOLO(model_path, task="detect")
        self.cap = RTSCapture.create(RTSP_URL)
        self.cap.start_read()

        self.zone_fetcher = ZoneFetcher(lambda: self._service_id)
        self.zone_fetcher.start()
        self.reconnect_thread = ReconnectThread(self)
        self.reconnect_thread.start()

    def _validate_detect_zone(self, shape):
        h, w = shape[:2]
        raw = self.zone_fetcher.zone_cache.get(self._service_id, [[0, 0], [100, 100]])
        zone = [[int(p[0] / 100 * w), int(p[1] / 100 * h)] for p in raw]
        x1, y1 = np.min(zone, axis=0)
        x2, y2 = np.max(zone, axis=0)
        return np.array([[x1, y1], [x2, y2]], dtype=int)

    def _save_image(self, image: np.ndarray):
        cv2.imwrite(f"{self.now}.jpg", image)

    def predict(self, data: List):
        if self._is_disconnected:
            logger.warning("请求被拒绝：视频流当前处于断连状态")
            return [0, "Service unavailable due to stream disconnection"]
        ts_req = data[0]
        if ts_req and ts_req > 0:
            img = self._read_image(ts_req)
            return [0, image_to_base64(img)] if img is not None else [0, "image not found!"]

        self._service_id = data[1]
        self.now = float(time.time())
        if not self.cap.isStarted():
            self._is_disconnected = True
            logger.warning("unable to connect video stream!")
            return [0, self.now]

        # record fetch time and compute read latency
        ok, frame = self.cap.read_latest_frame()
        t_after = time.perf_counter()
        if hasattr(self.cap, '_last_read_ts') and self.cap._last_read_ts:
            read_latency = t_after - self.cap._last_read_ts
            self.stats['read_latency'].append(read_latency)
            # logger.info(f"FRAME READ LATENCY: {read_latency*1000:.1f} ms")

        if not ok or frame is None:
            logger.warning("unable to connect video stream!")
            self._is_disconnected = True
            return [0, self.now]
        
        # validate zone timing
        t0 = time.perf_counter()
        self.detect_zone = self._validate_detect_zone(frame.shape)
        t1 = time.perf_counter()
        self.stats['validate_zone'].append(t1 - t0)

        # inference timing (sync GPU if needed)
        t0 = time.perf_counter()
        results = self.model(frame, device=device, verbose=False)
        t1 = time.perf_counter()
        self.stats['inference'].append(t1 - t0)

        res = next(iter(results), None)
        if not res:
            logger.info("no detect result!")
            logger.info(
                f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
                f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
                f"infer: {self.stats['inference'][-1] * 1000:.1f} ms  "
            )
            return [0, self.now]

        # postprocess timing
        t0 = time.perf_counter()
        area_ratio = self._calculate_smoke_area(res, frame)
        t1 = time.perf_counter()
        self.stats['postprocess'].append(t1 - t0)

        logger.info(
            f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
            f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
            f"infer: {self.stats['inference'][-1] * 1000:.1f} ms  "
            f"post: {self.stats['postprocess'][-1] * 1000:.1f} ms"
        )

        return [round(area_ratio, 4) * 100, self.now]

    def _calculate_smoke_area(self, result, image):
        # 1. 提取检测框与类别
        boxes = result.boxes.xyxy.cpu().numpy()
        classes = result.boxes.cls.cpu().numpy()
        names_list = [result.names[i] for i in range(len(result.names))]

        # 2. 筛选出 DETECT_CLASS 类别的目标框
        vec_match = np.vectorize(lambda cls: names_list[int(cls)] == DETECT_CLASS)
        mask = vec_match(classes)
        boxes = boxes[mask]
        if len(boxes) == 0:
            return 0

        # 3. 与检测区域进行裁剪（只保留交集）
        x1 = np.maximum(boxes[:, 0], self.detect_zone[0, 0])
        y1 = np.maximum(boxes[:, 1], self.detect_zone[0, 1])
        x2 = np.minimum(boxes[:, 2], self.detect_zone[1, 0])
        y2 = np.minimum(boxes[:, 3], self.detect_zone[1, 1])
        valid = (x2 > x1) & (y2 > y1)
        if not np.any(valid):
            return 0

        x1, y1, x2, y2 = x1[valid], y1[valid], x2[valid], y2[valid]

        # 4. 构建 mask 图像，合并所有裁剪后框，避免重叠面积重复计入
        mask_img = np.zeros(image.shape[:2], dtype=np.uint8)
        for xi1, yi1, xi2, yi2 in zip(x1.astype(int), y1.astype(int), x2.astype(int), y2.astype(int)):
            cv2.rectangle(mask_img, (xi1, yi1), (xi2, yi2), 255, -1)  # 填充白色

        # 5. 统计掩码图像中非零像素数量，即总面积
        total_area = np.count_nonzero(mask_img)

        # 6. 可视化绘制
        for xi1, yi1, xi2, yi2 in zip(x1, y1, x2, y2):
            cv2.rectangle(image, (int(xi1), int(yi1)), (int(xi2), int(yi2)), (0, 0, 255), 2)
            cv2.putText(image, f"{DETECT_CLASS}", (int(xi1), int(yi1) - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 1)

        # 7. 计算检测区域面积
        zone_area = (self.detect_zone[1, 0] - self.detect_zone[0, 0]) * (
                    self.detect_zone[1, 1] - self.detect_zone[0, 1])
        if zone_area <= 0:
            return 0

        # 8. 若存在目标，保存图像
        if total_area > 0:
            self._save_image(image)

        return total_area / zone_area

    def _read_image(self, timestamp):
        path = f"{timestamp}.jpg"
        if os.path.exists(path):
            return cv2.imread(path)
        logger.warning(f"Image not found: {path}")
        return None

    def stop(self):
        self.cap.stop_read()
        self.zone_fetcher.stop()
"""


@Component.inputs(File(key="model_params", file_type="Json"))
@Component.outputs(File(key="model_loader.py", file_type="Any"))
def main_business(**kwargs):
    model_params = kwargs.get("model_params")
    rtsp_url = model_params.get("视频参数").get("视频流地址").split("\n")[0]
    detect_class = model_params.get("视频参数").get("识别种类")
    zone_api_base_url = model_params.get("视频参数").get("平台地址")
    device = model_params.get("视频参数").get("运行设备")
    prefix = f"""import datetime
import time
import httpx
import numpy as np
import base64
import cv2
import os
import sys
import json
import threading

from typing import List
from threading import Thread
from ultralytics import YOLO
from loguru import logger
from sushineAI import Processor

RTSP_URL = "{rtsp_url}"
DETECT_CLASS = "{detect_class}"
BASE_URL = "{zone_api_base_url}"
device = "{device}"
POLL_INTERVAL = 5  # seconds between zone fetches
RECONNECT_INTERVAL = 5  # seconds between reconnect attempts
"""

    return {"model_loader.py": bytes(prefix + SMOKE_DETECT, encoding="utf-8")}


if __name__ == '__main__':
    App.run(main_business)
