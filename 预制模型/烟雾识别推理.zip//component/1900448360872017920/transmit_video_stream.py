"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: transmit_video_stream.py
@time: 2025/3/14 15:28
@desc: 
"""
import subprocess

from sushineAI.argument import StringOfDict
from sushineAI.component import Component
from sushineAI.app import App


def transmit_video_stream(ori_url, transmit_url):
    # FFmpeg 推流命令配置项
    ffmpeg_command = [
        'ffmpeg',
        "-i", ori_url,
        "-c:v", "copy",
        '-c:a', 'copy',
        "-an",  # 禁用音频
        '-f', 'mpegts', 

        # 推流地址
        transmit_url  # 后面的/live/stream可以修改成视频描述,如/taigang/smoke1
    ]

    # 启动 FFmpeg 推流进程
    subprocess.Popen(ffmpeg_command)


@Component.params(StringOfDict(key=["ori_rtsp_url", "transmit_rtsp_url"]))
def main_business(**kwargs):
    transmit_video_stream(kwargs.get("ori_rtsp_url"), kwargs.get("transmit_rtsp_url"))

    return


if __name__ == "__main__":
    App.run(main_business)
