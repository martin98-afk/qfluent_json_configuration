"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: model_parameters_generate.py
@time: 2024/10/14 9:59
@desc: 
"""
import pandas as pd

from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import StringOfDict
from sushineAI.argument import Xlsx, File


@Component.inputs(File(key='model_params',file_type='Json'))
@Component.outputs(Xlsx(key="parameters"))
def main_business(**kwargs):
    model_params = kwargs.get('model_params')
    input_vars = ["timestamp", "service_id"]
    input_type = ["float", "str"]
    output_vars = [model_params.get("视频参数").get("测点名").split("\n")[0], "timestamp"]
    output_type = ["float", "float"]

    output_list = []
    for column, type in zip(input_vars, input_type):
        if column == "": continue
        output_list.append({"参数名称": column, "参数类型": type, "参数描述": "", "输入/输出": "输入"})
    for column, type in zip(output_vars, output_type):
        if column == "": continue
        output_list.append({"参数名称": column, "参数类型": type, "参数描述": "", "输入/输出": "输出"})

    dataframe = pd.DataFrame(output_list)
    return {'parameters': {"sheet1": dataframe}}


if __name__ == '__main__':
    App.run(main_business)
