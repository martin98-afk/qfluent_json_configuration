from sushineAI.app import App
from sushineAI.argument import File
from sushineAI.component import Component

SMOKE_DETECT_SETTINGS = """
# ==================== 配置 ====================
RTSP_URL = "{rtsp_url}"
DETECT_CLASS = "{detect_class}"
BASE_URL = "{zone_api_base_url}"
device = "{device}"
SERVICE_ID = "{service_id}"
CONFIDENCE = {confidence}
POLL_INTERVAL = 5  # seconds between zone fetches

# ZLMediaKit 配置
ZLMEDIAKIT_HOST = "{zlmediakit_host}"
ZLMEDIAKIT_PORT = {zlmediakit_port}
ZLMEDIAKIT_SECRET = "{zlmediakit_key}"
ZLMEDIAKIT_TIMEOUT_SEC = 10
ZLMEDIAKIT_EXPIRE_SEC = 0
SNAPSHOT_INTERVAL = 0.2  # 200ms 一次截图，可调

TAG_NAME = "{tag_name}"
KAFKA_CONFIG = {{
    "bootstrap.servers": "{kafka}",
    "group.id": "ai-service-push",
    "auto.offset.reset": "earliest"
}}
"""

SMOKE_DETECT = """
PUSH_TEMPLATE = {
    'code': 0,
    'message': 'success',
    'timestamp': 1722054181043,
    'data': {
        'flag': True,
        'detail': 'error',
        'result': [],
        'outputParams': [
            {
                'paramName': TAG_NAME,
                'paramType': 'float',
                'paramDesc': '烟雾侵占区域面积',
            },
            {
                'paramName': 'timestamp',
                'paramType': 'str',
                'paramDesc': '',
            }
        ]
    }
}

import time
import httpx
import numpy as np
import hashlib
import base64
import traceback
import cv2
import os
import json
import threading
import urllib.parse
from typing import List
from threading import Thread
from ultralytics import YOLO
from loguru import logger
from sushineAI import Processor

# URL 编码 RTSP 地址（关键！）
RTSP_URL_ENCODED = urllib.parse.quote(RTSP_URL, safe='')
SNAP_URL = (
    f"http://{ZLMEDIAKIT_HOST}:{ZLMEDIAKIT_PORT}/index/api/getSnap?"
    f"url={RTSP_URL_ENCODED}&timeout_sec={ZLMEDIAKIT_TIMEOUT_SEC}&"
    f"expire_sec={ZLMEDIAKIT_EXPIRE_SEC}&secret={ZLMEDIAKIT_SECRET}"
)


# ==================== 辅助函数 ====================
def _image_hash(image: np.ndarray) -> str:
    if image is None:
        return ""
    # 简化：缩放到小图 + 转灰度 + 哈希
    small = cv2.resize(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY), (32, 32))
    return hashlib.md5(small.tobytes()).hexdigest()


def image_to_base64(image: np.ndarray) -> str:
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')


class SnapshotFetcher(Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._frame_lock = threading.Lock()
        self._latest_frame = None
        self._latest_ts = None
        self._latest_tss = None
        self._latest_hash = ""  # 新增：图像内容哈希

    def get_latest_unprocessed_frame(self, last_processed_hash):
        with self._frame_lock:
            if self._latest_hash != last_processed_hash and self._latest_frame is not None:
                return self._latest_frame.copy(), self._latest_ts, self._latest_hash
            else:
                return None, None, last_processed_hash

    def run(self):
        logger.info("SnapshotFetcher 线程启动...")
        last_hash = ""
        while not self._stop_event.is_set():
            try:
                with httpx.Client(timeout=10) as client:
                    resp = client.get(SNAP_URL)
                    if resp.status_code == 200:
                        img_array = np.frombuffer(resp.content, dtype=np.uint8)
                        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                        if frame is not None:
                            current_hash = _image_hash(frame)
                            if current_hash != last_hash:  # 内容变化才更新
                                with self._frame_lock:
                                    self._latest_frame = frame
                                    self._latest_ts = time.perf_counter()
                                    self._latest_tss = time.time()
                                    self._latest_hash = current_hash
                                logger.debug(f"获取新截图（内容变化）")
                                last_hash = current_hash
                            # else: 图像未变，不更新
                        else:
                            logger.warning("截图解码失败")
                    else:
                        logger.error(f"getSnap 返回错误: {resp.status_code}")
            except Exception as e:
                logger.error(f"获取截图异常: {e}")
                logger.error(traceback.format_exc())
            time.sleep(0.2)

# ==================== 区域获取线程（保持不变） ====================
class ZoneFetcher(Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self.zone_cache = {}

    def fetch_zone(self, service_id):
        try:
            with httpx.Client(base_url=BASE_URL, timeout=10) as client:
                resp = client.get(
                    f"/rest/video/camera/config/getRecogSphere?serviceId={service_id}"
                )
                resp.raise_for_status()
                zone_list = resp.json().get("data", [])
            polygons = [
                [
                    [float(p) for p in pos.split(",")]
                    for pos in polygon["posList"]
                ]
                for polygon in zone_list
            ]
            self.zone_cache[service_id] = polygons
            logger.info(f"Fetched zone for {service_id}: {self.zone_cache[service_id]}")
        except Exception:
            logger.error(f"Failed to fetch zone for {service_id}, using full frame.")
            self.zone_cache[service_id] = [[[0, 0], [100, 0], [100, 100], [0, 100]]]

    def _remove_image(self):
        cutoff = time.time() - 86400
        for root, _, files in os.walk('.', topdown=False):
            for f in files:
                if f.endswith('.jpg'):
                    path = os.path.join(root, f)
                    if os.path.getmtime(path) < cutoff:
                        os.remove(path)

    def run(self):
        while not self._stop_event.is_set():
            try:
                self.fetch_zone(SERVICE_ID)
                self._remove_image()
                logger.info("历史图像已移除")
                time.sleep(POLL_INTERVAL)
            except:
                import traceback
                logger.error(traceback.format_exc())

    def stop(self):
        self._stop_event.set()


# ==================== 主模型类 ====================
class Model(Processor):
    def __init__(self):
        from kafka import KafkaProducer
        self.model = None
        self.snapshot_fetcher = None
        self.zone_fetcher = None
        self.detect_zone = None
        self._inference_thread = None
        self._stop_inference = threading.Event()  # 控制推理线程停止
        self.last_processed_frame_hash = ""  # 替换 frame_id
        self.stats = {
            'read_latency': [],
            'validate_zone': [],
            'inference': [],
            'postprocess': []
        }
        self.kafka_producer = KafkaProducer(
            bootstrap_servers=KAFKA_CONFIG['bootstrap.servers'],
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            api_version=(0, 10, 1)
        )

    def load(self, model_path):
        if not model_path.endswith((".onnx", ".engine")):
            os.rename(model_path, "yolo.pt")
            self.model = YOLO("yolo.pt", task="detect")
        else:
            self.model = YOLO(model_path, task="detect")

        dummy_img = np.zeros((640, 640, 3), dtype=np.uint8)
        self.model(dummy_img, device=device, verbose=False)

        self.snapshot_fetcher = SnapshotFetcher()
        self.snapshot_fetcher.start()

        self.zone_fetcher = ZoneFetcher()
        self.zone_fetcher.start()

        # 启动推理线程（关键！不再阻塞主线程）
        self._stop_inference.clear()
        self._inference_thread = threading.Thread(target=self._inference_loop, daemon=True)
        self._inference_thread.start()

        logger.info("Model loaded. Background threads started.")

    def _inference_loop(self):
        logger.info("推理线程启动...")
        while not self._stop_inference.is_set():
            try:
                result = self.detect()
                if result:
                    logger.info(f"模型计算结果：{result}")
                    push_data = json.loads(json.dumps(PUSH_TEMPLATE))  # 深拷贝模板
                    push_data["timestamp"] = int(time.time() * 1000)
                    push_data["data"]["result"] = result
                    self.push_to_kafka(push_data)
            except Exception as e:
                logger.error(f"推理循环异常: {e}")
                logger.error(traceback.format_exc())
            time.sleep(0.2)  # 可根据实际帧率调整
        logger.info("推理线程已停止")

    def detect(self):
        try:

            t_start = time.perf_counter()

            # 获取比 last_processed_frame_id 更新的帧
            frame, frame_ts, frame_hash = self.snapshot_fetcher.get_latest_unprocessed_frame(
                self.last_processed_frame_hash)
            if frame is None:
                return None
            now = self.snapshot_fetcher._latest_tss - 1
            # === 处理该帧 ===
            read_latency = t_start - frame_ts
            self.stats['read_latency'].append(read_latency)
            if read_latency > 1.2:
                logger.warning(f"截图过期 ({read_latency:.2f}s)，跳过检测")
                # 注意：即使过期，也视为“已处理”，避免卡住
                self.last_processed_frame_hash = frame_hash
                return None

            # 验证区域
            t0 = time.perf_counter()
            self.detect_zone = self._validate_detect_zone(frame.shape)
            t1 = time.perf_counter()
            self.stats['validate_zone'].append(t1 - t0)

            # 推理
            t0 = time.perf_counter()
            results = self.model(frame, device=device, verbose=False, conf=CONFIDENCE)
            t1 = time.perf_counter()
            self.stats['inference'].append(t1 - t0)

            res = next(iter(results), None)
            if not res:
                logger.info("no detect result!")
                logger.info(
                    f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
                    f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
                    f"infer: {self.stats['inference'][-1] * 1000:.1f} ms"
                )
                self.last_processed_frame_hash = frame_hash  # 标记已处理
                return [0, now]

            # 后处理
            t0 = time.perf_counter()
            area_ratio = self._calculate_smoke_area(res, frame, now)
            t1 = time.perf_counter()
            self.stats['postprocess'].append(t1 - t0)

            logger.info(
                f"TIMINGS | read: {self.stats['read_latency'][-1] * 1000:.1f} ms  "
                f"zone: {self.stats['validate_zone'][-1] * 1000:.1f} ms  "
                f"infer: {self.stats['inference'][-1] * 1000:.1f} ms  "
                f"post: {self.stats['postprocess'][-1] * 1000:.1f} ms"
            )

            # 标记该帧已处理！
            self.last_processed_frame_hash = frame_hash

            return [round(area_ratio, 4) * 100, now]

        except Exception:
            logger.error(f"Failed to detect smoke: {traceback.format_exc()}")
            return None

    def push_to_kafka(self, v):
        self.kafka_producer.send(KAFKA_CONFIG['group.id'], v)

    def _validate_detect_zone(self, shape):
        h, w = shape[:2]
        raw = self.zone_fetcher.zone_cache.get(SERVICE_ID)
        # 将多个多边形的百分比点坐标转换成实际坐标
        polygons = []
        for polygon in raw:
            polygon = [
                (int(p[0] / 100 * w), int(p[1] / 100 * h)) for p in polygon
            ]
            polygons.append(polygon)
        return [np.array(polygon, np.int32) for polygon in polygons]

    def _save_image(self, image: np.ndarray, timestamp):
        cv2.imwrite(f"{timestamp}.jpg", image)

    def predict(self, data: List):
        try:
            ts_req = data[0]
            if ts_req:
                img = self._read_image(ts_req)
                return [0, image_to_base64(img)] if img is not None else [0, "image not found!"]

        except Exception as e:
            import traceback
            logger.error(traceback.format_exc())
            return [0, time.time()]

    def _calculate_smoke_area(self, result, image, timestamp):
        if len(result.boxes) == 0:
            return 0.0

        boxes = result.boxes.xyxy.cpu().numpy()
        confidences = result.boxes.conf.cpu().numpy()
        classes = result.boxes.cls.cpu().numpy()
        names_list = result.names

        smoke_boxes = []
        can_boxes = []
        smoke_conf = []

        for i, (conf, cls_id) in enumerate(zip(confidences, classes)):
            label = names_list[int(cls_id)]
            box = boxes[i]
            if label == DETECT_CLASS:
                smoke_boxes.append(box)
                smoke_conf.append(conf)
            elif label == "can":
                can_boxes.append(box)

        if len(smoke_boxes) == 0:
            return 0.0

        smoke_boxes = np.array(smoke_boxes)
        can_boxes = np.array(can_boxes) if len(can_boxes) > 0 else []

        detect_mask = np.zeros(image.shape[:2], dtype=np.uint8)
        for poly in self.detect_zone:
            cv2.fillPoly(detect_mask, [poly], 255)

        MAX_HANGING_RATIO = 0.6
        HORIZONTAL_OVERLAP_RATIO = 0.3
        MIN_SMOKE_AREA = 100

        ambient_boxes = []
        ambient_conf = []
        smoke_from_can_boxes = []

        for conf, smoke in zip(smoke_conf, smoke_boxes):
            sx1, sy1, sx2, sy2 = smoke
            smoke_area = (sx2 - sx1) * (sy2 - sy1)
            if smoke_area < MIN_SMOKE_AREA:
                continue
            matched = False
            for can in can_boxes:
                cx1, cy1, cx2, cy2 = can
                overlap_x1 = max(sx1, cx1)
                overlap_x2 = min(sx2, cx2)
                if overlap_x1 >= overlap_x2:
                    continue
                overlap_width = overlap_x2 - overlap_x1
                min_width = min(cx2 - cx1, sx2 - sx1)
                if overlap_width / min_width < HORIZONTAL_OVERLAP_RATIO:
                    continue
                if sy1 <= cy2:
                    smoke_from_can_boxes.append(smoke)
                    matched = True
                    break
            if not matched:
                ambient_boxes.append(smoke)
                ambient_conf.append(conf)

        # 可视化
        for poly in self.detect_zone:
            cv2.polylines(image, [poly], True, (255, 0, 0), 8)
        for conf, box in zip(ambient_conf, ambient_boxes):
            x1, y1, x2, y2 = map(int, box)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 8)
            cv2.putText(image, f"smoke {conf:.2f}", (x1 + 30, y1 + 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 8)
        for box in smoke_from_can_boxes:
            x1, y1, x2, y2 = map(int, box)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 255), 8)
            cv2.putText(image, "smoke (can)", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 8)
        for can in can_boxes:
            x1, y1, x2, y2 = map(int, can)
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 255, 0), 8)
            cv2.putText(image, "can", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 8)

        if len(ambient_boxes) == 0:
            return 0.0

        # 创建一个全黑掩码
        smoke_mask = np.zeros_like(detect_mask)

        # 只在 detect_zone 内绘制烟雾？不，应该先画烟雾，再与 detect_mask 取交
        for box in ambient_boxes:
            x1, y1, x2, y2 = map(int, box)
            cv2.rectangle(smoke_mask, (x1, y1), (x2, y2), 255, -1)

        # 计算烟雾与检测区域的交集
        intersection = cv2.bitwise_and(smoke_mask, detect_mask)
        total_area = np.count_nonzero(intersection)
        detect_area = np.count_nonzero(detect_mask)
        if total_area > 0:
            self._save_image(image, timestamp)

        return total_area / detect_area if detect_area > 0 else 0.0

    def _read_image(self, timestamp):
        path = f"{timestamp}.jpg"
        if os.path.exists(path):
            return cv2.imread(path)
        logger.warning(f"Image not found: {path}")
        return None

    def stop(self):
        # 停止推理线程
        if self._inference_thread and self._inference_thread.is_alive():
            self._stop_inference.set()
            self._inference_thread.join(timeout=2)

        # 停止其他线程
        if self.snapshot_fetcher:
            self.snapshot_fetcher.stop()
        if self.zone_fetcher:
            self.zone_fetcher.stop()
        if hasattr(self, 'kafka_producer'):
            self.kafka_producer.close()
        logger.info("Model stopped.")
"""


@Component.inputs(File(key="model_params", file_type="Json"))
@Component.outputs(File(key="model_loader.py", file_type="Any"))
def main_business(**kwargs):
    model_params = kwargs.get("model_params")
    rtsp_url = model_params.get("视频参数").get("视频流地址").split("\n")[0]
    detect_class = model_params.get("视频参数").get("识别种类")
    zone_api_base_url = model_params.get("视频参数").get("平台地址")
    device = model_params.get("视频参数").get("运行设备")
    service_id = model_params.get("视频参数").get("服务id", "")
    confidence = model_params.get("视频参数").get("置信度阈值", 0.4)
    zlmediakit_host = model_params.get("视频参数").get("zlmedikit地址","192.165.1.10")
    zlmediakit_port = model_params.get("视频参数").get("zlmedikit端口", 6060)
    zlmediakit_key = model_params.get("视频参数").get("zlmedikit密钥", "Sushine@2025!")
    kafka = model_params.get("视频参数").get("kafka地址", "192.165.1.10:9092")
    tag_name = model_params.get("视频参数").get("测点名").split("\n")[0]
    prefix = SMOKE_DETECT_SETTINGS.format(
        rtsp_url=rtsp_url,
        detect_class=detect_class,
        zone_api_base_url=zone_api_base_url,
        device=device,
        service_id=service_id,
        confidence=confidence,
        zlmediakit_host=zlmediakit_host,
        zlmediakit_port=zlmediakit_port,
        zlmediakit_key=zlmediakit_key,
        tag_name=tag_name,
        kafka=kafka
    )
    return {"model_loader.py": bytes(prefix + SMOKE_DETECT, encoding="utf-8")}


if __name__ == '__main__':
    App.run(main_business)
