"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: target_zone_invasion.py
@time: 2024/10/17 14:27
@desc: 
"""
import numpy as np
from PIL import Image
import cv2
import supervision as sv
import sys
from ultralytics import YOLO
import os
from loguru import logger
PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import Csv, StringOfDict, StringOfList, Model, String, File
from sushineAI.utils.translator import transform_params_type
from sushineAI.component import Component
from sushineAI.app import App

# 设定使用第三个gpu
os.environ["CUDA_VISIBLE_DEVICES"] = "3"


def draw_and_visualize(image, detections, class_name, kwargs):
    invasion_zone = [[int(kwargs.get("invasion_upper_x")), int(kwargs.get("invasion_upper_y"))],
                     [int(kwargs.get("invasion_lower_x")), int(kwargs.get("invasion_lower_y"))]]
    if invasion_zone[1][0] <= invasion_zone[0][0] or invasion_zone[1][1] <= invasion_zone[0][1]:
        invasion_zone = [[0, 0], [image.shape[1], image.shape[0]]]
    
    # 计算入侵区域的面积
    invasion_area = (invasion_zone[1][0] - invasion_zone[0][0]) * (invasion_zone[1][1] - invasion_zone[0][1])

    # 绘制边界框并检查是否有物体进入入侵区域
    boxes = [detections.xyxy[i, :] for i in range(detections.xyxy.shape[0])]
    class_ids = [detections.class_id[i] for i in range(detections.xyxy.shape[0])]
    confidence = [detections.confidence[i] for i in range(detections.xyxy.shape[0])]
    invasion_class = kwargs.get("invasion_class").split(",")
    invasion_object = []

    for i in range(len(boxes)):
        x1, y1, x2, y2 = int(boxes[i][0]), int(boxes[i][1]), int(boxes[i][2]), int(boxes[i][3])
        label = str(class_name[class_ids[i]])
        
        # 仅处理在入侵类别中的物体
        if label not in invasion_class:
            continue

        # 计算物体的面积
        object_area = (x2 - x1) * (y2 - y1)

        # 检查是否进入入侵区域
        if (x1 >= invasion_zone[0][0] and x1 <= invasion_zone[1][0] and y1 >= invasion_zone[0][1] and y1 <=
            invasion_zone[1][1]) or (
                x2 >= invasion_zone[0][0] and x2 <= invasion_zone[1][0] and y2 >= invasion_zone[0][1] and y2 <=
                invasion_zone[1][1]):
            
            color = (0, 0, 255)  # 物体进入区域，改变颜色为红色
            # 绘制矩形和标签
            cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
            cv2.putText(image, label, (x1, y1 + 5), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
            
            # 计算该物体所占的面积比
            area_ratio = object_area / invasion_area if invasion_area > 0 else 0
            invasion_object.append([label, x1, y1, x2, y2, object_area, area_ratio, float(confidence[i])])

    # 绘制入侵区域
    cv2.rectangle(image, invasion_zone[0], invasion_zone[1], (255, 0, 0), 2)

    return image, invasion_object



def get_model(kwargs):
    model_name = kwargs.get('model.pt')
    os.rename(model_name.name, "yolo.pt")
    # 配置yolo预训练模型
    model = YOLO("yolo.pt", task="detect")
    return model


@Component.inputs(File(key="image", file_type='Image'), File(key="model.pt", file_type='Any'))
@Component.params(StringOfDict(
    key=["invasion_upper_x", "invasion_upper_y", "invasion_lower_x", "invasion_lower_y", "invasion_class"]))
@Component.outputs(File(key='image', file_type='Image'), File(key='result', file_type='Json'))
def target_zone_invasion(**kwargs):
    model = get_model(kwargs)
    # 读取视频每一帧，并进行目标检测，在原视频帧上框选目标，并生成新视频
    image = np.array(kwargs.get("image"))
    result = model.predict(image[..., ::-1])[0]
    class_name = result.names
    detections = sv.Detections.from_ultralytics(result)

    annotated_image, object = draw_and_visualize(image, detections, class_name, kwargs)

    return {"image": Image.fromarray(annotated_image), "result": object}


if __name__ == '__main__':
    App.run(target_zone_invasion)
    # yolo_gen_detect(input_video='烟雾视频.mp4', pre_model='best.pt')
