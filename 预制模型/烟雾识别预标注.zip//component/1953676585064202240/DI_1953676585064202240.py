"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: upload_image_to_label_studio.py
@time: 2025/8/8 14:51
@desc: 
"""
import os
import random
import requests
from label_studio_sdk import Client
from label_studio_sdk.client import LabelStudio
from label_studio_sdk.label_interface import LabelInterface
from label_studio_sdk.label_interface.create import labels
from sushineAI.app import App
from sushineAI.argument import File, StringOfDict
from sushineAI.component import Component

def generate_distinct_colors(classes):
    """
    为多个类别生成视觉上易区分的颜色
    使用 HSL 模型，均匀分布色相，固定饱和度和亮度
    """
    n = len(classes)
    colors = {}
    
    # 如果类别少，用预定义鲜艳颜色
    predefined = [
        "#e6194b", "#3cb44b", "#ffe119", "#0082c8", "#f58231",
        "#911eb4", "#46f0f0", "#f032e6", "#d2f53c", "#fabebe"
    ]
    
    if n <= 10:
        color_pool = predefined
    else:
        # 多类别：均匀分布在 0~360 色相环上
        color_pool = []
        for i in range(n):
            hue = int((i * 360 / n) % 360)  # 均匀分布
            saturation = 75  # 高饱和，但不过曝
            lightness = 60   # 适中偏亮，避免太暗
            
            # HSL to RGB
            h = hue / 360
            s = saturation / 100
            l = lightness / 100

            c = (1 - abs(2 * l - 1)) * s
            x = c * (1 - abs((h * 6) % 2 - 1))
            m = l - c / 2

            if 0 <= h < 1/6:
                r, g, b = c, x, 0
            elif 1/6 <= h < 2/6:
                r, g, b = x, c, 0
            elif 2/6 <= h < 3/6:
                r, g, b = 0, c, x
            elif 3/6 <= h < 4/6:
                r, g, b = 0, x, c
            elif 4/6 <= h < 5/6:
                r, g, b = x, 0, c
            else:
                r, g, b = c, 0, x

            r = int((r + m) * 255)
            g = int((g + m) * 255)
            b = int((b + m) * 255)

            color = "#{:02x}{:02x}{:02x}".format(r, g, b)
            color_pool.append(color)
    
    # 分配颜色
    for i, class_name in enumerate(classes):
        colors[class_name] = color_pool[i % len(color_pool)]
    
    return colors

# =================== 创建项目 ===================
def create_project(ls, project_name, classes):
    # 检查是否已存在同名项目
    for project in ls.get_projects():
        if project.params['title'] == project_name:
            print(f"✅ 项目已存在: {project}")
            return project.params["id"]
        
    # 生成高区分度颜色
    class_colors = generate_distinct_colors(classes)
    
    # 打印颜色映射（方便调试）
    print("🎨 颜色分配：")
    for cls, color in class_colors.items():
        print(f"  {cls}: {color}")

    # 创建新项目
    project = ls.start_project(
        title=project_name,
        label_config=f"""
        <View>
          <Image name="image" value="$image"/>

          <RectangleLabels name="label" toName="image">
            """ + "\n".join([f'<Label value="{class_name}" background="{class_colors[class_name]}"/>' for class_name in classes])+ """
          </RectangleLabels>
        </View>"""
    )
    print(project.params)
    print(f"🎉 创建新项目成功: {project}")
    return project.params["id"]


def upload_image(image_path, base_url, token, project_id):
    url = f'{base_url}/api/projects/{project_id}/import?commit_to_project=false'
    headers = {
        'Authorization': f'Token {token}'
    }
    files = {
        'files': open(image_path, 'rb')
    }
    response = requests.post(url, headers=headers, files=files)

    if response.status_code == 201:
        # 成功上传，返回可访问的 URL
        uploaded_id = response.json()['file_upload_ids']
        url2 = f'{base_url}/api/projects/{project_id}/reimport'
        print({"file_upload_ids":uploaded_id,"files_as_tasks_list":False})
        response = requests.post(url2, headers=headers, json={"file_upload_ids":uploaded_id,"files_as_tasks_list":False})
        if response.status_code == 201:
            print(f"🎉 上传成功: {image_path}")
            print(response.json())
        else:
            print(f"❌ 上传失败: {response.status_code} - {response.text}")
    else:
        print(f"❌ 上传失败: {response.status_code} - {response.text}")


@Component.inputs(File(key="input", file_type="Any"))
@Component.params(StringOfDict(key=['prefix', 'project_name', 'token', 'class']))
def main_business(**kwargs):
    # =================== 配置参数 ===================
    LABEL_STUDIO_URL = kwargs.get("prefix")  # 或你的服务器 IP
    API_TOKEN = kwargs.get("token")
    # 替换为你的 Token
    PROJECT_NAME = kwargs.get("project_name")

    # =================== 初始化 Label Studio 客户端 ===================
    ls = Client(url=LABEL_STUDIO_URL, api_key=API_TOKEN)
    ls.check_connection()
    input_path = kwargs.get("input").name
    classes = kwargs.get("class").split(",")
    project_id = create_project(ls, PROJECT_NAME, classes)
    upload_image(input_path, LABEL_STUDIO_URL, API_TOKEN, project_id)


if __name__ == '__main__':
    App.run(main_business)
