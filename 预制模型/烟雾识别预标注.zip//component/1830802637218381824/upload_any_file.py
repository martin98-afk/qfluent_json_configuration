"""
@author: TangXC
@license: (C) Copyright 1999-2019, NJ_LUCULENT Corporation Limited.
@contact: tangxucheng@luculent.net
@file: upload_any_file.py
@time: 2024/9/3 11:30
@desc:
"""
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import File


@Component.outputs(File(key="output", file_type="Any"))
def upload_any_file(**kwargs):
    return {'output': None}


if __name__ == '__main__':
    App.run(upload_any_file)
