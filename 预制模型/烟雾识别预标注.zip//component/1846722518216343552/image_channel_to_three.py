"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: image_channel_to_three.py
@time: 2024/10/17 9:19
@desc: 
"""

import sys
import os

import numpy as np
from PIL import Image

PROJECT_FILE_PATH = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.append(PROJECT_FILE_PATH)

from sushineAI.argument import StringOfDict, File
from sushineAI.component import Component
from sushineAI.app import App


@Component.inputs(File(key="image", file_type='Image'))
@Component.outputs(File(key='image', file_type='Image'))
def image_box_cut(**kwargs):
    input_image = kwargs.get("image")
    # 图片resize
    input_image = np.array(input_image)[..., :3]
    input_image = Image.fromarray(input_image)
    return {"image": input_image}


if __name__ == '__main__':
    App.run(image_box_cut)
