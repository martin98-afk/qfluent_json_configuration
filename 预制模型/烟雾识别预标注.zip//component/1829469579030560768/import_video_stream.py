"""
@author: mading
@license: (C) Copyright: LUCULENT Corporation Limited.
@contact: mading@luculent.net
@file: import_video_stream.py
@time: 2024/9/27 17:40
@desc: 
"""

import cv2
import matplotlib.pyplot as plt
from PIL import Image
from sushineAI.app import App
from sushineAI.component import Component
from sushineAI.argument import File
from sushineAI.argument import StringOfDict


@Component.params(StringOfDict(key=['rtsp_url']))
@Component.outputs(File(key="output", file_type="Image"))
def import_video_stream(**kwargs):
    rtsp_url = kwargs.get('rtsp_url')
    cap = cv2.VideoCapture(rtsp_url)
    if not cap.isOpened():
        print("无法打开RTSP视频流")
        exit()

    try:
        while True:
            ret, frame = cap.read()
            if ret:
                break
            else:
                print("无法读取视频帧")
                
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = Image.fromarray(frame)
        return {"output": frame}
    finally:
        cap.release()


if __name__ == '__main__':
    App.run(import_video_stream)
